import React, { useState, ChangeEvent, useEffect, DragEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import AppearanceSettings from '../components/AppearanceSettings';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, 
  PieChart, Pie
} from 'recharts';
import { 
  FileText, AlertCircle, TrendingUp, CheckCircle2, MessageSquare, ShieldAlert, 
  MapPin, BriefcaseBusiness, Star, ChevronRight, Compass, Bot, Send, 
  Building2, Camera, UploadCloud, Pencil, Plus, Phone, Mail, XCircle, 
  ShieldCheck, ArrowRight, DollarSign, PieChart as PieIcon, Activity,
  Eye, Building, CreditCard, Receipt, Calendar, History, Link, FileCode,
  Download, ExternalLink, MessageCircle, Clock, Check, AlertTriangle,
  BrainCircuit, RefreshCw, FileDown, ClipboardList, Info, Trash2
} from 'lucide-react';
import { useAppContext } from '../App';
import DemoPaymentModal from '../components/DemoPaymentModal';

export default function PYMEView() {
  const { currentView } = useAppContext();

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6">
      <AnimatePresence mode="wait">
        <motion.div
          key={currentView}
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -15 }}
          transition={{ duration: 0.2 }}
        >
          {currentView === 'dashboard' && <PYMEDashboard />}
          {currentView === 'proveedores' && <PYMEProveedores />}
          {currentView === 'validación' && <PYMEValidacion />}
          {currentView === 'conciliacion' && <PYMEConciliacion />}
          {currentView === 'diot' && <PYMEDIOT />}
          {currentView === 'alertas' && <PYMEAlertas />}
          {currentView === 'asesor' && <PYMEAsesor />}
          {currentView === 'directorio' && <PYMEDirectorio />}
          {currentView === 'perfil' && <PYMEPerfil />}
          {currentView === 'calendario' && <PYMECalendario />}
          {currentView === 'nomina' && <PYMENomina />}
          {currentView === 'descargas' && <PYMEDescargas />}
          {currentView === 'emitir' && <PYMEEmitir />}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

// ---------------------------
// SUBCOMPONENTS
// ---------------------------
function PYMEDashboard() {
  const { setCurrentView, showToast, t } = useAppContext();
  const [selectedStat, setSelectedStat] = useState<string | null>(null);
  const [chartTimeframe, setChartTimeframe] = useState<'3M' | '6M' | '12M'>('6M');

  const chartData = {
    '3M': [
      { name: 'Feb', ingresos: 245000, egresos: 134000, impuestos: 32800 },
      { name: 'Mar', ingresos: 220000, egresos: 128000, impuestos: 30100 },
      { name: 'Abr', ingresos: 267000, egresos: 154200, impuestos: 36400 },
    ],
    '6M': [
      { name: 'Nov', ingresos: 180000, egresos: 98000, impuestos: 24000 },
      { name: 'Dic', ingresos: 215000, egresos: 112000, impuestos: 28500 },
      { name: 'Ene', ingresos: 198000, egresos: 105000, impuestos: 26200 },
      { name: 'Feb', ingresos: 245000, egresos: 134000, impuestos: 32800 },
      { name: 'Mar', ingresos: 220000, egresos: 128000, impuestos: 30100 },
      { name: 'Abr', ingresos: 267000, egresos: 154200, impuestos: 36400 },
    ],
    '12M': [
      { name: 'May', ingresos: 150000, egresos: 80000, impuestos: 20000 },
      { name: 'Jun', ingresos: 160000, egresos: 85000, impuestos: 21000 },
      { name: 'Jul', ingresos: 175000, egresos: 90000, impuestos: 23000 },
      { name: 'Ago', ingresos: 185000, egresos: 95000, impuestos: 24500 },
      { name: 'Sep', ingresos: 190000, egresos: 100000, impuestos: 25000 },
      { name: 'Oct', ingresos: 178000, egresos: 95000, impuestos: 23500 },
      { name: 'Nov', ingresos: 180000, egresos: 98000, impuestos: 24000 },
      { name: 'Dic', ingresos: 215000, egresos: 112000, impuestos: 28500 },
      { name: 'Ene', ingresos: 198000, egresos: 105000, impuestos: 26200 },
      { name: 'Feb', ingresos: 245000, egresos: 134000, impuestos: 32800 },
      { name: 'Mar', ingresos: 220000, egresos: 128000, impuestos: 30100 },
      { name: 'Abr', ingresos: 267000, egresos: 154200, impuestos: 36400 },
    ]
  };

  return (
    <div className="space-y-6">
      {/* FISCAL BANNER */}
      <motion.div 
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        onClick={() => setCurrentView('calendario')}
        className="bg-gradient-to-r from-amber-500 to-orange-600 p-4 rounded-[1.5rem] text-white shadow-lg shadow-amber-500/20 flex items-center justify-between cursor-pointer group"
      >
        <div className="flex items-center gap-4">
          <div className="bg-white/20 p-2.5 rounded-xl backdrop-blur-md">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <p className="text-[10px] font-black uppercase tracking-[0.15em] opacity-80">{t.pyme_view.sections.next_obligation}</p>
            <h4 className="font-bold text-sm">{t.pyme_view.messages.next_isr}</h4>
          </div>
        </div>
        <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest bg-white/20 px-3 py-1.5 rounded-lg group-hover:bg-white/30 transition-colors">
          {t.pyme_view.sections.view_calendar} <ChevronRight className="w-4 h-4" />
        </div>
      </motion.div>

      {/* STATS */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          {[
            { label: t.pyme_view.stats.received_cfdi, value: '34', icon: FileText, color: 'text-tertiary' },
            { label: t.pyme_view.stats.active_providers, value: '12', icon: Building, color: 'text-secondary' },
            { label: t.pyme_view.stats.deductible, value: '$182k', icon: TrendingUp, color: 'text-blue-500' },
            { label: t.pyme_view.stats.sat_alerts, value: '3', icon: ShieldAlert, color: 'text-red-500' }
          ].map((stat, i) => (
            <div key={i} onClick={() => setSelectedStat(stat.label)} className="cursor-pointer bg-white p-5 rounded-[2rem] shadow-sm border border-gray-100 flex flex-col gap-3 hover:shadow-xl hover:scale-105 transition-all group">
              <div className={`p-2.5 w-fit rounded-xl bg-gray-50 flex items-center justify-center group-hover:bg-dark group-hover:text-white transition-colors ${stat.color}`}>
                <stat.icon className="w-5 h-5" />
              </div>
              <div>
                <p className="text-2xl font-black text-dark tracking-tight leading-none group-hover:text-tertiary transition-colors">{stat.value}</p>
                <p className="text-[10px] text-gray-400 mt-2 uppercase tracking-widest font-black">{stat.label}</p>
              </div>
            </div>
          ))}
        </div>

      <AnimatePresence>
        {selectedStat && (
          <div className="fixed inset-0 z-[500] bg-dark/60 backdrop-blur-md flex items-center justify-center p-4" onClick={() => setSelectedStat(null)}>
            <motion.div 
               initial={{ scale: 0.95, opacity: 0 }}
               animate={{ scale: 1, opacity: 1 }}
               exit={{ scale: 0.95, opacity: 0 }}
               className="bg-white w-full max-w-lg rounded-[3rem] shadow-2xl p-8 relative overflow-hidden"
               onClick={(e) => e.stopPropagation()}
            >
               <button onClick={() => setSelectedStat(null)} className="absolute top-6 right-6 p-2 bg-gray-50 hover:bg-gray-100 rounded-2xl transition-all">
                  <XCircle className="w-6 h-6 text-gray-400" />
               </button>
               
               <div className="text-center mb-8 pt-4">
                  <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 border-b border-gray-100 pb-2 inline-block">{t.pyme_view.messages.analysis_title}</p>
                  <h3 className="text-2xl font-black text-dark">{selectedStat}</h3>
               </div>

               {selectedStat === t.pyme_view.stats.received_cfdi && (
                  <div className="space-y-4">
                     <p className="text-sm font-bold text-gray-500 text-center mb-6">{t.pyme_view.messages.cfdi_info}</p>
                     <div className="flex justify-between items-center p-4 bg-gray-50 rounded-2xl">
                        <span className="text-xs font-bold text-gray-400 uppercase">{t.pyme_view.messages.validated}</span>
                        <span className="text-sm font-black text-dark">30</span>
                     </div>
                     <div className="flex justify-between items-center p-4 bg-gray-50 rounded-2xl">
                        <span className="text-xs font-bold text-gray-400 uppercase">{t.pyme_view.messages.in_review}</span>
                        <span className="text-sm font-black text-amber-500">3</span>
                     </div>
                     <div className="flex justify-between items-center p-4 bg-gray-50 rounded-2xl">
                        <span className="text-xs font-bold text-gray-400 uppercase">{t.pyme_view.messages.rejected}</span>
                        <span className="text-sm font-black text-red-500">1</span>
                     </div>
                  </div>
               )}
               {selectedStat === t.pyme_view.stats.active_providers && (
                  <div className="space-y-4">
                    <p className="text-sm font-bold text-gray-500 text-center mb-6">{t.pyme_view.messages.prov_history}</p>
                    <div className="space-y-3">
                       <div className="flex items-center gap-3 bg-gray-50 p-4 rounded-2xl">
                          <div className="w-2 h-2 rounded-full bg-green-500" />
                          <span className="text-xs font-black text-dark flex-1">{t.pyme_view.messages.sat_compliant}</span>
                          <span className="text-xs font-bold text-gray-400">10</span>
                       </div>
                       <div className="flex items-center gap-3 bg-gray-50 p-4 rounded-2xl">
                          <div className="w-2 h-2 rounded-full bg-red-500" />
                          <span className="text-xs font-black text-dark flex-1">{t.pyme_view.messages.black_list}</span>
                          <span className="text-xs font-bold text-gray-400">2</span>
                       </div>
                    </div>
                  </div>
               )}
               {selectedStat === t.pyme_view.stats.deductible && (
                  <div className="space-y-4">
                    <p className="text-sm font-bold text-gray-500 text-center mb-6">{t.pyme_view.messages.annual_projection}</p>
                    <div className="bg-blue-50 border border-blue-100 p-6 rounded-[2rem] text-center">
                       <TrendingUp className="w-8 h-8 text-blue-500 mx-auto mb-3" />
                       <h4 className="text-3xl font-black text-blue-900 mb-1">$182,400</h4>
                       <p className="text-[10px] font-black text-blue-500 uppercase tracking-widest">{t.pyme_view.messages.accumulated}</p>
                    </div>
                    <p className="text-xs text-gray-400 font-medium text-center mt-4">
                      {t.pyme_view.messages.isr_validated}
                    </p>
                  </div>
               )}
               {selectedStat === t.pyme_view.stats.sat_alerts && (
                  <div className="space-y-4">
                     <p className="text-sm font-bold text-gray-500 text-center mb-6">{t.pyme_view.messages.fiscal_risk_notif}</p>
                     <div className="bg-red-50 p-4 rounded-2xl text-red-800 border border-red-100 text-sm">
                        <span className="font-bold flex items-center gap-2 mb-1"><ShieldAlert className="w-4 h-4" /> {t.pyme_view.messages.non_deductible}</span>
                        {t.pyme_view.messages.missing_cfdi}
                     </div>
                     <div className="bg-amber-50 p-4 rounded-2xl text-amber-800 border border-amber-100 text-sm mt-3">
                        <span className="font-bold flex items-center gap-2 mb-1"><AlertCircle className="w-4 h-4" /> {t.pyme_view.messages.iva_withholding}</span>
                        {t.pyme_view.messages.verify_retention}
                     </div>
                  </div>
               )}
               {selectedStat === 'No Deducibles' && (
                  <div className="space-y-4">
                    <p className="text-sm font-bold text-gray-500 text-center mb-6">{t.pyme_view.messages.fiscal_risk_projection}</p>
                    <div className="bg-amber-50 border border-amber-100 p-6 rounded-[2rem] text-center">
                       <ShieldAlert className="w-8 h-8 text-amber-500 mx-auto mb-3" />
                       <h4 className="text-3xl font-black text-amber-900 mb-1">$24,600</h4>
                       <p className="text-[10px] font-black text-amber-500 uppercase tracking-widest">{t.pyme_view.messages.fiscal_risk_label}</p>
                    </div>
                    <p className="text-xs text-gray-500 text-center mt-4 bg-gray-50 p-4 rounded-xl font-medium">
                      {t.pyme_view.messages.risk_explanation}
                    </p>
                  </div>
               )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 2 COLS */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          <div className="bg-white rounded-[2.5rem] shadow-sm border border-gray-100 overflow-hidden flex flex-col">
            <div className="p-6 border-b border-gray-100 bg-gray-50/50 flex justify-between items-center">
              <h3 className="font-black text-dark text-sm uppercase tracking-widest">{t.pyme_view.sections.critical_providers}</h3>
              <button 
                onClick={() => setCurrentView('proveedores')}
                className="text-[10px] font-black text-secondary uppercase tracking-widest hover:underline"
              >
                {t.pyme_view.sections.go_to_directory}
              </button>
            </div>
            <div className="flex-1 p-6 space-y-4">
              {[
                { name: 'Papelería Lozano SA de CV', amount: '$3,400', pending: 2, statusKey: 'completed' },
                { name: 'Consultoría IT Services', amount: '$28,000', pending: 1, statusKey: 'completed' },
                { name: 'Gasolinera Aeropuerto', amount: '$4,100', pending: 3, statusKey: 'problematic' },
              ].map((prov, i) => (
                <div key={i} className="flex justify-between items-center p-4 hover:bg-gray-50 rounded-2xl transition-colors border border-gray-50 shadow-sm">
                  <div>
                    <h4 className="font-bold text-dark text-sm">{prov.name}</h4>
                    <p className="text-[10px] text-gray-500 font-black uppercase tracking-widest mt-1">{t.pyme_view.emit.amount || 'Monto'}: {prov.amount} · {prov.pending} {t.nav.invoices.toLowerCase()}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className={`text-[8px] font-black uppercase px-2 py-0.5 rounded-md ${prov.statusKey === 'completed' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                      {t.common.statuses[prov.statusKey]}
                    </span>
                    <button onClick={() => setCurrentView('proveedores')} className="p-2 bg-gray-50 text-gray-400 hover:text-dark hover:bg-white rounded-lg transition-all border border-transparent hover:border-gray-100 shadow-sm">
                      <ArrowRight className="w-4 h-4"/>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-[2.5rem] shadow-sm border border-gray-100 overflow-hidden flex flex-col">
            <div className="p-6 border-b border-gray-100 bg-gray-50/50 flex justify-between items-center">
              <h3 className="font-black text-dark text-sm uppercase tracking-widest">{t.pyme_view.sections.reconciliation_title}</h3>
              <button 
                onClick={() => setCurrentView('conciliacion')}
                className="text-[10px] font-black text-tertiary uppercase tracking-widest hover:underline"
              >
                {t.pyme_view.sections.view_detail}
              </button>
            </div>
            <div className="p-7 flex flex-col gap-6 flex-1">
              <div className="bg-red-50 border border-red-100 text-red-700 p-5 rounded-2xl text-sm flex gap-4 items-start shadow-sm">
                <ShieldAlert className="w-6 h-6 shrink-0 text-red-500 animate-pulse" />
                <div>
                  <h4 className="font-black mb-1 text-red-900">{t.pyme_view.messages.inconsistencies_title || '3 Inconsistencias graves'}</h4>
                  <p className="text-xs opacity-80 leading-relaxed">{t.pyme_view.messages.inconsistencies_desc || 'Se encontraron egresos bancarios sin CFDI asociado.'}</p>
                </div>
              </div>

              <div className="mt-auto">
                <div className="flex justify-between items-end mb-3">
                  <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{t.pyme_view.messages.monthly_progress || 'Avance del mes'}</span>
                  <span className="text-xl font-black text-tertiary">83%</span>
                </div>
                <div className="h-4 w-full bg-gray-100 rounded-full overflow-hidden border border-gray-50">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: '83%' }}
                    className="h-full bg-tertiary rounded-full"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* BOTTOM PANEL */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
          <div onClick={() => setSelectedStat(t.pyme_view.stats.deductible)} className="cursor-pointer bg-white border border-gray-100 rounded-[2.5rem] p-8 shadow-sm flex flex-col justify-between hover:shadow-xl hover:-translate-y-1 transition-all group">
            <div>
              <p className="text-[10px] text-gray-400 uppercase tracking-[0.2em] font-black mb-3">{t.pyme_view.stats.deductible}</p>
              <p className="text-4xl font-black text-dark">$182,400 <span className="text-lg text-gray-300">MXN</span></p>
            </div>
            <div className="mt-8 flex justify-between items-center">
               <span className="text-xs font-bold text-gray-400">{t.pyme_view.messages.accumulated_month || 'Acumulado Mes'}</span>
               <div className="p-2 bg-gray-50 rounded-xl group-hover:bg-tertiary group-hover:text-white transition-colors">
                  <TrendingUp className="w-5 h-5" />
               </div>
            </div>
          </div>

          <div onClick={() => setSelectedStat('No Deducibles')} className="cursor-pointer bg-white border border-gray-100 rounded-[2.5rem] p-8 shadow-sm flex flex-col justify-between hover:shadow-xl hover:-translate-y-1 transition-all group">
            <div>
              <p className="text-[10px] text-gray-400 uppercase tracking-[0.2em] font-black mb-3">{t.pyme_view.stats.non_deductible || 'No Deducibles'}</p>
              <p className="text-4xl font-black text-amber-500">$24,600 <span className="text-lg text-gray-300">MXN</span></p>
            </div>
            <div className="mt-8 flex justify-between items-center">
               <span className="text-xs font-bold text-gray-400">{t.pyme_view.messages.fiscal_risk_label || 'Riesgo Fiscal'}</span>
               <div className="p-2 bg-amber-50 rounded-xl group-hover:bg-amber-500 group-hover:text-white transition-colors text-amber-500">
                  <ShieldAlert className="w-5 h-5" />
               </div>
            </div>
          </div>

          <motion.button 
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setCurrentView('alertas')}
            className="bg-red-500 text-white rounded-[2.5rem] p-8 shadow-2xl shadow-red-500/20 flex flex-col justify-between text-left group border-4 border-white"
          >
            <div className="flex justify-between items-start">
              <div>
                <p className="text-[10px] text-white/60 uppercase tracking-[0.2em] font-black mb-3">{t.pyme_view.sections.inconsistencies}</p>
                <p className="text-4xl font-black">2 <span className="text-lg text-white/40 italic">Activas</span></p>
              </div>
              <div className="bg-white/20 p-3 rounded-2xl backdrop-blur-md animate-bounce">
                 <AlertCircle className="w-6 h-6" />
              </div>
            </div>
            <div className="mt-8 flex justify-between items-center">
               <span className="text-xs font-black uppercase tracking-widest bg-white/20 px-3 py-1.5 rounded-xl">{t.pyme_view.actions.resolve_now}</span>
               <ArrowRight className="w-6 h-6 group-hover:translate-x-2 transition-transform" />
            </div>
          </motion.button>
        </div>

        {/* FINANCIAL CHARTS */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Comparativo Mensual */}
          <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-gray-100 flex flex-col">
            <div className="flex justify-between items-center mb-8">
              <div>
                <h3 className="text-sm font-black text-dark uppercase tracking-widest">{t.pyme_view.sections.financial_comparison}</h3>
                <p className="text-[10px] text-gray-400 font-bold mt-1">Ingresos vs Egresos vs Impuestos</p>
              </div>
              <div className="flex bg-gray-50 p-1 rounded-xl">
                 {['3M', '6M', '12M'].map((t) => (
                   <button 
                     key={t} 
                     onClick={() => setChartTimeframe(t as '3M' | '6M' | '12M')}
                     className={`px-4 py-1.5 rounded-lg text-[10px] font-black tracking-widest uppercase transition-all ${t === chartTimeframe ? 'bg-white shadow-sm text-dark' : 'text-gray-400 hover:text-dark'}`}
                   >
                     {t}
                   </button>
                 ))}
              </div>
            </div>
            
            <div className="h-64 mt-auto">
              <ResponsiveContainer width="100%" height="100%" minWidth={1} minHeight={1}>
                <BarChart data={chartData[chartTimeframe]}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 10, fontWeight: 900, fill: '#9CA3AF' }} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fontWeight: 900, fill: '#9CA3AF' }} tickFormatter={(v) => `$${v / 1000}k`} />
                  <Tooltip 
                    cursor={{ fill: '#F9FAFB' }}
                    contentStyle={{ borderRadius: '1rem', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)', fontSize: '10px', fontWeight: '900' }}
                  />
                  <Bar dataKey="ingresos" fill="#10B981" radius={[4, 4, 0, 0]} name={t.pyme_view.stats.income || 'Ingresos'} />
                  <Bar dataKey="egresos" fill="#F59E0B" radius={[4, 4, 0, 0]} name={t.pyme_view.stats.deductible || 'Egresos'} />
                  <Bar dataKey="impuestos" fill="#FCA5A5" radius={[4, 4, 0, 0]} name={t.pyme_view.stats.sat_alerts || 'Impuestos'} />
                </BarChart>
              </ResponsiveContainer>
            </div>
            
            <div className="mt-6 pt-6 border-t border-gray-50 flex gap-6">
               <div className="flex items-center gap-2">
                 <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                 <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest">{t.pyme_view.stats.income || 'Ingresos'}</span>
               </div>
               <div className="flex items-center gap-2">
                 <div className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                 <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest">{t.pyme_view.stats.deductible || 'Egresos'}</span>
               </div>
               <div className="flex items-center gap-2">
                 <div className="w-2.5 h-2.5 rounded-full bg-red-300" />
                 <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest">{t.pyme_view.stats.sat_alerts || 'Impuestos'}</span>
               </div>
            </div>
          </div>

          {/* Distribución de Gastos */}
          <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-gray-100 flex flex-col">
            <div className="flex justify-between items-center mb-8">
              <div>
                <h3 className="text-sm font-black text-dark uppercase tracking-widest">{t.pyme_view.sections.expense_distribution}</h3>
                <p className="text-[10px] text-gray-400 font-bold mt-1">{t.pyme_view.messages.expense_categories_title || 'Categorías de Egresos CFDI'}</p>
              </div>
              <button onClick={() => showToast('Generando plantilla de reporte de gastos...')} className="p-2 bg-gray-50 hover:bg-gray-100 rounded-xl transition-colors">
                 <PieIcon className="w-5 h-5 text-dark" />
              </button>
            </div>

            <div className="flex-1 flex flex-col md:flex-row items-center gap-8">
              <div className="w-48 h-48">
                <ResponsiveContainer width="100%" height="100%" minWidth={1} minHeight={1}>
                  <PieChart>
                    <Pie
                      data={[
                        { name: t.pyme_view.messages.services || 'Servicios', value: 35, color: '#10B981' },
                        { name: t.pyme_view.messages.goods || 'Bienes', value: 28, color: '#F59E0B' },
                        { name: t.pyme_view.messages.fees || 'Honorarios', value: 20, color: '#3B82F6' },
                        { name: t.pyme_view.messages.rent || 'Arrendamiento', value: 12, color: '#8B5CF6' },
                        { name: t.pyme_view.messages.others || 'Otros', value: 5, color: '#9CA3AF' },
                      ]}
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {[
                        { name: t.pyme_view.messages.services || 'Servicios', value: 35, color: '#10B981' },
                        { name: t.pyme_view.messages.goods || 'Bienes', value: 28, color: '#F59E0B' },
                        { name: t.pyme_view.messages.fees || 'Honorarios', value: 20, color: '#3B82F6' },
                        { name: t.pyme_view.messages.rent || 'Arrendamiento', value: 12, color: '#8B5CF6' },
                        { name: t.pyme_view.messages.others || 'Otros', value: 5, color: '#9CA3AF' },
                      ].map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>

              <div className="flex-1 space-y-4 w-full">
                {[
                  { name: t.pyme_view.messages.services || 'Servicios', percentage: '35%', color: 'bg-emerald-500' },
                  { name: t.pyme_view.messages.goods || 'Bienes', percentage: '28%', color: 'bg-amber-500' },
                  { name: t.pyme_view.messages.fees || 'Honorarios', percentage: '20%', color: 'bg-blue-500' },
                  { name: t.pyme_view.messages.rent || 'Arrendamiento', percentage: '12%', color: 'bg-violet-500' },
                  { name: t.pyme_view.messages.others || 'Otros', percentage: '5%', color: 'bg-gray-400' },
                ].map((cat, i) => (
                  <div key={i} className="flex items-center justify-between group">
                    <div className="flex items-center gap-3">
                      <div className={`w-2.5 h-2.5 rounded-full ${cat.color}`} />
                      <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest group-hover:text-dark transition-colors">{cat.name}</span>
                    </div>
                    <span className="text-xs font-black text-dark">{cat.percentage}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

    </div>
  );
}

function PYMEProveedores() {
  const { showToast, t } = useAppContext();
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedProvider, setSelectedProvider] = useState<any | null>(null);
  const [showContactModal, setShowContactModal] = useState<any | null>(null);
  
  const [provs, setProvs] = useState([
    { 
      id: 1, 
      name: 'Papelería Lozano SA de CV', 
      rfc: 'PLO920315K82', 
      regimen: '601 - General de Ley Personas Morales',
      cp: '64000',
      email: 'facturacion@lozano.mx',
      phone: '81 1234 5678',
      type: 'Bienes',
      credit: 'Contado',
      contact: { name: 'Ana Lozano', wa: '8112345678', email: 'ana@lozano.mx' },
      compliance: 'Cumplido',
      health: 92,
      totalYear: '$45,200',
      history: [
        { date: '15/10/2025', amount: '$3,400', status: '✓ Válida' },
        { date: '12/09/2025', amount: '$5,100', status: '✓ Válida' },
      ]
    },
    { 
      id: 2, 
      name: 'Consultoría IT Services', 
      rfc: 'ITS150822T34', 
      regimen: '601 - General de Ley Personas Morales',
      cp: '06700',
      email: 'admin@itservices.com',
      phone: '55 9876 5432',
      type: 'Servicios',
      credit: '30 días',
      contact: { name: 'Roberto Torres', wa: '5598765432', email: 'r.torres@itservices.com' },
      compliance: 'Cumplido',
      health: 100,
      totalYear: '$128,000',
      history: [
        { date: '20/10/2025', amount: '$28,000', status: '✓ Válida' },
      ]
    },
    { 
      id: 3, 
      name: 'Gasolinera Aeropuerto', 
      rfc: 'GAE081102B91', 
      regimen: '601 - General de Ley Personas Morales',
      cp: '15620',
      email: 'tickets@gas-aero.mx',
      phone: '55 1122 3344',
      type: 'Bienes',
      credit: 'Contado',
      contact: { name: 'Soporte', wa: '5511223344', email: 'soporte@gas-aero.mx' },
      compliance: 'Problemático',
      health: 65,
      totalYear: '$18,500',
      history: [
        { date: '18/10/2025', amount: '$1,200', status: '⚠ Revisar' },
        { date: '05/10/2025', amount: '$4,100', status: '✗ Rechazada' },
      ]
    }
  ]);

  const [editingProviderData, setEditingProviderData] = useState<any | null>(null);

  const handleDeleteProv = (id: number) => {
    setProvs(provs.filter(p => p.id !== id));
    showToast(t.pyme_view.providers.delete_success || "✓ Proveedor eliminado exitosamente");
  };

  const handleSaveProvider = (newProv: any) => {
    if (editingProviderData) {
      setProvs(provs.map(p => p.id === editingProviderData.id ? { ...p, ...newProv } : p));
      showToast(t.pyme_view.providers.update_success || "✓ Proveedor actualizado");
    } else {
      setProvs([{
        ...newProv,
        id: provs.length + 1,
        compliance: 'Cumplido', // Automatically valid for the demo
        health: 100,
        totalYear: '$0',
        history: []
      }, ...provs]);
      showToast(t.pyme_view.providers.save_success || "✓ Proveedor guardado");
      setTimeout(() => {
        alert(t.pyme_view.providers.validation_alert || "⚠ Asegúrate de validar el RFC en el portal del SAT antes de realizar pagos.\n\n⚠ Solicita la Constancia de Situación Fiscal actualizada del proveedor para emitir CFDI 4.0 sin errores.");
      }, 500);
    }
    setShowAddModal(false);
    setEditingProviderData(null);
  };

  return (
    <div className="space-y-6">
      {/* Header con botón Agregar */}
      <div className="flex justify-between items-center bg-white p-6 rounded-[2rem] shadow-sm border border-gray-100">
        <div>
          <h2 className="text-2xl font-black text-dark">{t.pyme_view.sections.prov_dir_title}</h2>
          <p className="text-xs text-gray-400 font-medium tracking-tight">{t.pyme_view.sections.prov_dir_subtitle}</p>
        </div>
        <button 
          onClick={() => setShowAddModal(true)}
          className="bg-secondary hover:bg-secondary-dark text-white px-8 py-3.5 rounded-2xl font-black transition-all flex items-center gap-2.5 shadow-xl shadow-secondary/30 active:scale-95"
        >
          <Plus className="w-5 h-5" /> 
          <span>{t.pyme_view.sections.add_prov_btn}</span>
        </button>
      </div>

      {/* Grid de Proveedores */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {provs.map((prov) => (
          <motion.div 
            key={prov.id}
            whileHover={{ y: -5 }}
            className="bg-white rounded-[2.5rem] p-6 shadow-sm border border-gray-100 flex flex-col hover:shadow-xl transition-all h-full"
          >
            <div className="flex justify-between items-start mb-4">
              <div className="bg-gray-50 p-3 rounded-2xl">
                <Building className="w-6 h-6 text-dark" />
              </div>
              <div className="flex items-center gap-2">
                <span className={`text-[9px] font-black uppercase px-2.5 py-1 rounded-lg ${
                  prov.compliance === 'Cumplido' ? 'bg-green-100 text-green-700' :
                  prov.compliance === 'Tardío' ? 'bg-amber-100 text-amber-700' :
                  'bg-red-100 text-red-700'
                }`}>
                  {prov.compliance}
                </span>
                <button 
                   onClick={(e) => { e.stopPropagation(); setEditingProviderData(prov); setShowAddModal(true); }}
                   className="p-1.5 bg-gray-50 hover:bg-gray-100 rounded-lg text-gray-400 hover:text-dark transition-colors"
                >
                   <Pencil className="w-4 h-4" />
                </button>
                <button 
                  onClick={(e) => { e.stopPropagation(); handleDeleteProv(prov.id); }}
                  className="p-1.5 bg-red-50 hover:bg-red-100 rounded-lg text-red-400 hover:text-red-600 transition-colors"
                >
                   <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
            
            <div className="flex-1">
              <h3 className="font-bold text-dark text-lg leading-snug mb-1 line-clamp-2">{prov.name}</h3>
              <p className="text-xs text-gray-400 font-black tracking-widest uppercase mb-4">{prov.rfc}</p>
              
              <div className="space-y-2 mb-6">
                <div className="flex items-center gap-2 text-xs text-gray-500">
                  <Receipt className="w-3.5 h-3.5" />
                  <span>{prov.type} · {prov.credit}</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-gray-500">
                  <Activity className="w-3.5 h-3.5" />
                  <span className="font-bold">{t.pyme_view.messages.fiscal_health}: {prov.health}%</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 mt-auto">
              <button 
                onClick={() => setSelectedProvider(prov)}
                className="py-3 px-4 bg-gray-50 hover:bg-gray-100 text-dark rounded-xl text-xs font-bold transition-all border border-gray-100"
              >
                {t.pyme_view.providers.view_profile}
              </button>
              <button 
                onClick={() => setShowContactModal(prov)}
                className="py-3 px-4 bg-dark hover:bg-black text-white rounded-xl text-xs font-bold transition-all shadow-lg shadow-dark/10"
              >
                {t.pyme_view.providers.contact_btn}
              </button>
            </div>
          </motion.div>
        ))}
      </div>

      <AnimatePresence>
        {showAddModal && <AddProviderModal initialData={editingProviderData} onClose={() => { setShowAddModal(false); setEditingProviderData(null); }} onSave={handleSaveProvider} />}
        
        {selectedProvider && <ProviderProfileModal provider={selectedProvider} onClose={() => setSelectedProvider(null)} onContact={() => {
          setShowContactModal(selectedProvider);
          setSelectedProvider(null);
        }} />}

        {showContactModal && <ContactProviderModal provider={showContactModal} onClose={() => setShowContactModal(null)} />}
      </AnimatePresence>
    </div>
  );
}

function AddProviderModal({ onClose, onSave, initialData }: { onClose: () => void, onSave: (provData: any) => void, initialData?: any }) {
  const { t } = useAppContext();
  const [formData, setFormData] = useState({
    name: initialData?.name || '',
    rfc: initialData?.rfc || '',
    cp: initialData?.cp || '',
    regimen: initialData?.regimen?.split(' ')[0] || '',
    type: initialData?.type || 'Bienes',
    credit: initialData?.credit || 'Contado',
    contactName: initialData?.contact?.name || '',
    contactWa: initialData?.contact?.wa || '',
    contactEmail: initialData?.contact?.email || ''
  });

  return (
    <div className="fixed inset-0 z-[350] bg-dark/60 backdrop-blur-md flex items-center justify-center p-4" onClick={onClose}>
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white w-full max-w-2xl rounded-[3rem] shadow-2xl p-8 overflow-y-auto max-h-[90vh]"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center gap-4">
            <div className="bg-secondary/10 p-3 rounded-2xl">
              {initialData ? <Pencil className="w-6 h-6 text-secondary" /> : <Plus className="w-6 h-6 text-secondary" />}
            </div>
            <h2 className="text-2xl font-black text-dark tracking-tight">{initialData ? t.common.edit : t.pyme_view.providers.add_btn}</h2>
          </div>
          <button onClick={onClose} className="text-gray-300 hover:text-dark transition-colors"><XCircle className="w-8 h-8" /></button>
        </div>

        <form className="grid grid-cols-1 md:grid-cols-2 gap-6" onSubmit={(e) => { 
          e.preventDefault(); 
          onSave({
            name: formData.name,
            rfc: formData.rfc,
            regimen: formData.regimen,
            cp: formData.cp,
            type: formData.type,
            credit: formData.credit,
            email: formData.contactEmail,
            phone: formData.contactWa,
            contact: { name: formData.contactName, wa: formData.contactWa, email: formData.contactEmail }
          }); 
        }}>
          <div className="md:col-span-2">
            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-2">{t.pyme_view.providers.modal.fields.name} *</label>
            <input required type="text" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full bg-gray-50 border border-gray-100 rounded-2xl p-4 text-sm font-bold outline-none focus:border-secondary transition-all" placeholder="Ej. Empresa de Servicios S.A. de C.V." />
          </div>
          
          <div>
            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-2">RFC *</label>
            <input required maxLength={13} minLength={12} value={formData.rfc} onChange={e => setFormData({...formData, rfc: e.target.value})} type="text" className="w-full bg-gray-50 border border-gray-100 rounded-2xl p-4 text-sm font-bold outline-none focus:border-secondary transition-all uppercase" placeholder="ABC123456XYZ" />
          </div>

          <div>
            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-2">{t.pyme_view.providers.modal.fields.cp} *</label>
            <input required maxLength={5} value={formData.cp} onChange={e => setFormData({...formData, cp: e.target.value})} type="text" className="w-full bg-gray-50 border border-gray-100 rounded-2xl p-4 text-sm font-bold outline-none focus:border-secondary transition-all" placeholder="64000" />
          </div>

          <div className="md:col-span-2">
            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-2">{t.pyme_view.providers.modal.fields.tax_regime} *</label>
            <select required value={formData.regimen} onChange={e => setFormData({...formData, regimen: e.target.value})} className="w-full bg-gray-50 border border-gray-100 rounded-2xl p-4 text-sm font-bold outline-none focus:border-secondary transition-all">
              <option value="">{t.common.select_option}</option>
              <option value="601">601 - General de Ley Personas Morales</option>
              <option value="626">626 - Régimen Simplificado de Confianza (RESICO PM)</option>
              <option value="603">603 - Personas Morales con Fines no Lucrativos</option>
            </select>
          </div>

          <div>
            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-2">{t.pyme_view.providers.table.spec}</label>
            <select value={formData.type} onChange={e => setFormData({...formData, type: e.target.value})} className="w-full bg-gray-50 border border-gray-100 rounded-2xl p-4 text-sm font-bold outline-none focus:border-secondary transition-all">
              <option value="Bienes">Bienes</option>
              <option value="Servicios">Servicios</option>
              <option value="Honorarios">Honorarios</option>
              <option value="Arrendamiento">Arrendamiento</option>
              <option value="Otro">Otro</option>
            </select>
          </div>

          <div>
            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-2">{t.pyme_view.providers.table.credit}</label>
            <select value={formData.credit} onChange={e => setFormData({...formData, credit: e.target.value})} className="w-full bg-gray-50 border border-gray-100 rounded-2xl p-4 text-sm font-bold outline-none focus:border-secondary transition-all">
              <option value="Contado">Contado</option>
              <option value="15">15 {t.common.days}</option>
              <option value="30">30 {t.common.days}</option>
              <option value="45">45 {t.common.days}</option>
              <option value="60">60 {t.common.days}</option>
            </select>
          </div>

          <div className="md:col-span-2 bg-gray-50/50 p-6 rounded-[2rem] border border-gray-100">
            <h4 className="text-sm font-black text-dark mb-4 border-b border-gray-100 pb-2">{t.pyme_view.providers.modal.fields.billing_contact}</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-[9px] font-black text-gray-400 uppercase mb-1 block">{t.common.name}</label>
                <input type="text" value={formData.contactName} onChange={e => setFormData({...formData, contactName: e.target.value})} className="w-full bg-white border border-gray-100 rounded-xl p-3 text-xs font-bold outline-none focus:border-secondary" />
              </div>
              <div>
                <label className="text-[9px] font-black text-gray-400 uppercase mb-1 block">WhatsApp</label>
                <input type="text" value={formData.contactWa} onChange={e => setFormData({...formData, contactWa: e.target.value})} className="w-full bg-white border border-gray-100 rounded-xl p-3 text-xs font-bold outline-none focus:border-secondary" />
              </div>
              <div className="md:col-span-2">
                <label className="text-[9px] font-black text-gray-400 uppercase mb-1 block">{t.common.email}</label>
                <input type="email" value={formData.contactEmail} onChange={e => setFormData({...formData, contactEmail: e.target.value})} className="w-full bg-white border border-gray-100 rounded-xl p-3 text-xs font-bold outline-none focus:border-secondary" />
              </div>
            </div>
          </div>

          <button type="submit" className="md:col-span-2 bg-secondary text-white py-5 rounded-2xl font-black shadow-xl shadow-secondary/20 hover:bg-secondary-dark transition-all mt-4">
            {t.common.save}
          </button>
        </form>
      </motion.div>
    </div>
  );
}

function HistoryRow({ op, provider }: { op: any, provider?: any, key?: any }) {
  const [expanded, setExpanded] = useState(false);
  const [showPDF, setShowPDF] = useState(false);
  const { showToast, t } = useAppContext();
  
  // Create deterministic-looking pseudo-random data based on date & amount so it doesn't change on re-renders, but looks unique
  const uuidStatic = `UUID-${op.date.replace(/\//g,'')}-${op.amount.replace(/\D/g, '')}`;
  const amountNumeric = parseFloat(op.amount.replace(/[^0-9.-]+/g,"")) || 0;
  const subtotal = (amountNumeric / 1.16).toFixed(2);
  const iva = (amountNumeric - (amountNumeric / 1.16)).toFixed(2);
  const concepto = provider?.type === 'Servicios' ? t.pyme_view.messages.professional_services_payment || 'Pago por servicios profesionales' : t.pyme_view.messages.goods_acquisition || 'Adquisición de bienes / insumos';

  return (
    <div className="flex flex-col bg-gray-50/50 p-6 rounded-[2rem] border border-gray-100 hover:bg-white hover:shadow-lg transition-all group overflow-visible relative">
      <div 
         className="flex justify-between items-center cursor-pointer"
         onClick={() => { setExpanded(!expanded); setShowPDF(false); }}
      >
        <div className="flex items-center gap-5">
          <div className="bg-white p-3 rounded-2xl shadow-sm text-dark group-hover:bg-dark group-hover:text-white transition-colors">
            <Receipt className="w-5 h-5" />
          </div>
          <div>
            <p className="font-black text-dark">{op.amount}</p>
            <p className="text-xs text-gray-400 font-bold uppercase tracking-widest">{op.date}</p>
          </div>
        </div>
        <div className="flex items-center gap-6">
           <span className={`text-[10px] font-black uppercase ${op.status.includes('✓') ? 'text-green-600' : op.status.includes('⚠') ? 'text-amber-600' : 'text-red-600'}`}>{op.status}</span>
           <button 
             onClick={(e) => { e.stopPropagation(); setExpanded(!expanded); setShowPDF(false); }} 
             className={`bg-white p-2 rounded-xl border border-gray-100 shadow-sm transition-all ${expanded ? 'text-dark bg-gray-50' : 'text-gray-400 hover:text-dark'}`}
           >
             <Eye className="w-5 h-5"/>
           </button>
        </div>
      </div>
      <AnimatePresence>
        {expanded && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }} 
            animate={{ height: 'auto', opacity: 1 }} 
            exit={{ height: 0, opacity: 0 }} 
            className="overflow-hidden mt-6"
          >
             <div className="bg-white p-4 rounded-xl border border-gray-100 flex flex-col items-start gap-4">
                <div className="w-full flex justify-between items-center">
                  <div>
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">UUID</p>
                    <p className="text-xs font-mono text-gray-500 mt-1 cursor-pointer hover:text-secondary transition-colors" onClick={() => showToast(t.pyme_view.messages.uuid_copied)}>{uuidStatic}</p>
                  </div>
                  <button onClick={() => setShowPDF(!showPDF)} className="px-4 py-2 bg-gray-50 hover:bg-gray-100 hover:text-dark text-gray-500 rounded-lg text-xs font-bold transition-all border border-gray-100">
                    {showPDF ? t.pyme_view.providers.modal.profile.hide_details : t.pyme_view.providers.modal.profile.view_details}
                  </button>
                </div>
                
                {showPDF && (
                   <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="w-full bg-gray-50 rounded-xl p-4 border border-gray-200 mt-2 text-sm text-dark space-y-3">
                     <div className="flex justify-between border-b border-gray-200 pb-2">
                        <span className="font-bold text-gray-500 text-xs">{t.pyme_view.providers.modal.profile.concept}</span>
                        <span className="font-medium text-xs text-right break-words max-w-[200px]">{concepto}</span>
                     </div>
                     <div className="flex justify-between border-b border-gray-200 pb-2">
                        <span className="font-bold text-gray-500 text-xs">{t.cfdi_viewer.subtotal}</span>
                        <span className="font-medium text-xs">$ {subtotal}</span>
                     </div>
                     <div className="flex justify-between border-b border-gray-200 pb-2">
                        <span className="font-bold text-gray-500 text-xs">{t.cfdi_viewer.tax}</span>
                        <span className="font-medium text-xs">$ {iva}</span>
                     </div>
                     <div className="flex justify-between pt-1">
                        <span className="font-black text-dark text-xs">{t.cfdi_viewer.total}</span>
                        <span className="font-black text-xs">{op.amount}</span>
                     </div>
                   </motion.div>
                 )}
             </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function CFDIRow({ v }: { v: number, key?: any }) {
  const { t } = useAppContext();
  const [expanded, setExpanded] = useState(false);
  
  return (
    <div className="bg-gray-50 p-4 rounded-xl flex flex-col transition-colors border border-transparent hover:border-gray-200">
       <div className="flex justify-between items-center cursor-pointer" onClick={() => setExpanded(!expanded)}>
         <div className="flex items-center gap-4">
           <div className={`p-2 rounded-lg shadow-sm border ${expanded ? 'bg-secondary text-white border-secondary' : 'bg-white border-gray-100 text-gray-400'}`}>
             <FileText className="w-5 h-5" />
           </div>
           <div>
             <p className="text-sm font-bold text-dark">{t.pyme_view.emitir.invoice} F-{800 + v}</p>
             <p className="text-[10px] text-gray-400 font-black uppercase tracking-widest">{t.pyme_view.emitir.emission_date}: {v}/10/2025</p>
           </div>
         </div>
         <button onClick={(e) => { e.stopPropagation(); setExpanded(!expanded); }} className={`px-3 py-1.5 font-bold text-xs rounded-lg shadow-sm transition ${expanded ? 'bg-dark text-white' : 'bg-white border border-gray-200 text-gray-600 hover:shadow-md'}`}>
           {expanded ? t.common.hide : 'XML/PDF'}
         </button>
       </div>
       <AnimatePresence>
         {expanded && (
            <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden">
               <div className="mt-4 pt-4 border-t border-gray-200 text-sm text-dark space-y-3 px-2">
                 <div className="flex justify-between border-b border-gray-200 pb-2">
                    <span className="font-bold text-gray-500 text-xs">{t.pyme_view.providers.modal?.profile?.concept || 'Concepto'}</span>
                    <span className="font-medium text-xs text-right">{t.pyme_view.emitir.lot_supplies || 'Lote de suministros'}<br/>{t.common.month_oct || 'Mes Octubre'}</span>
                 </div>
                 <div className="flex justify-between border-b border-gray-200 pb-2">
                    <span className="font-bold text-gray-500 text-xs">{t.cfdi_viewer.subtotal}</span>
                    <span className="font-medium text-xs">$ {(1500 * v).toFixed(2)}</span>
                 </div>
                 <div className="flex justify-between border-b border-gray-200 pb-2">
                    <span className="font-bold text-gray-500 text-xs">{t.cfdi_viewer.tax}</span>
                    <span className="font-medium text-xs">$ {(1500 * v * 0.16).toFixed(2)}</span>
                 </div>
                 <div className="flex justify-between pt-1">
                    <span className="font-black text-dark text-xs">{t.cfdi_viewer.total}</span>
                    <span className="font-black text-xs">$ {(1500 * v * 1.16).toFixed(2)}</span>
                 </div>
                 <div className="pt-2 flex justify-end gap-2">
                    <button className="px-3 py-2 bg-gray-200 hover:bg-gray-300 rounded-lg text-xs font-bold text-dark flex items-center gap-2 transition-colors">
                       <Download className="w-3.5 h-3.5" /> {t.pyme_view.emitir.download_pdf}
                    </button>
                    <button className="px-3 py-2 bg-dark hover:bg-black rounded-lg text-xs font-bold text-white flex items-center gap-2 transition-colors">
                       <FileCode className="w-3.5 h-3.5" /> {t.pyme_view.emitir.download_xml}
                    </button>
                 </div>
               </div>
            </motion.div>
         )}
       </AnimatePresence>
    </div>
  );
}

function ProviderProfileModal({ provider, onClose, onContact }: { provider: any, onClose: () => void, onContact: () => void }) {
  const { showToast, t } = useAppContext();
  const [isDownloading, setIsDownloading] = useState(false);
  const [isPaying, setIsPaying] = useState(false);
  const [loadingCFDI, setLoadingCFDI] = useState(false);
  const [showCFDIList, setShowCFDIList] = useState(false);
  const [paymentRegistered, setPaymentRegistered] = useState(false);
  const [editContactMode, setEditContactMode] = useState(false);
  const [contactInfo, setContactInfo] = useState(provider.contact);
  const [reportDownloaded, setReportDownloaded] = useState(false);

  const handleDownload = () => {
    setIsDownloading(true);
    setTimeout(() => {
      setIsDownloading(false);
      setReportDownloaded(true);
      setTimeout(() => setReportDownloaded(false), 5000); // Hide the note after 5s
    }, 2000);
  };

  const handlePay = () => {
    if (paymentRegistered) {
      showToast(t.pyme_view.providers.already_paid_alert || '⚠ Este proveedor ya tiene registrado el pago actual.');
      return;
    }
    setIsPaying(true);
    setTimeout(() => {
      setIsPaying(false);
      setPaymentRegistered(true);
      showToast(t.pyme_view.providers.payment_success || '✓ Pago de la última operación encolado; saldo actualizado');
    }, 2000);
  };

  const handleCFDI = () => {
    setLoadingCFDI(true);
    setTimeout(() => {
      setLoadingCFDI(false);
      setShowCFDIList(!showCFDIList);
    }, 800);
  };
  
  return (
    <div className="fixed inset-0 z-[400] bg-dark/60 backdrop-blur-md flex items-center justify-center p-4 lg:p-10" onClick={onClose}>
      <motion.div 
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 50, opacity: 0 }}
        className="bg-white w-full max-w-5xl h-full flex flex-col rounded-[3rem] shadow-2xl overflow-hidden"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-8 border-b border-gray-100 flex justify-between items-start bg-gray-50/30">
          <div className="flex items-center gap-5">
            <div className="bg-white p-4 rounded-[1.5rem] shadow-xl border border-gray-100">
              <Building className="w-8 h-8 text-dark" />
            </div>
            <div>
              <h2 className="text-3xl font-black text-dark leading-tight">{provider.name}</h2>
              <div className="flex items-center gap-3 mt-1">
                <span className="text-[10px] font-black tracking-[0.2em] uppercase text-gray-400">{provider.rfc}</span>
                <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-md ${
                  provider.compliance === 'Cumplido' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                }`}>
                  {provider.compliance}
                </span>
              </div>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-xl transition-colors"><XCircle className="w-8 h-8 text-gray-200" /></button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-8 lg:grid lg:grid-cols-12 lg:gap-10">
          {/* Section A: Datos */}
          <div className="lg:col-span-4 space-y-8">
            <div className="space-y-6">
              <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.3em] border-b border-gray-50 pb-2">{t.pyme_view.providers.modal?.profile?.fiscal_info || 'Información Fiscal'}</h4>
              <div className="space-y-4">
                {[
                  { label: t.pyme_view.providers.modal.fields.regimen, val: provider.regimen },
                  { label: t.pyme_view.providers.modal.fields.cp, val: provider.cp },
                  { label: t.common.type || 'Tipo', val: provider.type },
                  { label: t.pyme_view.providers.table.credit || 'Crédito', val: provider.credit },
                ].map((item, i) => (
                  <div key={i}>
                    <p className="text-[10px] font-black text-gray-300 uppercase mb-0.5">{item.label}</p>
                    <p className="text-sm font-bold text-dark">{item.val}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-gray-50 p-6 rounded-[2rem] border border-gray-100">
               <div className="flex justify-between items-center mb-4">
                 <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{t.pyme_view.providers.modal?.profile?.fiscal_health || 'Salud Fiscal'}</h4>
                 <span className="text-xl font-black text-dark">{provider.health}%</span>
               </div>
               <div className="h-2.5 w-full bg-white rounded-full overflow-hidden mb-3">
                 <div className={`h-full rounded-full transition-all duration-1000 ${
                   provider.health > 80 ? 'bg-green-500' : provider.health > 50 ? 'bg-amber-500' : 'bg-red-500'
                 }`} style={{ width: `${provider.health}%` }}></div>
               </div>
               <p className="text-[10px] text-gray-400 font-medium leading-relaxed">
                 {provider.health}% {t.pyme_view.messages.health_explanation || 'de sus CFDI emitidos a esta empresa han sido validados correctamente.'}
               </p>
            </div>

            <div className="space-y-4">
              <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.3em] border-b border-gray-50 pb-2 flex justify-between items-center">
                <span>{t.pyme_view.providers.modal?.profile?.billing_contact || 'Contacto Facturación'}</span>
                <button onClick={() => {
                  if (editContactMode) {
                    showToast(t.pyme_view.messages.contact_updated || "✓ Datos de contacto actualizados");
                    setEditContactMode(false);
                  } else {
                    setEditContactMode(true);
                  }
                }} className="hover:bg-gray-100 p-1.5 rounded-lg transition-colors">
                   {editContactMode ? <CheckCircle2 className="w-4 h-4 text-green-500" /> : <Pencil className="w-3.5 h-3.5 text-gray-400" />}
                </button>
              </h4>
              <div className="bg-white border border-gray-100 p-5 rounded-2xl shadow-sm space-y-3 relative group">
                {editContactMode ? (
                  <div className="space-y-2">
                    <input type="text" value={contactInfo.name} onChange={e => setContactInfo({...contactInfo, name: e.target.value})} className="w-full bg-gray-50 border border-gray-100 rounded-lg p-2 text-sm font-black outline-none focus:border-secondary" />
                    <div className="flex items-center gap-2">
                      <MessageCircle className="w-4 h-4 text-[#25D366]" />
                      <input type="text" value={contactInfo.wa} onChange={e => setContactInfo({...contactInfo, wa: e.target.value})} className="w-full bg-gray-50 border border-gray-100 rounded-lg p-2 text-xs font-bold outline-none focus:border-secondary" />
                    </div>
                    <div className="flex items-center gap-2">
                      <Mail className="w-4 h-4 text-blue-500" />
                      <input type="email" value={contactInfo.email} onChange={e => setContactInfo({...contactInfo, email: e.target.value})} className="w-full bg-gray-50 border border-gray-100 rounded-lg p-2 text-xs font-bold outline-none focus:border-secondary" />
                    </div>
                  </div>
                ) : (
                  <>
                    <p className="text-sm font-black text-dark">{contactInfo.name}</p>
                    <div className="flex items-center gap-2 text-xs font-bold text-gray-600">
                      <MessageCircle className="w-4 h-4 text-[#25D366]" /> {contactInfo.wa}
                    </div>
                    <div className="flex items-center gap-2 text-xs font-bold text-gray-600">
                      <Mail className="w-4 h-4 text-blue-500" /> {contactInfo.email}
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Section B: Historial / CFDIs */}
          <div className="lg:col-span-8 mt-10 lg:mt-0 space-y-10">
            {showCFDIList ? (
              <div className="bg-white border border-gray-100 rounded-[2.5rem] shadow-sm p-8">
                <div className="flex justify-between items-center mb-6 border-b border-gray-100 pb-4">
                   <div>
                     <h3 className="text-xl font-black text-dark">{t.pyme_view.emitir.invoice_repository || 'Repositorio de CFDI'}</h3>
                     <p className="text-sm text-gray-400 font-bold uppercase tracking-widest mt-1">{t.pyme_view.emitir.active_invoices_viewer || 'Visor de Comprobantes Activos'}</p>
                   </div>
                   <button onClick={() => setShowCFDIList(false)} className="px-4 py-2 bg-gray-50 text-gray-500 font-black rounded-xl text-xs uppercase hover:bg-gray-100 transition">{t.common.back}</button>
                </div>
                <div className="space-y-3 max-h-[500px] overflow-y-auto pr-2">
                  {[1,2,3,4,5].map(v => (
                    <CFDIRow key={v} v={v} />
                  ))}
                </div>
              </div>
            ) : (
              <>
                 <div className="bg-dark rounded-[2.5rem] p-8 text-white relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-bl-[10rem]" />
                    <div className="relative z-10">
                      <p className="text-xs font-black text-white/40 uppercase tracking-[0.3em] mb-2">{t.pyme_view.providers.modal?.profile?.total_operated || 'Total Operado este Año'}</p>
                      <h3 className="text-5xl font-black">{provider.totalYear} <span className="text-2xl text-white/30">MXN</span></h3>
                      <div className="mt-8 flex gap-4">
                        <button onClick={handleCFDI} disabled={loadingCFDI} className="bg-white/10 hover:bg-white/20 text-white px-6 py-3 rounded-xl text-xs font-bold backdrop-blur-xl border border-white/10 transition-all flex items-center justify-center gap-2 min-w-[150px]">
                          {loadingCFDI ? <RefreshCw className="w-4 h-4 animate-spin" /> : (t.pyme_view.emitir.view_all_cfdi || "Ver todos los CFDI")}
                        </button>
                        <button onClick={handleDownload} disabled={isDownloading || reportDownloaded} className={`${reportDownloaded ? 'bg-green-500 text-white border-green-500' : 'bg-white/10 hover:bg-white/20 text-white border-white/10'} px-6 py-3 rounded-xl text-xs font-bold backdrop-blur-xl border transition-all flex items-center justify-center gap-2 min-w-[150px]`}>
                          {isDownloading ? <RefreshCw className="w-4 h-4 animate-spin" /> : reportDownloaded ? <><CheckCircle2 className="w-4 h-4" /> {t.pyme_view.providers.download_success || 'Reporte Descargado'}</> : (t.common.download_report || "Descargar Reporte")}
                        </button>
                      </div>
                    </div>
                 </div>

                <div className="space-y-6">
                  <div className="flex justify-between items-center px-4">
                    <h4 className="font-black text-dark uppercase tracking-widest text-sm">{t.pyme_view.dashboard.recent_activity || 'Historial de Operaciones'}</h4>
                    <div className="flex gap-2">
                      <span className="text-[10px] font-bold bg-green-50 text-green-600 px-3 py-1 rounded-full uppercase tracking-widest">{t.pyme_view.messages.validated || 'Validado'}</span>
                      <span className="text-[10px] font-bold bg-amber-50 text-amber-600 px-3 py-1 rounded-full uppercase tracking-widest">{t.pyme_view.messages.in_review || 'En Revisión'}</span>
                    </div>
                  </div>

                  <div className="space-y-4">
                    {provider.history.map((op: any, i: number) => (
                      <HistoryRow key={i} op={op} provider={provider} />
                    ))}
                  </div>
                </div>

                {/* Section C: Acciones */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-10">
                  <button disabled={isPaying || paymentRegistered} onClick={handlePay} className={`py-4.5 rounded-2xl font-black shadow-xl flex flex-col items-center gap-2 transition-all ${paymentRegistered ? 'bg-green-500 text-white shadow-green-500/20' : 'bg-secondary text-white shadow-secondary/20 hover:scale-105'}`}>
                    {isPaying ? <RefreshCw className="w-6 h-6 animate-spin" /> : paymentRegistered ? <CheckCircle2 className="w-6 h-6" /> : <CreditCard className="w-6 h-6" />}
                    <span>{isPaying ? (t.pyme_view.emit.processing || 'Aprobando...') : paymentRegistered ? (t.pyme_view.providers.payment_success || 'Pago Registrado') : (t.pyme_view.providers.actions.pay || 'Registrar Pago')}</span>
                  </button>
                  <button 
                    onClick={onContact}
                    className="bg-dark text-white py-4.5 rounded-2xl font-black shadow-xl shadow-dark/20 flex flex-col items-center gap-1 hover:scale-105 transition-all"
                  >
                    <MessageCircle className="w-6 h-6" /> <span>{t.pyme_view.providers.actions.request_invoice || 'Solicitar Factura'}</span>
                  </button>
                  <button 
                     onClick={onContact}
                     className="bg-blue-500 text-white py-4.5 rounded-2xl font-black shadow-xl shadow-blue-500/20 flex flex-col items-center gap-1 hover:scale-105 transition-all"
                  >
                    <Phone className="w-6 h-6" /> <span>{t.common.contact || 'Contactar'}</span>
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
}

function ContactProviderModal({ provider, onClose }: { provider: any, onClose: () => void }) {
  const { showToast } = useAppContext();
  const [activeStep, setActiveStep] = useState<'menu' | 'calling' | 'email_preview'>('menu');
  const [timer, setTimer] = useState(0);

  useEffect(() => {
    let interval: any;
    if (activeStep === 'calling') {
      interval = setInterval(() => setTimer(t => t + 1), 1000);
    } else {
      setTimer(0);
    }
    return () => clearInterval(interval);
  }, [activeStep]);

  const formatTime = (s: number) => {
    const mins = Math.floor(s / 60);
    const secs = s % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleAction = (label: string) => {
    showToast(`✓ Acción iniciada: ${label}`);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[500] bg-dark/80 backdrop-blur-xl flex items-center justify-center p-4" onClick={onClose}>
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-white w-full max-w-lg rounded-[3rem] shadow-2xl relative overflow-y-auto max-h-[90vh]"
        onClick={e => e.stopPropagation()}
      >
        {activeStep === 'menu' && (
          <div className="p-8">
            <div className="flex justify-between items-center mb-8">
              <h3 className="text-2xl font-black text-dark tracking-tight">Contactar a {provider.name}</h3>
              <button onClick={onClose} className="text-gray-300 hover:text-dark transition-colors"><XCircle className="w-8 h-8" /></button>
            </div>

            <div className="space-y-8">
              {/* Sección 1: Comercial */}
              <div className="space-y-3">
                <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.3em]">Contacto Comercial</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <button 
                    onClick={() => setActiveStep('calling')}
                    className="flex justify-between items-center bg-blue-50 p-4 rounded-2xl hover:bg-blue-100 transition-all group"
                  >
                    <div className="flex items-center gap-3">
                       <Phone className="w-5 h-5 text-blue-600" />
                       <span className="text-xs font-bold text-blue-900 uppercase">Llamar</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-blue-400 group-hover:translate-x-1 transition-transform" />
                  </button>
                  <button 
                    onClick={() => handleAction("WhatsApp Comercial")}
                    className="flex justify-between items-center bg-[#25D366]/10 p-4 rounded-2xl hover:bg-[#25D366]/20 transition-all group"
                  >
                    <div className="flex items-center gap-3">
                       <MessageCircle className="w-5 h-5 text-[#25D366]" />
                       <span className="text-xs font-bold text-green-900 uppercase">WhatsApp</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-[#25D366]/40 group-hover:translate-x-1 transition-transform" />
                  </button>
                  <button 
                    onClick={() => handleAction("Correo Comercial")}
                    className="flex justify-between items-center bg-gray-50 p-4 rounded-2xl hover:bg-gray-100 transition-all group sm:col-span-2"
                  >
                    <div className="flex items-center gap-3">
                       <Mail className="w-5 h-5 text-dark" />
                       <span className="text-xs font-bold text-dark uppercase">Enviar Correo Comercial</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-gray-400 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>

              {/* Sección 2: Facturación */}
              <div className="space-y-3">
                <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.3em]">Departamento de Facturación</h4>
                <div className="grid grid-cols-1 gap-3">
                  <button 
                    onClick={() => handleAction("WhatsApp Facturación")}
                    className="flex flex-col bg-green-50 p-5 rounded-2xl border border-green-100 hover:border-green-300 transition-all text-left"
                  >
                    <div className="flex items-center gap-3 mb-3">
                       <MessageSquare className="w-5 h-5 text-[#25D366]" />
                       <span className="text-xs font-black text-green-800 uppercase">WhatsApp Regional</span>
                    </div>
                    <p className="text-[11px] text-green-700 italic border-l-2 border-green-200 pl-3">
                      "Buen día {provider.contact.name}, les escribo de MTY Tech Solutions. Solicito CFDI por el pago realizado..."
                    </p>
                  </button>
                  <button 
                    onClick={() => handleAction("Correo Facturación")}
                    className="flex justify-between items-center bg-blue-50/50 p-4 rounded-2xl hover:bg-blue-50 transition-all group"
                  >
                    <div className="flex items-center gap-3">
                       <Mail className="w-5 h-5 text-blue-500" />
                       <span className="text-xs font-bold text-blue-900 uppercase">Correo de Facturación</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-blue-400/40 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>

              {/* Sección 3: Acciones Rápidas */}
              <div className="space-y-3">
                <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.3em]">Gestión Preventiva</h4>
                <div className="grid grid-cols-2 gap-3">
                  <button 
                    onClick={() => handleAction("Agendar Reunión")}
                    className="flex items-center gap-3 bg-dark text-white p-4 rounded-2xl hover:bg-black transition-all"
                  >
                    <Calendar className="w-5 h-5" />
                    <span className="text-[10px] font-black uppercase tracking-widest leading-none">Agendar Cita</span>
                  </button>
                  <button 
                    onClick={() => handleAction("Solicitar Constancia")}
                    className="flex items-center gap-3 bg-gray-100 text-dark p-4 rounded-2xl hover:bg-gray-200 transition-all"
                  >
                    <FileCode className="w-5 h-5" />
                    <span className="text-[10px] font-black uppercase tracking-widest leading-none">Pedir Situación Fiscal</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Simulador de Llamada */}
        {activeStep === 'calling' && (
          <div className="h-full bg-dark text-white p-12 flex flex-col items-center justify-between min-h-[400px]">
             <div className="text-center space-y-4">
                <div className="w-24 h-24 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-6 relative">
                   <Phone className="w-10 h-10 text-white animate-pulse" />
                   <div className="absolute inset-0 border-2 border-white/20 rounded-full animate-ping" />
                </div>
                <h4 className="text-2xl font-bold tracking-tight">{provider.name}</h4>
                <p className="text-blue-400 font-mono text-xl">{formatTime(timer)}</p>
                <p className="text-white/40 text-xs font-black uppercase tracking-[0.3em]">Llamada en curso...</p>
             </div>

             <button 
               onClick={() => { setActiveStep('menu'); showToast("✓ Llamada finalizada"); }}
               className="w-20 h-20 bg-red-500 rounded-full flex items-center justify-center shadow-2xl shadow-red-500/40 hover:scale-110 active:scale-95 transition-all"
             >
                <XCircle className="w-10 h-10" />
             </button>
          </div>
        )}
      </motion.div>
    </div>
  );
}

function PYMEValidacion() {
  const { showToast, t } = useAppContext();
  const [selectedCFDI, setSelectedCFDI] = useState<any | null>(null);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingStep, setProcessingStep] = useState(0);

  const [cfdis, setCfdis] = useState([
    { 
      id: 'C1', 
      uuid: 'A1B2C3D4-E5F6-7890-ABCD-EF1234567890',
      emisor: 'Papelería Lozano SA de CV', 
      emisorRfc: 'PLO920315K82',
      receiver: 'MTY Tech Solutions',
      receiverRfc: 'MTS230415A87',
      date: '15 Oct 2025', 
      amount: '$3,400.00', 
      status: '✓ Válido',
      type: 'G03 - Gastos en general',
      concepts: [
        { desc: 'Hojas Bond Carta 500pzs', qty: 10, unit: 'Paquete', price: 200, total: 2000 },
        { desc: 'Tóner HP Láser 85A', qty: 1, unit: 'Pieza', price: 931.03, total: 931.03 }
      ]
    },
    { 
      id: 'C2', 
      uuid: 'B9C8D7E6-F5A4-4321-DCBA-FE0987654321',
      emisor: 'Consultoría IT Services', 
      emisorRfc: 'ITS150822T34',
      receiver: 'MTY Tech Solutions',
      receiverRfc: 'MTS230415A87',
      date: '20 Oct 2025', 
      amount: '$28,000.00', 
      status: '✓ Válido',
      type: 'G03 - Gastos en general',
      concepts: [
        { desc: 'Asesoría Mensual Octubre', qty: 1, unit: 'Servicio', price: 24137.93, total: 24137.93 }
      ]
    },
    { 
      id: 'C3', 
      uuid: 'D5E4F3G2-H1I0-0987-KJHG-MLKJIHGFEDCB',
      emisor: 'Gasolinera Aeropuerto', 
      emisorRfc: 'GAE081102B91',
      receiver: 'MTY Tech Solutions',
      receiverRfc: 'MTS230415A87',
      date: '18 Oct 2025', 
      amount: '$1,200.00', 
      status: '⚠ Revisar',
      reason: 'Uso de CFDI incorrecto: debería ser G03 en lugar de G01',
      type: 'G01 - Adquisición de mercancías',
      concepts: [
        { desc: 'Gasolina Premium', qty: 50, unit: 'Litro', price: 20.69, total: 1034.48 }
      ]
    },
    { 
      id: 'C4', 
      uuid: 'X1Y2Z3A4-B5C6-D7E8-F9G0-H1I2J3K4L5M6',
      emisor: 'Papelería Lozano SA de CV', 
      emisorRfc: 'PLO920315K82',
      receiver: 'MTY Tech Solutions',
      receiverRfc: 'MTS230415A87',
      date: '05 Oct 2025', 
      amount: '$4,100.00', 
      status: '✗ Rechazado',
      reason: 'El RFC del receptor no coincide con la versión 4.0',
      type: 'G03 - Gastos en general',
      concepts: [
        { desc: 'Artículos de Limpieza', qty: 1, unit: 'Lote', price: 3534.48, total: 3534.48 }
      ]
    },
  ]);

  const processingLogs = [
    t.pyme_view.validation.logs_reading || "⏳ Leyendo archivo XML...",
    t.pyme_view.validation.logs_validating || "⏳ Validando estructura CFDI 4.0...",
    t.pyme_view.validation.logs_checking_rfc || "⏳ Verificando RFC del emisor...",
    t.pyme_view.validation.logs_validating_seal || "⏳ Validando sello digital del SAT...",
    t.pyme_view.validation.logs_reconciling || "⏳ Conciliando con pagos registrados..."
  ];

  const handleUpload = () => {
    setIsProcessing(true);
    setProcessingStep(0);
    
    const interval = setInterval(() => {
      setProcessingStep(prev => {
        if (prev >= processingLogs.length - 1) {
          clearInterval(interval);
          setTimeout(() => {
            setIsProcessing(false);
            setShowUploadModal(false);
            
            // Add new CFDI to the list
            const newCFDI = {
              id: `C${cfdis.length + 1}`,
              uuid: '7F8E9D0A-1B2C-3D4E-5F6G-7H8I9J0K1L2M',
              emisor: t.pyme_view.validation.new_provider_xml || 'Nuevo Proveedor XML', 
              emisorRfc: 'NPX201231ABC',
              receiver: 'MTY Tech Solutions',
              receiverRfc: 'MTS230415A87',
              date: t.pyme_view.validation.today || 'Hoy', 
              amount: '$12,450.00', 
              status: `✓ ${t.pyme_view.providers.modal?.profile?.validated || 'Validado'}`,
              type: 'G03 - Gastos en general',
              concepts: [
                { desc: 'Servicios de Procesamiento Cloud', qty: 1, unit: 'Servicio', price: 10732.75, total: 10732.75 }
              ]
            };
            setCfdis(prevCfdis => [newCFDI, ...prevCfdis]);
            
            showToast(t.pyme_view.validation.success_toast || "✓ CFDI procesado y validado exitosamente");
          }, 1000);
          return prev;
        }
        return prev + 1;
      });
    }, 1000);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white p-7 rounded-[2rem] shadow-sm border border-gray-100 flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-black text-dark">{t.pyme_view.validation.title}</h2>
          <p className="text-xs text-gray-400 font-medium tracking-tight">{t.pyme_view.validation.subtitle}</p>
        </div>
        <div className="flex gap-2">
          <button 
            onClick={() => setShowUploadModal(true)}
            className="bg-secondary text-white px-6 py-3.5 rounded-2xl font-black transition-all flex items-center gap-2.5 shadow-xl shadow-secondary/30 active:scale-95"
          >
            <Plus className="w-5 h-5" /> 
            <span>{t.pyme_view.actions.validate}</span>
          </button>
          <button className="bg-dark hover:bg-black text-white px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-lg shadow-dark/10">
            {t.common.download_report}
          </button>
        </div>
      </div>

      <div className="bg-white rounded-[2rem] shadow-sm border border-gray-100 overflow-hidden">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-gray-50/50 border-b border-gray-50">
              <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">{t.pyme_view.validation.table.folio || 'ID'}</th>
              <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">{t.pyme_view.validation.table.provider || 'Proveedor / Emisor'}</th>
              <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest text-right">{t.pyme_view.validation.table.amount || 'Monto'}</th>
              <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">{t.pyme_view.validation.table.status || 'Estado'}</th>
              <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest text-center">{t.common.actions}</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-50">
            {cfdis.map((cfdi) => (
              <tr key={cfdi.id} className="hover:bg-gray-50/30 transition-colors group">
                <td className="px-6 py-4">
                  <span className="text-xs font-black text-gray-300">{cfdi.id}</span>
                </td>
                <td className="px-6 py-4">
                  <p className="text-sm font-bold text-dark">{cfdi.emisor}</p>
                  <p className="text-[10px] text-gray-400 font-medium">{cfdi.date}</p>
                </td>
                <td className="px-6 py-4 text-right">
                  <p className="text-sm font-black text-dark">{cfdi.amount}</p>
                </td>
                <td className="px-6 py-4">
                  <span className={`text-[10px] font-black uppercase px-2 py-1 rounded-lg ${
                    cfdi.status.includes('Válido') ? 'bg-green-100 text-green-700' :
                    cfdi.status.includes('Revisar') ? 'bg-amber-100 text-amber-700' :
                    'bg-red-100 text-red-700'
                  }`}>
                    {cfdi.status}
                  </span>
                </td>
                <td className="px-6 py-4">
                  <div className="flex justify-center gap-2">
                    <button 
                      onClick={() => setSelectedCFDI(cfdi)}
                      className="p-2 bg-white rounded-xl border border-gray-100 shadow-sm text-gray-400 hover:text-dark transition-all flex items-center gap-2 group-hover:border-dark/20"
                    >
                      <Eye className="w-4 h-4" />
                      <span className="text-[10px] font-black uppercase tracking-widest">{t.pyme_view.providers.modal?.profile?.view_details || 'Ver Detalles'}</span>
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <AnimatePresence>
        {showUploadModal && (
          <div className="fixed inset-0 z-[500] bg-dark/60 backdrop-blur-md flex items-center justify-center p-4" onClick={() => !isProcessing && setShowUploadModal(false)}>
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white w-full max-w-xl rounded-[3rem] shadow-2xl p-10 overflow-hidden"
              onClick={e => e.stopPropagation()}
            >
              {!isProcessing ? (
                <>
                  <div className="text-center mb-8">
                    <div className="bg-secondary/10 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                      <UploadCloud className="w-10 h-10 text-secondary" />
                    </div>
                    <h3 className="text-2xl font-black text-dark tracking-tight">{t.pyme_view.emit.new_btn || 'Cargar Archivos XML'}</h3>
                    <p className="text-sm text-gray-400 font-medium mt-1">{t.pyme_view.emit.subtitle || 'Sube tus comprobantes CFDI 4.0'}</p>
                  </div>

                  <div 
                    onClick={handleUpload}
                    className="border-2 border-dashed border-gray-100 rounded-[2rem] p-12 flex flex-col items-center justify-center bg-gray-50/50 hover:bg-white hover:border-secondary transition-all cursor-pointer group"
                  >
                    <FileCode className="w-12 h-12 text-gray-200 group-hover:text-secondary transition-colors mb-4" />
                    <p className="text-sm font-bold text-gray-500">{t.pyme_view.validation.upload_drop || 'Arrastra tu archivo XML aquí'}</p>
                    <p className="text-[10px] font-black text-gray-300 uppercase tracking-widest mt-2">{t.pyme_view.validation.upload_click || 'O haz clic para seleccionar'}</p>
                  </div>

                  <div className="mt-8 flex justify-center">
                    <button onClick={() => setShowUploadModal(false)} className="text-xs font-black text-gray-400 uppercase tracking-widest hover:text-dark">{t.common.cancel}</button>
                  </div>
                </>
              ) : (
                <div className="py-10 space-y-8">
                   <div className="flex flex-col items-center gap-6">
                      <div className="w-16 h-16 border-4 border-secondary border-t-transparent rounded-full animate-spin"></div>
                      <h4 className="text-xl font-black text-dark tracking-tight">{t.pyme_view.emit.processing_title || 'Procesando CFDI'}</h4>
                   </div>
                   <div className="space-y-3 bg-gray-50 p-6 rounded-[2rem] border border-gray-100">
                      {processingLogs.map((log, idx) => (
                        <div key={idx} className={`flex items-center gap-3 transition-opacity duration-500 ${idx > processingStep ? 'opacity-20' : 'opacity-100'}`}>
                           {idx < processingStep ? (
                             <div className="bg-green-100 p-1 rounded-full"><Check className="w-3 h-3 text-green-600" /></div>
                           ) : idx === processingStep ? (
                             <div className="w-5 h-5 border-2 border-secondary border-t-transparent rounded-full animate-spin" />
                           ) : (
                             <div className="w-5 h-5 rounded-full border-2 border-gray-200" />
                           )}
                           <span className={`text-xs font-bold ${idx === processingStep ? 'text-dark' : 'text-gray-400'}`}>{log}</span>
                        </div>
                      ))}
                   </div>
                </div>
              )}
            </motion.div>
          </div>
        )}
        
        {selectedCFDI && <CFDIViewer cfdi={selectedCFDI} onClose={() => setSelectedCFDI(null)} />}
      </AnimatePresence>
    </div>
  );
}

function CFDIViewer({ cfdi, onClose }: { cfdi: any, onClose: () => void }) {
  const { showToast, t } = useAppContext();
  
  return (
    <div className="fixed inset-0 z-[450] bg-dark/60 backdrop-blur-md flex items-center justify-center p-4 lg:p-10" onClick={onClose}>
      <motion.div 
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        className="bg-white document-viewer w-full max-w-4xl h-full flex flex-col rounded-[2.5rem] shadow-2xl overflow-hidden"
        onClick={e => e.stopPropagation()}
      >
        {/* Banner de error si aplica */}
        {cfdi.reason && (
          <div className={`${cfdi.status === '⚠ Revisar' ? 'bg-amber-500' : 'bg-red-500'} text-white py-3 px-6 text-center text-xs font-black uppercase tracking-widest animate-pulse`}>
            {cfdi.reason}
          </div>
        )}

        <div className="p-8 border-b border-gray-100 flex justify-between items-center bg-gray-50/30">
          <div className="flex items-center gap-4">
            <div className="bg-dark p-3 rounded-2xl">
              <FileCode className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-black text-dark tracking-tight">{t.cfdi_viewer.title}</h2>
              <p className="text-[10px] text-gray-400 font-black uppercase tracking-widest">Folio Fiscal (UUID): {cfdi.uuid}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-3 hover:bg-gray-100 rounded-2xl transition-colors text-gray-300 hover:text-dark">
            <XCircle className="w-8 h-8" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-10 space-y-12">
          {/* Header del CFDI */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            <div className="space-y-4">
              <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest border-b border-gray-50 pb-2">{t.cfdi_viewer.issuer}</h4>
              <div className="space-y-1">
                <p className="text-lg font-black text-dark leading-tight">{cfdi.emisor}</p>
                <p className="text-sm font-bold text-gray-500">RFC: {cfdi.emisorRfc}</p>
                <p className="text-xs text-gray-400 mt-2 font-medium">{t.pyme_view.providers.modal.fields.regimen}: 601 - General de Ley Personas Morales</p>
                <p className="text-xs text-gray-400 font-medium">{t.pyme_view.directory.modal.city}: 64100, Nuevo León</p>
              </div>
            </div>
            <div className="space-y-4">
              <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest border-b border-gray-50 pb-2">{t.cfdi_viewer.receiver}</h4>
              <div className="space-y-1">
                <p className="text-lg font-black text-dark">{cfdi.receiver}</p>
                <p className="text-sm font-bold text-gray-500">RFC: {cfdi.receiverRfc}</p>
                <p className="text-xs text-gray-400 mt-2 font-medium">{t.pyme_view.emit.usage}: {cfdi.type}</p>
                <p className="text-xs text-gray-400 font-medium">{t.pyme_view.providers.modal.fields.cp}: 64000</p>
              </div>
            </div>
          </div>

          {/* Tabla de Conceptos */}
          <div>
            <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-4">{t.cfdi_viewer.concepts}</h4>
            <div className="border border-gray-100 rounded-2xl overflow-hidden">
               <table className="w-full text-left text-sm">
                  <thead className="bg-gray-50 font-black text-[10px] uppercase text-gray-400">
                    <tr>
                      <th className="px-6 py-4">{t.pyme_view.emit.concepts || 'Clave'}</th>
                      <th className="px-6 py-4">{t.cfdi_viewer.description}</th>
                      <th className="px-6 py-4 text-center">{t.cfdi_viewer.quantity}</th>
                      <th className="px-6 py-4 text-right">{t.cfdi_viewer.unit_price}</th>
                      <th className="px-6 py-4 text-right">{t.cfdi_viewer.amount}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                    {cfdi.concepts.map((c: any, i: number) => (
                      <tr key={i}>
                        <td className="px-6 py-4 font-bold text-gray-400">01010101</td>
                        <td className="px-6 py-4 font-bold text-dark">{c.desc}</td>
                        <td className="px-6 py-4 text-center text-gray-500">{c.qty}</td>
                        <td className="px-6 py-4 text-right text-gray-500">${c.price.toLocaleString()}</td>
                        <td className="px-6 py-4 text-right font-black text-dark">${c.total.toLocaleString()}</td>
                      </tr>
                    ))}
                  </tbody>
               </table>
            </div>
          </div>

          {/* Totales y Sellos */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
            <div className="lg:col-span-7 space-y-6">
              <div className="space-y-3">
                 <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{t.pyme_view.emit.payment_method || 'Información de Pago'}</h4>
                 <div className="grid grid-cols-2 gap-4">
                    <div className="bg-gray-50 p-4 rounded-xl">
                       <p className="text-[10px] font-black text-gray-300 uppercase">{t.pyme_view.emit.payment_method || 'Método'}</p>
                       <p className="text-xs font-bold text-dark">PUE - Pago en una sola exhibición</p>
                    </div>
                    <div className="bg-gray-50 p-4 rounded-xl">
                       <p className="text-[10px] font-black text-gray-300 uppercase">{t.pyme_view.emit.payment_form || 'Forma'}</p>
                       <p className="text-xs font-bold text-dark">03 - Transferencia electrónica</p>
                    </div>
                 </div>
              </div>

              <div className="space-y-3">
                <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{t.cfdi_viewer.sat_seal}</h4>
                <p className="text-[8px] font-mono text-gray-400 break-all leading-normal bg-gray-50 p-4 rounded-xl border border-gray-100">
                  yHw+XJRpL6m+XvYq9x1z8w0A2b3c4d5e6f7g8h9i0j1k2l3m4n5o6p7q8r9s0t1u2v3w4x5y6z7A8B9C0D1E2F3G4H5I6J7K8L9M0N1O2P3Q4R5S6T7U8V9W0X1Y2Z3A4B5C6D7E8F9G0H1I2J3K4L5M6N7O8P9Q0R1S2T3U4V5W6X7Y8Z9A0B1C2D3E4F5G6H7I8J9K0L1M2N3O4P5Q6R7S8T9U0V1W2X3Y4Z5A6B7C8D9E0F1G2H3I4J5K6L7M8N9O0P1Q2R3S4T5U6V7W8X9Y0Z1A2B3==
                </p>
              </div>

              <div className="space-y-3">
                <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{t.cfdi_viewer.sat_seal_chain || 'Cadena Original del Complemento de Certificación'}</h4>
                <p className="text-[8px] font-mono text-gray-400 break-all leading-normal bg-gray-50 p-4 rounded-xl border border-gray-100">
                  ||1.1|{cfdi.uuid}|2025-10-15T10:30:00|SAT970701NN3|yHw+XJRpL6m+XvYq9x1z8w0A2b3c4d5e6f7g8h9i0j1k2l3m4n5o6p7q8r9s0t1u2v3w4x5y6z7A8B9C0D1E2F3G4H5I6J7K8L9M0N1O2P3Q4R5S6T7U8V9W0X1Y2Z3A4B5C6D7E8F9G0H1I2J3K4L5M6N7O8P9Q0R1S2T3U4V5W6X7Y8Z9A0B1C2D3E4F5G6H7I8J9K0L1M2N3O4P5Q6R7S8T9U0V1W2X3Y4Z5A6B7C8D9E0F1G2H3I4J5K6L7M8N9O0P1Q2R3S4T5U6V7W8X9Y0Z1A2B3|00001000000504465028||
                </p>
              </div>
            </div>

            <div className="lg:col-span-5">
              <div className="bg-gray-50 rounded-[2.5rem] p-8 space-y-6">
                <div className="flex justify-between items-center text-sm">
                  <span className="font-bold text-gray-400 uppercase tracking-widest">{t.cfdi_viewer.subtotal}</span>
                  <span className="font-black text-dark text-lg italic">$3,103.45</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span className="font-bold text-gray-400 uppercase tracking-widest">{t.cfdi_viewer.tax}</span>
                  <span className="font-black text-dark text-lg italic">$496.55</span>
                </div>
                <div className="h-px bg-gray-200 w-full" />
                <div className="flex justify-between items-center pt-2">
                  <span className="font-black text-dark uppercase tracking-widest">{t.pyme_view.emit.summary || 'Total CFDI'}</span>
                  <span className="font-black text-3xl text-secondary">{cfdi.amount}</span>
                </div>
                <p className="text-[10px] text-gray-400 font-bold text-center italic mt-4">{t.common.currency || 'Moneda'}: MXN - Peso Mexicano</p>
              </div>

              <div className="mt-8 space-y-3">
                 <button 
                   onClick={() => showToast(t.cfdi_viewer.download_success.replace('{type}', 'XML'))}
                   className="w-full py-4 rounded-xl border-2 border-gray-100 hover:border-dark text-dark font-black text-[10px] uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-2"
                 >
                   <Download className="w-4 h-4" /> {t.cfdi_viewer.download_xml}
                 </button>
                 <button 
                    onClick={() => showToast(t.cfdi_viewer.download_success.replace('{type}', 'PDF'))}
                    className="w-full py-4 rounded-xl bg-dark text-white font-black text-[10px] uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-2 shadow-xl shadow-dark/20"
                 >
                   <FileText className="w-4 h-4" /> {t.cfdi_viewer.download_pdf}
                  </button>
               </div>
             </div>
           </div>
         </div>
       </motion.div>
     </div>
   );
}

function PYMEEmitir() {
  const { showToast, t } = useAppContext();
  const [isTimbrando, setIsTimbrando] = useState(false);
  const [timbradoStep, setTimbradoStep] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [activeEmitView, setActiveEmitView] = useState<'new' | 'drafts'>('new');
  
  const clients = [
    { name: 'Innovaciones Digitales SA de CV', rfc: 'IDI180523XY1', cp: '64000', regimen: '601', uso: 'G03' },
    { name: 'Consultora Empresarial del Norte', rfc: 'CEN200410ABC', cp: '66200', regimen: '601', uso: 'G03' },
    { name: 'Soluciones Integrales García', rfc: 'SIG150812DEF', cp: '06700', regimen: '601', uso: 'P01' }
  ];

  const timbradoLogs = [
    t.pyme_view.emit.logs_validating || "⏳ Validando datos del receptor...",
    t.pyme_view.emit.logs_calculating || "⏳ Calculando impuestos...",
    t.pyme_view.emit.logs_sending || "⏳ Enviando al PAC...",
    t.pyme_view.emit.logs_requesting || "⏳ Solicitando timbre fiscal del SAT..."
  ];

  const handleTimbrar = () => {
    setIsTimbrando(true);
    setTimbradoStep(0);
    const interval = setInterval(() => {
      setTimbradoStep(s => {
        if (s >= timbradoLogs.length - 1) {
          clearInterval(interval);
          setTimeout(() => {
            setIsTimbrando(false);
            setShowResult(true);
            showToast(t.pyme_view.emit.success_toast || "✓ CFDI timbrado exitosamente");
          }, 1000);
          return s;
        }
        return s + 1;
      });
    }, 1000);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white p-7 rounded-[2rem] shadow-sm border border-gray-100 flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-black text-dark tracking-tight">{t.pyme_view.emit.title}</h2>
          <p className="text-xs text-gray-400 font-medium mt-1">{t.pyme_view.emit.subtitle}</p>
        </div>
        <div className="flex bg-gray-50 p-1.5 rounded-2xl border border-gray-100">
           <button 
             onClick={() => setActiveEmitView('new')}
             className={`px-5 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${activeEmitView === 'new' ? 'text-dark bg-white shadow-sm' : 'text-gray-400 hover:text-dark'}`}
           >
             {t.pyme_view.emit.new_btn}
           </button>
           <button 
             onClick={() => setActiveEmitView('drafts')}
             className={`px-5 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${activeEmitView === 'drafts' ? 'text-dark bg-white shadow-sm' : 'text-gray-400 hover:text-dark'}`}
           >
             {t.pyme_view.emit.drafts_btn}
           </button>
        </div>
      </div>

      {activeEmitView === 'new' ? (
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-8 space-y-6">
          {/* CLIENT DATA */}
          <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-gray-100 space-y-6">
             <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-2 px-1">{t.pyme_view.emit.receptor}</h3>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="md:col-span-2">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1 block">{t.pyme_view.providers.table.name}</label>
                  <select className="w-full bg-gray-50 border border-gray-100 rounded-2xl p-4 text-sm font-bold outline-none focus:border-dark transition-all">
                    <option value="">{t.pyme_view.emit.select_client}</option>
                    {clients.map(c => (
                      <option key={c.rfc} value={c.rfc}>{c.name} ({c.rfc})</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1 block">{t.pyme_view.emit.usage}</label>
                  <select className="w-full bg-gray-50 border border-gray-100 rounded-2xl p-4 text-sm font-bold outline-none focus:border-dark transition-all">
                    <option value="G03">G03 - Gastos en general</option>
                    <option value="P01">P01 - Por definir</option>
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1 block">{t.pyme_view.emit.payment_method}</label>
                  <select className="w-full bg-gray-50 border border-gray-100 rounded-2xl p-4 text-sm font-bold outline-none focus:border-dark transition-all">
                    <option value="PUE">PUE - Pago en una sola exhibición</option>
                    <option value="PPD">PPD - Pago en parcialidades o diferido</option>
                  </select>
                </div>
             </div>
          </div>

          {/* CONCEPTS */}
          <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-gray-100 space-y-6">
             <div className="flex justify-between items-center px-1">
               <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">{t.pyme_view.emit.concepts}</h3>
               <button className="text-[10px] font-black text-secondary flex items-center gap-1.5 uppercase tracking-widest hover:underline">
                  <Plus className="w-3.5 h-3.5" /> {t.pyme_view.emit.add_concept}
               </button>
             </div>
             
             <div className="space-y-4">
                <div className="p-6 bg-gray-50 rounded-[2rem] border border-gray-100 grid grid-cols-1 md:grid-cols-12 gap-4 items-end">
                   <div className="md:col-span-5">
                      <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1 block">{t.pyme_view.emit.desc}</label>
                      <input type="text" defaultValue="Consultoría Administrativa Mensual" className="w-full bg-white border border-gray-100 rounded-xl p-3 text-xs font-bold outline-none focus:border-dark" />
                   </div>
                   <div className="md:col-span-2">
                      <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1 block">{t.pyme_view.emit.qty}</label>
                      <input type="number" defaultValue="1" className="w-full bg-white border border-gray-100 rounded-xl p-3 text-xs font-bold outline-none focus:border-dark" />
                   </div>
                   <div className="md:col-span-3">
                      <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1 block">{t.pyme_view.emit.price}</label>
                      <input type="number" defaultValue="15000" className="w-full bg-white border border-gray-100 rounded-xl p-3 text-xs font-bold outline-none focus:border-dark" />
                   </div>
                   <div className="md:col-span-2 text-right p-3">
                      <p className="text-[10px] font-black text-gray-400 uppercase mb-1">{t.cfdi_viewer.subtotal}</p>
                      <p className="text-sm font-black text-dark">$15,000.00</p>
                   </div>
                </div>
             </div>
          </div>
        </div>

        <div className="lg:col-span-4 space-y-6">
          <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-gray-100 flex flex-col h-full">
            <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-8">{t.pyme_view.emit.summary}</h3>
            <div className="space-y-6 flex-1">
              <div className="flex justify-between items-center text-sm font-bold">
                 <span className="text-gray-400 uppercase tracking-widest text-[10px]">{t.cfdi_viewer.subtotal}</span>
                 <span className="text-dark">$15,000.00</span>
              </div>
              <div className="flex justify-between items-center text-sm font-bold">
                 <span className="text-gray-400 uppercase tracking-widest text-[10px]">{t.cfdi_viewer.tax}</span>
                 <span className="text-dark">$2,400.00</span>
              </div>
              <div className="pt-6 border-t border-gray-50 flex justify-between items-center text-2xl font-black text-dark">
                 <span className="text-sm uppercase tracking-[0.2em] text-gray-300">{t.cfdi_viewer.total}</span>
                 <span>$17,400.00</span>
              </div>
            </div>
            
            <button 
              onClick={handleTimbrar}
              disabled={isTimbrando}
              className="w-full bg-dark text-white py-5 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-dark/20 hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-3 mt-10 disabled:opacity-50"
            >
              {isTimbrando ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>{t.pyme_view.emit.timbrando}</span>
                </>
              ) : (
                <>
                  <Send className="w-5 h-5 text-secondary" />
                  <span>{t.pyme_view.emit.timbrar}</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
      ) : (
         <div className="bg-white p-12 rounded-[2.5rem] shadow-sm border border-gray-100 text-center flex flex-col items-center justify-center space-y-4">
            <div className="bg-gray-50 w-20 h-20 rounded-full flex items-center justify-center mb-2">
               <FileText className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-xl font-black text-dark tracking-tight">{t.pyme_view.emit.drafts_title || 'No hay borradores'}</h3>
            <p className="text-sm font-medium text-gray-500 max-w-sm">{t.pyme_view.emit.drafts_empty || 'Los documentos que guardes sin timbrar aparecerán aquí.'}</p>
         </div>
      )}

      <AnimatePresence>
        {isTimbrando && (
           <div className="fixed inset-0 z-[600] bg-dark/80 backdrop-blur-md flex items-center justify-center p-4">
              <div className="bg-white w-full max-w-md p-10 rounded-[3rem] text-center space-y-6 shadow-2xl">
                 <div className="w-20 h-20 bg-secondary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <div className="w-10 h-10 border-4 border-secondary border-t-transparent rounded-full animate-spin" />
                 </div>
                 <h3 className="text-2xl font-black text-dark">{t.pyme_view.emit.processing_title}</h3>
                 <div className="space-y-3">
                   {timbradoLogs.map((log, i) => (
                     <motion.p 
                       key={i}
                       initial={{ opacity: 0 }}
                       animate={{ opacity: i <= timbradoStep ? 1 : 0.3 }}
                       className={`text-sm font-bold ${i === timbradoStep ? 'text-dark' : 'text-gray-400'}`}
                     >
                       {log}
                     </motion.p>
                   ))}
                 </div>
              </div>
           </div>
        )}

        {showResult && (
          <div className="fixed inset-0 z-[600] bg-dark/80 backdrop-blur-md flex items-center justify-center p-4 lg:p-10">
            <motion.div 
               initial={{ opacity: 0, scale: 0.95 }}
               animate={{ opacity: 1, scale: 1 }}
               className="bg-white w-full max-w-4xl h-full flex flex-col rounded-[3rem] shadow-2xl overflow-hidden"
            >
              <div className="p-8 border-b border-gray-100 flex justify-between items-center bg-green-50/30">
                 <div className="flex items-center gap-4">
                   <div className="bg-green-100 p-3 rounded-2xl">
                     <CheckCircle2 className="w-6 h-6 text-green-600" />
                   </div>
                   <div>
                     <h3 className="text-xl font-black text-dark">{t.pyme_view.emit.success_title}</h3>
                     <p className="text-[10px] font-bold text-green-600 uppercase tracking-widest mt-0.5">UUID: 8F7D6E5C-4B3A-2910-FEDC-BA9876543210</p>
                   </div>
                 </div>
                 <button onClick={() => setShowResult(false)} className="text-gray-300 hover:text-dark transition-colors"><XCircle className="w-8 h-8" /></button>
              </div>

              <div className="flex-1 overflow-y-auto p-10 bg-gray-50 flex items-center justify-center">
                 {/* Preview de la factura */}
                 <div className="bg-white w-full max-w-2xl aspect-[1/1.4] shadow-xl p-12 flex flex-col border border-gray-100 relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-gray-50 -mr-16 -mt-16 rotate-45" />
                    <div className="flex justify-between items-start mb-16">
                       <div>
                          <h4 className="text-2xl font-black text-dark">{t.pyme_view.emit.invoice.toUpperCase()}</h4>
                          <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mt-1">Serie A · Folio 1284</p>
                       </div>
                       <div className="text-right">
                          <p className="font-black text-dark">MTY Tech Solutions</p>
                          <p className="text-[9px] font-bold text-gray-400">MTS230415A87</p>
                       </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-10 mb-16">
                       <div>
                          <p className="text-[9px] font-black text-gray-300 uppercase tracking-widest mb-2">{t.cfdi_viewer.receiver}</p>
                          <p className="text-xs font-black text-dark">Innovaciones Digitales SA de CV</p>
                          <p className="text-[9px] font-bold text-gray-500 mt-1">IDI180523XY1</p>
                       </div>
                       <div>
                          <p className="text-[9px] font-black text-gray-300 uppercase tracking-widest mb-2">{t.cfdi_viewer.emission_date || 'Fecha y Hora'}</p>
                          <p className="text-xs font-black text-dark">30 Abril 2026</p>
                          <p className="text-[9px] font-bold text-gray-500 mt-1">05:12:24 AM</p>
                       </div>
                    </div>

                    <div className="flex-1 border-y border-gray-100 py-8">
                       <table className="w-full text-left">
                          <thead>
                             <tr>
                                <th className="text-[9px] font-black text-gray-400 uppercase tracking-widest pb-4">{t.pyme_view.emit.concepts || 'Concepto'}</th>
                                <th className="text-[9px] font-black text-gray-400 uppercase tracking-widest pb-4 text-center">{t.pyme_view.emit.qty || 'Cant.'}</th>
                                <th className="text-[9px] font-black text-gray-400 uppercase tracking-widest pb-4 text-right">{t.pyme_view.emit.price || 'P. Unitario'}</th>
                                <th className="text-[9px] font-black text-gray-400 uppercase tracking-widest pb-4 text-right">{t.cfdi_viewer.amount || 'Importe'}</th>
                             </tr>
                          </thead>
                          <tbody>
                             <tr>
                                <td className="text-[11px] font-bold text-dark py-2">Consultoría Administrativa Mensual</td>
                                <td className="text-[11px] font-bold text-center py-2">1</td>
                                <td className="text-[11px] font-bold text-right py-2">$15,000.00</td>
                                <td className="text-[11px] font-black text-dark py-2 text-right">$15,000.00</td>
                             </tr>
                          </tbody>
                       </table>
                    </div>

                    <div className="mt-10 self-end w-48 space-y-4">
                       <div className="flex justify-between items-center text-[10px] font-bold text-gray-400">
                          <span>{t.cfdi_viewer.subtotal}</span>
                          <span className="text-dark">$15,000.00</span>
                       </div>
                       <div className="flex justify-between items-center text-[10px] font-bold text-gray-400">
                          <span>{t.cfdi_viewer.tax}</span>
                          <span className="text-dark">$2,400.00</span>
                       </div>
                       <div className="flex justify-between items-center border-t border-gray-100 pt-4 text-lg font-black text-dark">
                          <span>{t.cfdi_viewer.total}</span>
                          <span>$17,400.00</span>
                       </div>
                    </div>
                 </div>
              </div>

              <div className="p-8 border-t border-gray-100 bg-white grid grid-cols-3 gap-4">
                 <button className="flex items-center justify-center gap-2 bg-gray-50 py-4 rounded-xl text-xs font-black uppercase tracking-widest text-dark hover:bg-gray-100 transition-all border border-gray-100">
                    <Download className="w-4 h-4" /> {t.cfdi_viewer.download_xml}
                 </button>
                 <button className="flex items-center justify-center gap-2 bg-gray-50 py-4 rounded-xl text-xs font-black uppercase tracking-widest text-dark hover:bg-gray-100 transition-all border border-gray-100">
                    <FileDown className="w-4 h-4" /> {t.cfdi_viewer.download_pdf}
                 </button>
                 <button 
                  onClick={() => { setShowResult(false); showToast(t.common.success_email || "✓ Enviado por correo"); }}
                  className="flex items-center justify-center gap-2 bg-dark py-4 rounded-xl text-xs font-black uppercase tracking-widest text-white hover:bg-black transition-all shadow-xl shadow-dark/20"
                 >
                    <Mail className="w-4 h-4" /> {t.pyme_view.emit.send_client}
                 </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function PYMEDescargas() {
  const { showToast, t } = useAppContext();
  const [isGenerating, setIsGenerating] = useState(false);
  const [showResult, setShowResult] = useState(false);

  const handleGenerate = () => {
    setIsGenerating(true);
    setTimeout(() => {
      setIsGenerating(false);
      setShowResult(true);
      showToast(t.pyme_view.downloads.ready_toast || "✓ Paquete listo (CFDI_2026_Marzo.zip - 2.4 MB)");
    }, 3000);
  };

  const zipContent = [
    { name: 'Facturas_Emitidas_Marzo.xml (x8)', type: 'XML CFDI', size: '1.2 MB' },
    { name: 'Facturas_Recibidas_Marzo.xml (x10)', type: 'XML CFDI', size: '1.8 MB' },
    { name: 'Reporte_Mensual_Marzo.xlsx', type: 'Excel Spreadsheet', size: '450 KB' },
    { name: 'Resumen_Fiscal_Ejecutivo.pdf', type: 'PDF Document', size: '890 KB' }
  ];

  return (
    <div className="space-y-6">
      <div className="bg-white p-10 rounded-[3rem] shadow-sm border border-gray-100 max-w-3xl mx-auto">
        <div className="flex items-center gap-5 mb-10">
          <div className="bg-tertiary/10 p-4 rounded-3xl">
            <Download className="w-8 h-8 text-tertiary" />
          </div>
          <div>
            <h2 className="text-2xl font-black text-dark tracking-tight">{t.pyme_view.downloads.title}</h2>
            <p className="text-xs text-gray-400 font-medium mt-1 uppercase tracking-widest">{t.pyme_view.downloads.subtitle}</p>
          </div>
        </div>

        {!showResult ? (
          <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
               <div className="space-y-2">
                 <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">{t.pyme_view.downloads.period}</label>
                 <select className="w-full bg-gray-50 border border-gray-100 rounded-2xl p-4 text-sm font-bold outline-none focus:border-tertiary transition-all">
                    <option>{t.common.months.mar || 'Marzo'} 2026</option>
                    <option>{t.common.months.feb || 'Febrero'} 2026</option>
                    <option>{t.pyme_view.downloads.quarter || 'Trimestre'} 1 2026</option>
                 </select>
               </div>
               <div className="space-y-2">
                 <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">{t.pyme_view.downloads.type}</label>
                 <select className="w-full bg-gray-50 border border-gray-100 rounded-2xl p-4 text-sm font-bold outline-none focus:border-tertiary transition-all">
                    <option>{t.pyme_view.downloads.all}</option>
                    <option>{t.pyme_view.downloads.received}</option>
                    <option>{t.pyme_view.downloads.issued}</option>
                    <option>{t.pyme_view.downloads.payroll}</option>
                 </select>
               </div>
            </div>

            <button 
              onClick={handleGenerate}
              disabled={isGenerating}
              className="w-full bg-dark text-white py-6 rounded-3xl font-black text-xs uppercase tracking-widest shadow-2xl shadow-dark/20 hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-3 disabled:opacity-50"
            >
              {isGenerating ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>{t.pyme_view.downloads.generating}</span>
                </>
              ) : (
                <>
                  <FileDown className="w-6 h-6 text-tertiary" />
                  <span>{t.pyme_view.downloads.generate_btn}</span>
                </>
              )}
            </button>
          </div>
        ) : (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-8"
          >
            <div className="bg-green-50 p-6 rounded-[2rem] border border-green-100 text-center">
               <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-4 border border-green-50 shadow-sm">
                  <CheckCircle2 className="w-8 h-8 text-green-500" />
               </div>
               <h3 className="text-xl font-black text-green-900">{t.pyme_view.downloads.ready_title}</h3>
               <p className="text-xs text-green-700 font-bold mt-1 opacity-70">CFDI_2026_Marzo.zip (2.4 MB)</p>
            </div>

            <div className="space-y-4">
               <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">{t.pyme_view.downloads.content}</p>
               {zipContent.map((file, i) => (
                 <div key={i} className="flex justify-between items-center p-4 bg-gray-50 rounded-2xl border border-gray-100">
                    <div className="flex items-center gap-3">
                       <FileCode className="w-5 h-5 text-dark/40" />
                       <span className="text-sm font-bold text-dark">{file.name}</span>
                    </div>
                    <div className="text-right">
                       <p className="text-[10px] font-black text-gray-400 uppercase">{file.size}</p>
                    </div>
                 </div>
               ))}
            </div>

            <div className="flex gap-4">
               <button 
                 onClick={() => setShowResult(false)}
                 className="flex-1 bg-gray-100 p-5 rounded-2xl text-xs font-black uppercase tracking-widest text-gray-500"
               >
                 {t.pyme_view.downloads.new_btn}
               </button>
               <button 
                 onClick={() => showToast(t.pyme_view.downloads.downloading || "✓ Descargando archivo...")}
                 className="flex-[2] bg-dark text-white p-5 rounded-2xl text-xs font-black uppercase tracking-widest shadow-xl shadow-dark/20 hover:bg-black transition-all"
               >
                 {t.pyme_view.downloads.download_now}
               </button>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}

function PYMENomina() {
  const { showToast, t } = useAppContext();
  const [isTimbrando, setIsTimbrando] = useState(false);
  const [timbradoStep, setTimbradoStep] = useState(0);
  const [showAddModal, setShowAddModal] = useState(false);

  const employees = [
    { name: 'María Fernanda Ortiz', role: 'Gerente de Operaciones', salary: 850, rfc: 'OIMA890315ABC', nss: '12345678901', status: '✓ Pagado' },
    { name: 'Carlos Eduardo Rivera', role: 'Desarrollador Senior', salary: 1200, rfc: 'RICE920704DEF', nss: '98765432109', status: '✓ Pagado' },
    { name: 'Ana Lucía Mendoza', role: 'Asistente Administrativa', salary: 480, rfc: 'MEAL950122GHI', nss: '55667788990', status: '⌛ Pendiente' }
  ];

  const timbradoLogs = [
    "⏳ Generando recibos...",
    "⏳ Calculando ISR...",
    "⏳ Calculando IMSS...",
    "⏳ Timbrando ante PAC..."
  ];

  const handleTimbrar = () => {
    setIsTimbrando(true);
    setTimbradoStep(0);
    const interval = setInterval(() => {
      setTimbradoStep(s => {
        if (s >= timbradoLogs.length - 1) {
          clearInterval(interval);
          setTimeout(() => {
            setIsTimbrando(false);
            showToast(t.pyme_view.payroll.success_toast || "✓ Nómina timbrada exitosamente");
          }, 1000);
          return s;
        }
        return s + 1;
      });
    }, 1000);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white p-7 rounded-[2rem] shadow-sm border border-gray-100 flex flex-col md:flex-row justify-between items-center gap-4">
        <div>
          <h2 className="text-2xl font-black text-dark tracking-tight">{t.pyme_view.payroll.title}</h2>
          <p className="text-xs text-gray-400 font-medium mt-1">{t.pyme_view.payroll.subtitle}</p>
        </div>
        <div className="flex gap-3 w-full md:w-auto">
          <button 
            onClick={() => setShowAddModal(true)}
            className="flex-1 md:flex-none border border-gray-200 text-dark px-6 py-3.5 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-gray-50 transition-all flex items-center justify-center gap-2"
          >
            <Plus className="w-5 h-5" /> {t.pyme_view.payroll.add_emp}
          </button>
          <button 
            onClick={handleTimbrar}
            disabled={isTimbrando}
            className="flex-1 md:flex-none bg-dark text-white px-8 py-3.5 rounded-2xl font-black text-xs uppercase tracking-widest transition-all flex items-center justify-center gap-2 shadow-xl shadow-dark/20 active:scale-95 disabled:opacity-50"
          >
            {isTimbrando ? (
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <ShieldCheck className="w-5 h-5 text-secondary" />
            )}
            <span>{isTimbrando ? t.pyme_view.payroll.processing || 'Procesando...' : t.pyme_view.payroll.timbrar_period}</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
           {employees.map((emp, i) => (
             <div key={i} className="bg-white p-6 rounded-[2.5rem] shadow-sm border border-gray-100 flex justify-between items-center group hover:border-dark/10 transition-all">
               <div className="flex items-center gap-5">
                  <div className="bg-gray-50 p-3.5 rounded-2xl group-hover:bg-dark group-hover:text-white transition-colors">
                     <BriefcaseBusiness className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-dark">{emp.name}</h4>
                    <p className="text-[10px] text-gray-400 font-black uppercase tracking-widest mt-0.5">{emp.role} · {emp.rfc}</p>
                  </div>
               </div>
               <div className="flex items-center gap-8 text-right">
                  <div>
                    <p className="text-sm font-black text-dark">${emp.salary}/{t.common.date === 'Fecha' ? 'día' : 'day'}</p>
                    <p className="text-[9px] font-bold text-gray-400 uppercase tracking-widest">{emp.status}</p>
                  </div>
                  <button className="p-3 bg-gray-50 text-gray-400 hover:text-dark hover:bg-white rounded-xl transition-all border border-transparent hover:border-gray-100 shadow-sm">
                    <Eye className="w-5 h-5" />
                  </button>
               </div>
             </div>
           ))}
        </div>

        <div className="space-y-6">
          <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-gray-100 flex flex-col justify-between h-full">
            <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-6">{t.pyme_view.payroll.summary}</h3>
            <div className="space-y-6 mb-8">
              <div className="flex justify-between items-center text-sm font-bold">
                 <span className="text-gray-400">{t.pyme_view.payroll.net_total}</span>
                 <span className="text-dark">$38,450.00</span>
              </div>
              <div className="flex justify-between items-center text-sm font-bold">
                 <span className="text-gray-400">{t.pyme_view.payroll.isr}</span>
                 <span className="text-dark">$4,210.00</span>
              </div>
              <div className="flex justify-between items-center text-sm font-bold">
                 <span className="text-gray-400">{t.pyme_view.payroll.imss}</span>
                 <span className="text-dark">$1,120.00</span>
              </div>
              <div className="pt-6 border-t border-gray-50 flex justify-between items-center text-lg font-black text-dark">
                 <span>{t.pyme_view.payroll.total_disburse}</span>
                 <span>$43,780.00</span>
              </div>
            </div>
            <button className="w-full bg-gray-50 py-4 rounded-2xl text-[10px] font-black text-dark uppercase tracking-widest hover:bg-gray-100 transition-all">{t.pyme_view.payroll.layout_btn}</button>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {isTimbrando && (
          <div className="fixed inset-0 z-[600] bg-dark/80 backdrop-blur-md flex items-center justify-center p-4">
             <div className="bg-white w-full max-w-md p-10 rounded-[3rem] text-center space-y-6 shadow-2xl">
                <div className="w-20 h-20 bg-secondary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                   <div className="w-10 h-10 border-4 border-secondary border-t-transparent rounded-full animate-spin" />
                </div>
                <h3 className="text-2xl font-black text-dark">{t.pyme_view.payroll.processing || 'Procesando Nómina'}</h3>
                <div className="space-y-3">
                  {timbradoLogs.map((log, i) => (
                    <motion.p 
                      key={i}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: i <= timbradoStep ? 1 : 0.3 }}
                      className={`text-sm font-bold ${i === timbradoStep ? 'text-dark' : 'text-gray-400'}`}
                    >
                      {log}
                    </motion.p>
                  ))}
                </div>
             </div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function PYMECalendario() {
  const { showToast, t } = useAppContext();
  const [selectedDay, setSelectedDay] = useState<number | null>(17);

  const [viewMode, setViewMode] = useState<'mes' | 'lista'>('mes');

  const days = Array.from({ length: 30 }, (_, i) => i + 1);
  const events = {
    17: [
      { title: t.pyme_view.calendar?.events?.isr_tax || 'Pago provisional ISR', type: t.pyme_view.calendar?.events?.due_today || 'Vence hoy', badge: 'bg-red-500' },
      { title: t.pyme_view.calendar?.events?.iva_tax || 'Declaración mensual IVA', type: t.pyme_view.calendar?.events?.due_today || 'Vence hoy', badge: 'bg-red-500' }
    ],
    30: [
      { title: t.pyme_view.calendar?.events?.diot || 'Presentación DIOT', type: t.pyme_view.calendar?.events?.last_day || 'Último día', badge: 'bg-amber-500' }
    ],
    31: [
      { title: t.pyme_view.calendar?.events?.annual_tax || 'Declaración Anual Personas Morales', type: t.pyme_view.calendar?.events?.annual_due || 'Vencimiento Anual', badge: 'bg-red-600' }
    ],
    5: [
      { title: `${t.pyme_view.calendar?.events?.provider_apt || 'Cita con Proveedor'}: IT Services`, type: t.pyme_view.calendar?.events?.scheduled || 'Cita agendada', badge: 'bg-blue-500' }
    ],
    22: [
      { title: `${t.pyme_view.calendar?.events?.provider_apt || 'Cita con Proveedor'}: Gasolinera`, type: t.pyme_view.calendar?.events?.scheduled || 'Cita agendada', badge: 'bg-blue-500' }
    ]
  };

  const [showDetailModal, setShowDetailModal] = useState(false);

  return (
    <div className="space-y-6">
      <div className="bg-white p-7 rounded-[2rem] shadow-sm border border-gray-100 flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-black text-dark tracking-tight">{t.pyme_view.calendar.title}</h2>
          <p className="text-xs text-gray-400 font-medium mt-1">{t.pyme_view.calendar.subtitle} {t.common.months.apr} 2026</p>
        </div>
        <div className="flex bg-gray-50 p-1.5 rounded-2xl border border-gray-100">
           <button 
             onClick={() => setViewMode('mes')}
             className={`px-5 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${viewMode === 'mes' ? 'text-dark bg-white shadow-sm' : 'text-gray-400 hover:text-dark'}`}
           >
             {t.pyme_view.calendar.monthly_view}
           </button>
           <button 
             onClick={() => setViewMode('lista')}
             className={`px-5 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${viewMode === 'lista' ? 'text-dark bg-white shadow-sm' : 'text-gray-400 hover:text-dark'}`}
           >
             {t.pyme_view.calendar.list_view}
           </button>
        </div>
      </div>

      {viewMode === 'mes' ? (
        <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-gray-100">
          <div className="grid grid-cols-7 gap-4 text-center mb-8">
            {[t.pyme_view.calendar.days.mon, t.pyme_view.calendar.days.tue, t.pyme_view.calendar.days.wed, t.pyme_view.calendar.days.thu, t.pyme_view.calendar.days.fri, t.pyme_view.calendar.days.sat, t.pyme_view.calendar.days.sun].map(d => (
              <span key={d} className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{d}</span>
            ))}
            {days.map(d => {
              const hasEvents = events[d as keyof typeof events];
              const isSelected = selectedDay === d;
              return (
                <button 
                  key={d}
                  onClick={() => {
                    setSelectedDay(d);
                    if (hasEvents) setShowDetailModal(true);
                  }}
                  className={`aspect-square rounded-2xl flex flex-col items-center justify-center relative transition-all group ${
                    isSelected ? 'bg-dark text-white shadow-xl shadow-dark/20' : 'bg-gray-50 text-dark hover:bg-gray-100'
                  }`}
                >
                  <span className="text-sm font-black">{d}</span>
                  {hasEvents && (
                    <div className="absolute bottom-2 flex gap-1">
                      {hasEvents.map((_, i) => (
                        <div key={i} className={`w-1.5 h-1.5 rounded-full ${isSelected ? 'bg-white' : hasEvents[0].badge}`} />
                      ))}
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      ) : (
        <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-gray-100 space-y-4">
           {Object.entries(events).map(([idx, dayEvents]) => (
             <div key={idx} className="p-6 rounded-2xl border border-gray-100 bg-gray-50 flex flex-col gap-4">
                <h4 className="font-black text-dark text-lg border-b border-gray-200 pb-2">{idx} {t.pyme_view.calendar.of} {t.common.months.apr} 2026</h4>
                <div className="space-y-4">
                  {dayEvents.map((ev, i) => (
                    <div key={i} className="flex gap-4 items-center">
                       <div className={`w-3 h-3 rounded-full ${ev.badge} shrink-0`} />
                       <div>
                          <p className="text-[9px] font-black uppercase text-gray-400 tracking-[0.2em]">{ev.type}</p>
                          <h4 className="font-bold text-dark">{ev.title}</h4>
                       </div>
                    </div>
                  ))}
                </div>
             </div>
           ))}
        </div>
      )}

      <AnimatePresence>
        {showDetailModal && selectedDay && events[selectedDay as keyof typeof events] && (
          <div className="fixed inset-0 z-[600] bg-dark/60 backdrop-blur-md flex items-center justify-center p-4" onClick={() => setShowDetailModal(false)}>
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white w-full max-w-lg rounded-[3rem] shadow-2xl p-8"
              onClick={e => e.stopPropagation()}
            >
              <div className="flex justify-between items-center mb-8">
                <div className="flex items-center gap-4">
                  <div className="bg-dark/5 p-3 rounded-2xl">
                    <Calendar className="w-6 h-6 text-dark" />
                  </div>
                  <div>
                    <h3 className="text-xl font-black text-dark tracking-tight">{t.pyme_view.calendar.obligations}: {selectedDay} {t.pyme_view.calendar.of} {t.common.months.apr}</h3>
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mt-0.5">{t.pyme_view.calendar.vencimiento_detail || 'Detalle de vencimientos'}</p>
                  </div>
                </div>
                <button onClick={() => setShowDetailModal(false)} className="text-gray-300 hover:text-dark transition-colors"><XCircle className="w-8 h-8" /></button>
              </div>

              <div className="space-y-4">
                {events[selectedDay as keyof typeof events].map((ev, i) => (
                  <div key={i} className="p-6 rounded-[2rem] border border-gray-100 bg-gray-50/50 space-y-5">
                    <div className="flex gap-4">
                       <div className={`mt-1.5 w-3 h-3 rounded-full ${ev.badge} shrink-0 shadow-sm`} />
                       <div>
                          <p className="text-[9px] font-black uppercase text-gray-400 tracking-[0.2em] mb-1">{ev.type}</p>
                          <h4 className="font-bold text-dark text-base leading-snug">{ev.title}</h4>
                          <p className="text-xs text-gray-500 font-medium mt-1">{t.pyme_view.calendar.vence || 'Vence'}: {selectedDay} {t.pyme_view.calendar.of} {t.common.months.apr} 2026</p>
                       </div>
                    </div>
                    <div className="flex gap-3 pt-2">
                       <button 
                         onClick={() => {
                           showToast(t.pyme_view.calendar.fulfilled_toast || `✓ Obligación marcada como cumplida`);
                           setShowDetailModal(false);
                         }}
                         className="flex-1 bg-dark text-white py-4 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-black transition-all shadow-lg shadow-dark/10"
                       >
                         {t.pyme_view.calendar.mark_fulfilled || 'Marcar como cumplida'}
                       </button>
                       <button 
                         onClick={() => {
                           showToast(t.pyme_view.calendar.reminder_toast || `✓ Recordatorio configurado`);
                           setShowDetailModal(false);
                         }}
                         className="flex-1 bg-white border border-gray-200 py-4 rounded-xl text-[10px] font-black uppercase tracking-widest text-gray-400 hover:text-dark hover:border-dark transition-all"
                       >
                         {t.pyme_view.calendar.reminder || 'Recordatorio'}
                       </button>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <div className="bg-gradient-to-br from-dark to-gray-800 p-8 rounded-[3rem] text-white shadow-xl shadow-dark/20 relative overflow-hidden">
         <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-bl-[10rem] -mr-32 -mt-32" />
         <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="flex items-center gap-4">
               <div className="bg-white/10 p-4 rounded-2xl backdrop-blur-xl border border-white/10">
                  <Info className="w-8 h-8 text-amber-500" />
               </div>
               <div>
                 <span className="text-[10px] font-black uppercase tracking-[0.3em] opacity-50">{t.pyme_view.calendar.suggestion_label || 'Sugerencia Fiscal Automática'}</span>
                 <p className="text-lg font-bold leading-relaxed max-w-xl">{t.pyme_view.calendar.suggestion_text || 'Optimiza tu flujo de efectivo: Programa tus pagos de impuestos 48 horas antes para evitar recargos bancarios.'}</p>
               </div>
            </div>
            <button 
               onClick={() => showToast(t.pyme_view.calendar.suggestion_toast || '✓ Avisos y recordatorios sincronizados con el calendario')}
               className="bg-white text-dark px-8 py-4 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-gray-100 transition-all shadow-xl"
            >
               {t.pyme_view.calendar.suggestion_btn || 'Configurar Avisos'}
            </button>
         </div>
      </div>
    </div>
  );
}

function PYMEDIOT() {
  const { showToast, t } = useAppContext();
  const [isGenerating, setIsGenerating] = useState(false);

  const diotRecords = [
    { rfc: 'PLO920315K82', name: 'Papelería Lozano SA de CV', type: 'Adquisición de bienes', subtotal: 12400.50, iva: 1984.08, total: 14384.58 },
    { rfc: 'ITS080512M31', name: 'IT Services Consultoria SC', type: 'Prestación de servicios', subtotal: 50000.00, iva: 8000.00, total: 58000.00 },
    { rfc: 'GAA991231H12', name: 'Gasolinera Aeropuerto SA', type: 'Adquisición de bienes', subtotal: 850.00, iva: 136.00, total: 986.00 },
  ];

  const generateLayout = () => {
    setIsGenerating(true);
    setTimeout(() => {
      setIsGenerating(false);
      showToast(t.pyme_view.diot.layout_toast || "✓ Layout DIOT (.txt) generado correctamente");
    }, 2000);
  };

  return (
    <div className="space-y-6 pb-20">
      <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-gray-100 flex flex-col md:flex-row justify-between items-center gap-6">
        <div className="flex items-center gap-4">
          <div className="bg-indigo-50 p-4 rounded-3xl">
            <ClipboardList className="w-8 h-8 text-indigo-600" />
          </div>
          <div>
            <h2 className="text-2xl font-black text-dark">{t.pyme_view.diot.title}</h2>
            <p className="text-xs text-gray-400 font-bold uppercase tracking-widest mt-1">{t.pyme_view.diot.subtitle}</p>
          </div>
        </div>
        <div className="flex gap-3">
          <select className="bg-gray-50 border border-gray-100 rounded-2xl px-5 py-3 text-sm font-bold outline-none focus:ring-2 focus:ring-indigo-500/20">
            <option>{t.common.months.oct || 'Octubre'} 2025</option>
            <option>{t.common.months.sep || 'Septiembre'} 2025</option>
          </select>
          <button 
            onClick={generateLayout}
            disabled={isGenerating}
            className="bg-dark text-white px-8 py-3.5 rounded-2xl font-black transition-all flex items-center gap-2.5 shadow-xl shadow-dark/20 active:scale-95"
          >
            {isGenerating ? (
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <FileDown className="w-5 h-5 text-secondary" />
            )}
            <span>{t.pyme_view.diot.generate_layout || 'Generar Layout .txt'}</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm col-span-2">
          <h3 className="text-sm font-black text-dark uppercase tracking-widest mb-6">{t.pyme_view.diot.detail_title || 'Detalle de Operaciones'}</h3>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="text-left border-b border-gray-50">
                  <th className="pb-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">Proveedor / RFC</th>
                  <th className="pb-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">Tipo</th>
                  <th className="pb-4 text-[10px] font-black text-gray-400 uppercase tracking-widest text-right">IVA Pagado</th>
                  <th className="pb-4 text-[10px] font-black text-gray-400 uppercase tracking-widest text-right">Monto Total</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {diotRecords.map((rec, i) => (
                  <tr key={i} className="group hover:bg-gray-50/50 transition-colors">
                    <td className="py-5">
                      <p className="text-sm font-bold text-dark">{rec.name}</p>
                      <p className="text-[10px] font-medium text-gray-400 uppercase tracking-wider">{rec.rfc}</p>
                    </td>
                    <td className="py-5">
                      <span className="text-[10px] font-black bg-blue-50 text-blue-600 px-2.5 py-1 rounded-lg uppercase">{rec.type}</span>
                    </td>
                    <td className="py-5 text-right font-black text-dark text-sm">${rec.iva.toLocaleString()}</td>
                    <td className="py-5 text-right font-black text-dark text-sm">${rec.total.toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-gradient-to-br from-indigo-600 to-indigo-800 p-8 rounded-[2rem] text-white shadow-xl shadow-indigo-200">
            <div className="flex items-center gap-3 mb-6">
               <div className="bg-white/20 p-2 rounded-xl backdrop-blur-md">
                 <ShieldCheck className="w-5 h-5" />
               </div>
               <span className="text-[10px] font-black uppercase tracking-widest opacity-80">Cumplimiento Fiscal</span>
            </div>
            <p className="text-2xl font-black mb-2">$9,944.08</p>
            <p className="text-xs font-medium opacity-80 leading-relaxed">IVA acreditable total detectado en Octubre para reporte DIOT.</p>
            <div className="mt-8 pt-6 border-t border-white/20">
               <p className="text-[10px] font-black uppercase tracking-widest opacity-60 mb-3">Fecha Límite</p>
               <div className="flex justify-between items-center text-sm font-black">
                 <span>17 de Noviembre, 2025</span>
                 <span className="bg-white/20 px-3 py-1 rounded-lg text-[9px] uppercase">Faltan 18 días</span>
               </div>
            </div>
          </div>

          <div className="bg-amber-50 border border-amber-100 p-6 rounded-[2rem]">
             <div className="flex items-center gap-3 mb-3">
                <AlertCircle className="w-5 h-5 text-amber-500" />
                <h4 className="text-amber-800 font-black text-sm">Validación IA</h4>
             </div>
             <p className="text-xs text-amber-900/70 font-medium leading-relaxed">
               Se detectaron 2 facturas de proveedores extranjeros que requieren tratamiento especial de IVA virtual para el layout DIOT.
             </p>
             <button className="mt-4 text-[10px] font-black text-amber-500 uppercase tracking-widest hover:underline">Ver inconsistencias</button>
          </div>
        </div>
      </div>
    </div>
  );
}

function PYMEConciliacion() {
  const { showToast, t } = useAppContext();
  const [matchingStatus, setMatchingStatus] = useState<Record<number, number | null>>({});
  const [isAutoMatching, setIsAutoMatching] = useState(false);

  const bankMovements = [
    { id: 101, date: `15-${t.common.months.apr}-2026`, desc: 'TRANSFERENCIA SALIENTE', amount: 1540.50, ref: 'PAPELERIA-NORTE' },
    { id: 102, date: `12-${t.common.months.apr}-2026`, desc: 'PAGO SPEI', amount: 3400.00, ref: 'PL-LOZANO' },
    { id: 103, date: `21-${t.common.months.apr}-2026`, desc: 'COMISION BANCARIA', amount: 250.00, ref: 'SERV-MEN' },
    { id: 104, date: `20-${t.common.months.apr}-2026`, desc: 'TRANSFERENCIA SALIENTE', amount: 28000.00, ref: 'IT-SERVICES' },
  ];

  const pendingCFDIs = [
    { id: 201, date: `15-Oct-2025`, emisor: 'Papelería Lozano SA', amount: 3400.00 },
    { id: 202, date: `20-Oct-2025`, emisor: 'IT Services Consultoria', amount: 28000.00 },
    { id: 203, date: `18-Oct-2025`, emisor: 'Gasolinera Aeropuerto', amount: 1200.00 },
  ];

  const handleDragOver = (e: DragEvent) => e.preventDefault();
  
  const handleDrop = (moveId: number, cfdiId: number) => {
    setMatchingStatus(prev => ({ ...prev, [moveId]: cfdiId }));
    showToast(t.pyme_view.reconciliation.manual_toast || "✓ Emparejamiento manual realizado");
  };

  const runAutoMatch = () => {
    setIsAutoMatching(true);
    setTimeout(() => {
      setMatchingStatus({
        102: 201,
        104: 202
      });
      setIsAutoMatching(false);
      showToast(t.pyme_view.reconciliation.auto_toast || "✓ Conciliación completada — 2 inconsistencias detectadas");
    }, 2000);
  };

  const matchedCount = Object.keys(matchingStatus).filter(k => matchingStatus[parseInt(k)] !== null).length;

  return (
    <div className="space-y-6">
      <div className="bg-white p-7 rounded-[2rem] shadow-sm border border-gray-100 flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-black text-dark text-emerald-600">{t.pyme_view.reconciliation.title}</h2>
          <p className="text-xs text-gray-400 font-medium tracking-tight">{t.pyme_view.reconciliation.subtitle}</p>
        </div>
        <div className="flex gap-4 items-center">
          <div className="bg-gray-50 px-5 py-2.5 rounded-2xl border border-gray-100">
             <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest mr-3">{t.pyme_view.reconciliation.progress}</span>
             <span className="text-sm font-black text-dark">{matchedCount} {t.pyme_view.reconciliation.of} {bankMovements.length} {t.pyme_view.reconciliation.matched}</span>
          </div>
          <button 
            onClick={runAutoMatch}
            disabled={isAutoMatching}
            className="bg-dark text-white px-8 py-3.5 rounded-2xl font-black transition-all flex items-center gap-2.5 shadow-xl shadow-dark/20 active:scale-95 disabled:opacity-50"
          >
            {isAutoMatching ? (
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <Bot className="w-5 h-5 text-secondary" />
            )}
            <span>{t.pyme_view.reconciliation.auto_btn}</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 relative">
        {/* Columna Izquierda: Bancos */}
        <div className="space-y-4">
           <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.3em] px-4">{t.pyme_view.reconciliation.bank_moves}</h3>
           <div className="space-y-3">
             {bankMovements.map((move) => {
               const isMatched = matchingStatus[move.id] !== undefined;
               return (
                 <div 
                   key={move.id}
                   draggable={!isMatched}
                   onDragStart={(e) => e.dataTransfer.setData("moveId", move.id.toString())}
                   className={`p-6 rounded-[2rem] border transition-all ${
                     isMatched 
                       ? 'bg-green-50 border-green-100' 
                       : 'bg-white border-gray-100 shadow-sm hover:shadow-md cursor-move group'
                   }`}
                 >
                   <div className="flex justify-between items-start">
                     <div className="flex items-center gap-4">
                        <div className={`p-3 rounded-2xl ${isMatched ? 'bg-white text-green-600' : 'bg-gray-50 text-gray-400 group-hover:text-dark transition-colors'}`}>
                           <CreditCard className="w-6 h-6" />
                        </div>
                        <div>
                          <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{move.date}</p>
                          <h4 className="font-bold text-dark">{move.desc}</h4>
                          <p className="text-xs text-gray-500 italic mt-0.5">REF: {move.ref}</p>
                        </div>
                     </div>
                     <div className="text-right">
                        <p className="text-lg font-black text-dark">-${move.amount.toLocaleString()}</p>
                        {isMatched ? (
                          <span className="text-[9px] font-black text-green-600 uppercase bg-white px-2 py-1 rounded-lg mt-2 inline-block">{t.pyme_view.payroll.status_paid || 'Conciliado ✓'}</span>
                        ) : (
                          <span className="text-[9px] font-black text-amber-500 uppercase bg-amber-50 px-2 py-1 rounded-lg mt-2 inline-block animate-pulse">{t.pyme_view.payroll.status_pending || 'Pendiente ⚠'}</span>
                        )}
                     </div>
                   </div>
                 </div>
               );
             })}
           </div>
        </div>

        {/* Columna Derecha: CFDI */}
        <div className="space-y-4">
           <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.3em] px-4">{t.pyme_view.reconciliation.pending_cfdi}</h3>
           <div className="space-y-3">
             {pendingCFDIs.map((cfdi) => {
               const isTargetOfMatch = Object.values(matchingStatus).includes(cfdi.id);
               return (
                 <div 
                   key={cfdi.id}
                   onDragOver={handleDragOver}
                   onDrop={(e) => {
                     const moveId = parseInt(e.dataTransfer.getData("moveId"));
                     if (moveId) handleDrop(moveId, cfdi.id);
                   }}
                   className={`p-6 rounded-[2rem] border-2 border-dashed transition-all ${
                     isTargetOfMatch 
                       ? 'bg-blue-50 border-blue-200' 
                       : 'bg-gray-50 border-gray-100 hover:border-dark/20'
                   }`}
                 >
                   <div className="flex justify-between items-center">
                     <div className="flex items-center gap-4">
                        <div className="bg-white p-3 rounded-2xl shadow-sm">
                           <FileCode className="w-6 h-6 text-dark" />
                        </div>
                        <div>
                          <p className="text-sm font-bold text-dark">{cfdi.emisor}</p>
                          <p className="text-[10px] text-gray-400 font-bold uppercase">{cfdi.date}</p>
                        </div>
                     </div>
                     <p className="text-lg font-black text-dark">${cfdi.amount.toLocaleString()}</p>
                   </div>
                   {isTargetOfMatch && (
                     <div className="mt-4 pt-4 border-t border-blue-100 flex items-center gap-2 text-blue-600 text-xs font-bold">
                       <Link className="w-4 h-4" /> {t.pyme_view.reconciliation.matched_success}
                     </div>
                   )}
                 </div>
               );
             })}
           </div>
        </div>
      </div>
    </div>
  );
}

function PYMEAlertas() {
  const { showToast, t } = useAppContext();
  const [expandedAlert, setExpandedAlert] = useState<number | null>(null);
  const [showExpensesModal, setShowExpensesModal] = useState(false);
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [emailBody, setEmailBody] = useState('');
  const [isScanning, setIsScanning] = useState(false);

  const handleScan = () => {
    setIsScanning(true);
    setTimeout(() => {
      setIsScanning(false);
      showToast(t.pyme_view.alerts.scan_toast || '✓ Escaneo de inconsistencias actualizado');
    }, 1500);
  };

  const alerts = [
    { 
      id: 1,
      icon: AlertCircle, 
      color: 'text-red-500', 
      bg: 'bg-red-50', 
      title: t.pyme_view.alerts?.list?.[0]?.title || 'Declaración mensual atrasada', 
      desc: t.pyme_view.alerts?.list?.[0]?.desc || 'Tu contador no ha subido el acuse de la declaración de Octubre.', 
      status: t.pyme_view.alerts?.list?.[0]?.status || 'Crítica',
      details: [
        { label: t.pyme_view.alerts?.list?.[0]?.d1 || 'Carga de XML de Ingresos', done: true },
        { label: t.pyme_view.alerts?.list?.[0]?.d2 || 'Carga de XML de Egresos', done: true },
        { label: t.pyme_view.alerts?.list?.[0]?.d3 || 'Conciliación Bancaria', done: true },
        { label: t.pyme_view.alerts?.list?.[0]?.d4 || 'Generación de Acuse SAT', done: false, critical: true }
      ],
      aiSuggestion: t.pyme_view.alerts?.list?.[0]?.ai || 'Notamos que el portal del SAT ya muestra la información de ingresos procesada. Notifica a tu contador para que proceda con el cierre.',
      actionLabel: t.pyme_view.alerts?.list?.[0]?.action || 'Notificar al Contador'
    },
    { 
      id: 2,
      icon: ShieldAlert, 
      color: 'text-amber-500', 
      bg: 'bg-amber-50', 
      title: t.pyme_view.alerts?.list?.[1]?.title || 'Facturas canceladas', 
      desc: t.pyme_view.alerts?.list?.[1]?.desc || 'Un proveedor canceló 2 facturas que ya habías pagado.', 
      status: t.pyme_view.alerts?.list?.[1]?.status || 'Requiere atención',
      details: [
        { label: t.pyme_view.alerts?.list?.[1]?.d1 || 'UUID 459-F32 (Gasolinera)', done: false },
        { label: t.pyme_view.alerts?.list?.[1]?.d2 || 'UUID 112-A88 (Papelería)', done: false }
      ],
      aiSuggestion: t.pyme_view.alerts?.list?.[1]?.ai || 'Estas facturas corresponden a pagos ya realizados. La cancelación podría afectar tu deducción de IVA de este periodo.',
      actionLabel: t.pyme_view.alerts?.list?.[1]?.action || 'Contactar Proveedor'
    },
    { 
      id: 3,
      icon: TrendingUp, 
      color: 'text-blue-500', 
      bg: 'bg-blue-50', 
      title: t.pyme_view.alerts?.list?.[2]?.title || 'Límite de efectivo mensual', 
      desc: t.pyme_view.alerts?.list?.[2]?.desc || 'Estás a $2,500 de superar tu límite permitido para pagos en efectivo.', 
      status: t.pyme_view.alerts?.list?.[2]?.status || 'Informativa',
      progress: 85,
      limit: '$50,000 MXN',
      current: '$47,500 MXN',
      details: [
        { label: t.pyme_view.alerts?.list?.[2]?.d1 || 'Gasto máximo recomendado', done: true },
        { label: t.pyme_view.alerts?.list?.[2]?.d2 || 'Evitar multas por efectivo', done: false }
      ],
      aiSuggestion: t.pyme_view.alerts?.list?.[2]?.ai || 'Mueve tus pagos recurrentes de servicios a domiciliación bancaria para liberar cupo de efectivo para gastos menores.',
      actionLabel: t.pyme_view.alerts?.list?.[2]?.action || 'Ver detalles de gastos'
    },
  ];

  const handleResolve = (id: number) => {
    showToast(`✓ Alerta #${id} marcada como resuelta`);
    setExpandedAlert(null);
  };

  const handleIgnore = (id: number) => {
    showToast(`⚠ Alerta #${id} será ignorada temporalmente`);
    setExpandedAlert(null);
  };

  return (
    <div className="bg-white rounded-[2.5rem] shadow-xl border border-gray-100 overflow-hidden flex flex-col min-h-screen">
      <div className="p-8 border-b border-gray-100 bg-white flex justify-between items-center">
        <div>
          <h3 className="text-2xl font-black text-dark">{t.pyme_view.alerts.title}</h3>
          <p className="text-sm text-gray-400 font-medium mt-1">{t.pyme_view.alerts.subtitle}</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="bg-red-50 text-red-600 px-4 py-2 rounded-2xl text-[10px] font-black uppercase tracking-widest border border-red-100 flex items-center gap-2">
            <div className="w-2 h-2 bg-red-600 rounded-full animate-ping" />
            {alerts.filter(a => a.status === (t.pyme_view.alerts.critical || 'Crítica')).length} {t.pyme_view.alerts.critical || 'Críticas'}
          </div>
          <button onClick={handleScan} className="p-3 bg-gray-50 rounded-2xl hover:bg-gray-100 transition-colors">
            <RefreshCw className={`w-5 h-5 text-gray-400 ${isScanning ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>
      
      <div className="flex-1 p-8 space-y-6 bg-gray-50/20 pb-32">
        {alerts.map((alt, i) => (
          <div 
            key={alt.id} 
            className={`group rounded-[2.5rem] border transition-all overflow-hidden bg-white ${
              expandedAlert === i 
                ? 'border-dark/10 shadow-2xl ring-4 ring-dark/5' 
                : 'border-gray-100 hover:border-gray-200 shadow-sm'
            }`}
          >
            <button 
              onClick={() => setExpandedAlert(expandedAlert === i ? null : i)}
              className="w-full flex gap-6 p-6 text-left transition-colors"
            >
              <div className={`${alt.bg} ${alt.color} w-16 h-16 rounded-[1.5rem] shrink-0 flex items-center justify-center transition-transform group-hover:scale-105 shadow-sm`}>
                 <alt.icon className="w-8 h-8"/>
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-extrabold text-dark text-lg truncate pr-3">{alt.title}</h4>
                  <span className={`text-[9px] uppercase font-black px-3 py-1.5 rounded-xl shrink-0 ${
                    alt.status === (t.pyme_view.alerts.critical || 'Crítica') ? 'bg-red-100 text-red-700 shadow-sm' : 
                    alt.status === (t.pyme_view.alerts.info || 'Informativa') ? 'bg-blue-100 text-blue-700 shadow-sm' : 
                    'bg-amber-100 text-amber-700 shadow-sm'
                  }`}>
                    {alt.status}
                  </span>
                </div>
                <p className="text-sm text-gray-500 leading-relaxed font-semibold">{alt.desc}</p>
              </div>
            </button>

            <AnimatePresence>
              {expandedAlert === i && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="px-6 pb-8 border-t border-gray-50"
                >
                  <div className="pt-8 space-y-8">
                    {/* IA Suggestion Section */}
                    <div className="bg-blue-50/50 rounded-[2rem] p-6 border border-blue-100/50 flex gap-4">
                       <div className="bg-white p-3 rounded-2xl shadow-sm h-fit">
                          <BrainCircuit className="w-6 h-6 text-blue-600" />
                       </div>
                       <div>
                          <p className="text-[10px] font-black text-blue-400 uppercase tracking-[0.2em] mb-2">Sugerencia IA de Puente Contable</p>
                          <p className="text-sm font-bold text-blue-900 leading-relaxed">{alt.aiSuggestion}</p>
                       </div>
                    </div>

                    {alt.progress !== undefined && (
                      <div className="bg-gray-50/50 rounded-[2rem] p-6 border border-gray-100">
                        <div className="flex justify-between items-end mb-3">
                           <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Utilización de Límite ({alt.current} / {alt.limit})</span>
                           <span className={`text-sm font-black ${alt.progress > 80 ? 'text-amber-500' : 'text-blue-500'}`}>{alt.progress}%</span>
                        </div>
                        <div className="h-4 w-full bg-white border border-gray-200 rounded-full overflow-hidden shadow-inner">
                          <motion.div 
                            initial={{ width: 0 }}
                            animate={{ width: `${alt.progress}%` }}
                            className={`h-full rounded-full ${alt.progress > 80 ? 'bg-amber-500' : 'bg-blue-500'}`}
                          ></motion.div>
                        </div>
                      </div>
                    )}

                    {alt.id === 1 && (
                      <div className="bg-gray-50/50 rounded-[2rem] p-6 border border-gray-100 flex flex-col items-center">
                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-5 self-start">Impacto de Recargos Estimados</p>
                        <div className="w-full max-w-sm flex items-end justify-between h-32 px-4">
                           <div className="w-16 bg-blue-100 rounded-t-xl h-4 relative flex justify-center"><span className="absolute -top-6 text-xs font-bold text-gray-500">Día 1</span></div>
                           <div className="w-16 bg-blue-200 rounded-t-xl h-8 relative flex justify-center"><span className="absolute -top-6 text-xs font-bold text-gray-500">Día 5</span></div>
                           <div className="w-16 bg-blue-300 rounded-t-xl h-14 relative flex justify-center"><span className="absolute -top-6 text-xs font-bold text-gray-500">Día 10</span></div>
                           <div className="w-16 bg-red-400 rounded-t-xl h-24 relative flex justify-center shadow-[0_0_15px_rgba(248,113,113,0.5)]"><span className="absolute -top-6 text-xs font-black text-red-600">{t.pyme_view.alerts.today || 'Hoy'}</span></div>
                        </div>
                        <div className="w-full bg-gray-200 h-px mt-2" />
                        <p className="text-xs text-gray-400 mt-4 font-medium text-center">Tasa de recargo acumulada proyectada si no se paga hoy.</p>
                      </div>
                    )}

                    {alt.id === 2 && (
                      <div className="bg-gray-50/50 rounded-[2rem] p-6 border border-gray-100">
                         <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-5">{t.pyme_view.alerts.reconciliation_summary || 'Conciliación de Pagos vs Facturas'}</p>
                         <div className="flex gap-4 items-center">
                           <div className="flex-1 bg-white p-4 rounded-xl border border-gray-200 text-center">
                             <p className="text-xl font-black text-dark">$14,500</p>
                             <p className="text-[10px] text-gray-400 font-bold uppercase">{t.pyme_view.alerts.paid || 'Pagado'}</p>
                           </div>
                           <TrendingUp className="w-6 h-6 text-gray-300" />
                           <div className="flex-1 bg-red-50 p-4 rounded-xl border border-red-100 text-center">
                             <p className="text-xl font-black text-red-600">$0</p>
                             <p className="text-[10px] text-red-400 font-bold uppercase">{t.pyme_view.alerts.valid_cfdi || 'CFDI Válidos'}</p>
                           </div>
                         </div>
                         <p className="text-xs text-gray-500 mt-4 text-center">Existe una discrepancia de $14,500 MXN sin comprobar debido a las cancelaciones.</p>
                      </div>
                    )}

                    <div className="bg-gray-50/50 rounded-[2rem] p-6 border border-gray-50">
                      <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-5">{t.pyme_view.alerts.resolution_milestones || 'Hitos de Resolución'}</p>
                      <div className="space-y-4">
                        {alt.details.map((detail, idx) => (
                          <div key={idx} className="flex items-center justify-between group/item">
                            <div className="flex items-center gap-4">
                              <div className={`w-6 h-6 rounded-full flex items-center justify-center border shadow-sm ${
                                detail.done 
                                  ? 'bg-green-100 border-green-200 text-green-600' 
                                  : detail.critical ? 'bg-red-100 border-red-200 text-red-600' : 'bg-white border-gray-200'
                              }`}>
                                {detail.done ? (
                                  <CheckCircle2 className="w-4 h-4" />
                                ) : (
                                  <div className={`w-2 h-2 rounded-full ${detail.critical ? 'bg-red-500 animate-pulse' : 'bg-gray-300'}`} />
                                )}
                              </div>
                              <span className={`text-base font-bold ${
                                detail.done ? 'text-gray-400 line-through decoration-2' : 'text-dark'
                              }`}>
                                {detail.label}
                              </span>
                            </div>
                            {!detail.done && detail.critical && (
                              <span className="text-[9px] font-black text-red-600 uppercase bg-red-50 px-3 py-1 rounded-lg border border-red-100">Acción Requerida</span>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="flex flex-col sm:flex-row gap-3 pt-2">
                       <button 
                        onClick={() => {
                          if (alt.id === 3) {
                            setShowExpensesModal(true);
                          } else {
                            handleResolve(alt.id);
                          }
                        }}
                        className="flex-1 py-5 rounded-[1.5rem] bg-dark text-white text-xs font-black uppercase tracking-widest hover:bg-black transition-all active:scale-[0.98] shadow-xl shadow-dark/20 flex items-center justify-center gap-2"
                      >
                        <Check className="w-4 h-4" /> Resolve: {alt.actionLabel}
                      </button>
                      <div className="flex gap-3 h-full">
                        <button 
                          onClick={() => handleIgnore(alt.id)}
                          className="px-6 py-5 rounded-[1.5rem] bg-gray-50 text-gray-500 text-xs font-black uppercase tracking-widest hover:bg-gray-100 transition-all active:scale-[0.98] border border-gray-100"
                        >
                          Ignorar
                        </button>
                        <button 
                          onClick={() => {
                            setEmailBody(`Referencia: Alerta ${alt.title}\n\nHola,\nTe escribo para notificar y dar seguimiento a la siguiente alerta fiscal:\n\n${alt.desc}\n\nSugerencia del sistema: ${alt.aiSuggestion}\n\nQuedo a la espera de tus comentarios.`);
                            setShowEmailModal(true);
                          }}
                          className="px-6 py-5 rounded-[1.5rem] bg-gray-50 text-gray-500 text-xs font-black uppercase tracking-widest hover:bg-gray-100 transition-all active:scale-[0.98] border border-gray-100"
                        >
                          <Mail className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ))}
      </div>

      <AnimatePresence>
        {showExpensesModal && (
          <ExpensesDetailModal onClose={() => setShowExpensesModal(false)} />
        )}
        {showEmailModal && (
          <div className="fixed inset-0 z-[400] bg-dark/60 backdrop-blur-md flex items-center justify-center p-4" onClick={() => setShowEmailModal(false)}>
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white w-full max-w-lg rounded-[3rem] shadow-2xl relative overflow-hidden"
              onClick={e => e.stopPropagation()}
            >
              <div className="p-8 pb-4 border-b border-gray-100 flex justify-between items-center">
                <div>
                  <h3 className="text-xl font-black text-dark">Enviar Correo</h3>
                  <p className="text-sm text-gray-500 font-medium mt-1">Notificar de la alerta detectada</p>
                </div>
                <button onClick={() => setShowEmailModal(false)} className="p-2 hover:bg-gray-100 rounded-xl transition-colors"><XCircle className="w-6 h-6 text-gray-400" /></button>
              </div>
              <div className="p-8 space-y-6">
                <div>
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 block">Mensaje Automático</label>
                  <textarea 
                    value={emailBody}
                    onChange={(e) => setEmailBody(e.target.value)}
                    className="w-full bg-gray-50 border border-gray-100 rounded-2xl p-4 text-sm text-dark font-medium leading-relaxed resize-none h-48 focus:outline-none focus:ring-2 focus:ring-secondary/20"
                  />
                </div>
                <button 
                  onClick={() => {
                    showToast("✓ Correo enviado al contacto.");
                    setShowEmailModal(false);
                  }}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white py-4 rounded-2xl font-black transition-all flex justify-center items-center gap-2"
                >
                  <Mail className="w-5 h-5" /> Enviar Correo Electrónico
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function ExpensesDetailModal({ onClose }: { onClose: () => void }) {
  const expenseData = [
    { category: 'Materiales', amount: 15400, color: '#10B981' },
    { category: 'Servicios', amount: 8200, color: '#3B82F6' },
    { category: 'Renta', amount: 12000, color: '#6366F1' },
    { category: 'Efectivo', amount: 11900, color: '#F59E0B' },
  ];

  const historicalData = [
    { month: 'Jul', cash: 32000 },
    { month: 'Ago', cash: 41000 },
    { month: 'Sep', cash: 38000 },
    { month: 'Oct', cash: 47500 },
  ];

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[300] bg-dark/40 backdrop-blur-md flex items-center justify-center p-4 lg:p-10"
      onClick={onClose}
    >
      <motion.div 
        initial={{ scale: 0.95, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.95, y: 20 }}
        className="bg-white w-full max-w-5xl h-full flex flex-col rounded-[3rem] shadow-2xl overflow-hidden"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-8 border-b border-gray-100 flex justify-between items-center bg-gray-50/30">
          <div className="flex items-center gap-4">
            <div className="bg-blue-100 p-3 rounded-2xl">
              <TrendingUp className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-dark">Detalle de Gastos y Efectivo</h2>
              <p className="text-sm text-gray-400 font-medium tracking-tight">Análisis detallado de egresos mensuales</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-3 hover:bg-gray-100 rounded-2xl transition-colors text-gray-400 hover:text-dark"
          >
            <XCircle className="w-8 h-8" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-8 bg-white lg:grid lg:grid-cols-12 lg:gap-8">
          {/* Left Side: Summary & Progress */}
          <div className="lg:col-span-4 space-y-6">
            <div className="bg-gray-50 border border-gray-100 p-6 rounded-[2rem]">
              <div className="flex items-center justify-between mb-4">
                <span className="text-[10px] font-black uppercase tracking-widest text-gray-400">Estado de Límite</span>
                <span className="bg-amber-100 text-amber-600 px-2.5 py-1 rounded-lg text-[10px] font-black uppercase">Crítico (85%)</span>
              </div>
              <div className="text-center mb-6">
                <p className="text-xs text-gray-500 font-bold mb-1">Gasto en Efectivo Acumulado</p>
                <h3 className="text-4xl font-black text-dark">$47,500 <span className="text-xl text-gray-300">MXN</span></h3>
              </div>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-[11px] font-bold mb-1.5">
                    <span className="text-gray-400 uppercase">Progreso del Límite</span>
                    <span className="text-amber-500">85%</span>
                  </div>
                  <div className="h-4 w-full bg-white border border-gray-200 rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: '85%' }}
                      className="h-full bg-amber-500 rounded-full"
                    />
                  </div>
                </div>
                <div className="flex justify-between items-center text-[11px] text-gray-500 font-medium">
                  <span>Iniciado: $0</span>
                  <span>Límite: $50,000</span>
                </div>
              </div>
            </div>

            <div className="bg-blue-50 border border-blue-100 p-6 rounded-[2rem] flex items-center gap-4">
              <div className="bg-white p-3 rounded-2xl shadow-sm">
                <DollarSign className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <p className="text-[10px] font-black text-blue-400 uppercase tracking-widest mb-0.5">Sugerencia IA</p>
                <p className="text-xs font-bold text-blue-900 leading-snug">"Te recomendamos realizar tus próximos pagos vía transferencia para evitar multas fiscales."</p>
              </div>
            </div>

            <div className="space-y-3">
               <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Egresos por Categoría</h4>
               {expenseData.map((item, idx) => (
                 <div key={idx} className="flex justify-between items-center bg-white border border-gray-50 p-4 rounded-2xl shadow-sm">
                    <div className="flex items-center gap-3">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                      <span className="text-sm font-bold text-dark">{item.category}</span>
                    </div>
                    <span className="text-sm font-black text-gray-500">${item.amount.toLocaleString()}</span>
                 </div>
               ))}
            </div>
          </div>

          {/* Right Side: Charts */}
          <div className="lg:col-span-8 space-y-8 mt-8 lg:mt-0">
             {/* Main Chart Card */}
             <div className="bg-white border border-gray-100 rounded-[2.5rem] shadow-sm overflow-hidden">
                <div className="p-6 border-b border-gray-50 flex items-center justify-between">
                   <div className="flex items-center gap-3">
                     <Activity className="w-5 h-5 text-gray-400" />
                     <h3 className="font-bold text-dark">Tendencia de Gasto en Efectivo</h3>
                   </div>
                   <div className="flex gap-2">
                     <span className="text-[10px] font-black bg-gray-100 text-gray-500 px-3 py-1 rounded-full uppercase">Últimos 4 meses</span>
                   </div>
                </div>
                <div className="h-64 sm:h-80 w-full p-4">
                  <ResponsiveContainer width="100%" height="100%" minWidth={1} minHeight={1}>
                    <BarChart data={historicalData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F3F4F6" />
                      <XAxis 
                        dataKey="month" 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{ fill: '#9CA3AF', fontWeight: 'bold', fontSize: 12 }}
                      />
                      <YAxis 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{ fill: '#9CA3AF', fontWeight: 'bold', fontSize: 12 }}
                      />
                      <Tooltip 
                        cursor={{ fill: '#F9FAFB' }}
                        contentStyle={{ borderRadius: '1.5rem', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', padding: '1rem' }}
                      />
                      <Bar dataKey="cash" radius={[10, 10, 0, 0]} barSize={40}>
                         {historicalData.map((entry, index) => (
                           <Cell key={`cell-${index}`} fill={entry.cash > 45000 ? '#F59E0B' : '#E5E7EB'} />
                         ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
             </div>

             {/* Pie Chart & Distribution Card */}
             <div className="bg-white border border-gray-100 rounded-[2.5rem] shadow-sm overflow-hidden flex flex-col sm:flex-row divide-y sm:divide-y-0 sm:divide-x divide-gray-100">
                <div className="sm:w-1/2 p-6 flex flex-col items-center justify-center">
                   <div className="flex items-center gap-2 mb-4 w-full">
                     <PieIcon className="w-4 h-4 text-gray-400" />
                     <h3 className="text-sm font-bold text-dark">Distribución de Gastos</h3>
                   </div>
                   <div className="h-48 w-full">
                      <ResponsiveContainer width="100%" height="100%" minWidth={1} minHeight={1}>
                        <PieChart>
                          <Pie
                            data={expenseData}
                            cx="50%"
                            cy="50%"
                            innerRadius={60}
                            outerRadius={80}
                            paddingAngle={5}
                            dataKey="amount"
                          >
                            {expenseData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                          </Pie>
                          <Tooltip />
                        </PieChart>
                      </ResponsiveContainer>
                   </div>
                </div>
                <div className="sm:w-1/2 p-8 space-y-6">
                   <h4 className="text-lg font-black text-dark italic leading-tight">¿Hacia dónde va mi dinero?</h4>
                   <p className="text-sm text-gray-500 font-medium leading-relaxed">
                     La mayoría de tus gastos este mes se concentran en <span className="text-dark font-bold">Materiales</span>. Recuerda que puedes deducirlos al 100% si tienes el CFDI correcto.
                   </p>
                   <button className="flex items-center gap-2 text-blue-600 font-black text-xs uppercase tracking-widest hover:gap-3 transition-all">
                     Descargar Reporte Completo <ArrowRight className="w-4 h-4" />
                   </button>
                </div>
             </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 bg-gray-50 border-t border-gray-100 flex justify-center">
           <button 
             onClick={onClose}
             className="px-10 py-4 bg-dark text-white rounded-2xl font-black text-xs uppercase tracking-[0.2em] shadow-xl shadow-dark/20 hover:scale-105 transition-all"
           >
             Cerrar Ventana
           </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

function PYMEAsesor() {
  const { t } = useAppContext();
  const [messages, setMessages] = useState([
    { role: 'system', content: t.pyme_view.advisor.welcome }
  ]);
  const [input, setInput] = useState('');

  const sendPrompt = (text: string) => {
    if(!text.trim()) return;
    setMessages(p => [...p, { role: 'user', content: text }]);
    setInput('');
    const msg = text.toLowerCase();
    
    setTimeout(() => {
      let reply = t.pyme_view.advisor.default_reply;
      
      if (msg.includes('auto') || msg.includes('coche') || msg.includes('vehículo') || msg.includes('car')) reply = t.pyme_view.advisor.auto_reply;
      else if (msg.includes('comida') || msg.includes('restaurante') || msg.includes('food') || msg.includes('restaurant')) reply = t.pyme_view.advisor.restaurant_reply;
      else if (msg.includes('aguinaldo') || msg.includes('christmas')) reply = t.pyme_view.advisor.aguinaldo_reply;
      else if (msg.includes('contador') || msg.includes('accountant')) reply = t.pyme_view.advisor.accountant_reply;

      setMessages(p => [...p, { role: 'system', content: reply }]);
    }, 800);
  };

  const quickBtns = [
    { label: t.pyme_view.advisor.quick_btns.auto, val: t.pyme_view.advisor.quick_queries.auto },
    { label: t.pyme_view.advisor.quick_btns.restaurants, val: t.pyme_view.advisor.quick_queries.restaurants },
    { label: t.pyme_view.advisor.quick_btns.aguinaldos, val: t.pyme_view.advisor.quick_queries.aguinaldos }
  ];

  return (
    <div className="flex gap-6 h-[calc(100vh-140px)]">
      <div className="w-full lg:w-2/3 bg-white rounded-2xl shadow-sm border border-gray-100 flex flex-col overflow-hidden">
        <div className="p-4 border-b border-gray-100 bg-gray-50 flex items-center gap-3">
          <div className="bg-tertiary text-white p-2 rounded-lg"><Bot className="w-5 h-5"/></div>
          <div>
            <h3 className="font-semibold text-dark leading-none">{t.pyme_view.advisor.title}</h3>
            <span className="text-[11px] text-tertiary font-bold uppercase tracking-wider">{t.pyme_view.advisor.online}</span>
          </div>
        </div>
        
        <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-light/50">
          {messages.map((m, i) => (
            <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[80%] rounded-2xl p-4 text-sm whitespace-pre-wrap leading-relaxed ${
                m.role === 'user' 
                  ? 'bg-tertiary text-white rounded-br-sm shadow-md' 
                  : 'bg-white border border-gray-200 text-gray-800 rounded-bl-sm shadow-sm'
              }`}>
                {m.content}
              </div>
            </div>
          ))}
        </div>

        <div className="p-4 bg-white border-t border-gray-100">
          <div className="flex gap-2 mb-3 overflow-x-auto pb-1 hide-scrollbar">
             {quickBtns.map((b, i) => (
               <button 
                 key={i} 
                 onClick={() => sendPrompt(b.val)}
                 className="whitespace-nowrap px-3 py-1.5 bg-gray-100 hover:bg-tertiary-light hover:text-tertiary transition-colors rounded-full text-xs font-semibold text-gray-600"
               >
                 {b.label}
               </button>
             ))}
          </div>
          <div className="flex items-center gap-2">
            <input 
              type="text" 
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && sendPrompt(input)}
              placeholder={t.pyme_view.advisor.placeholder}
              className="flex-1 border border-gray-200 bg-gray-50 rounded-xl px-4 py-3 outline-none focus:border-tertiary focus:bg-white transition-colors text-sm"
            />
            <button 
              onClick={() => sendPrompt(input)}
              className="bg-tertiary hover:bg-tertiary-dark text-white p-3 rounded-xl transition-colors shadow-sm"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      <div className="hidden lg:flex w-1/3 flex-col gap-4">
        <div className="bg-blue-50 p-6 rounded-2xl border border-blue-200">
          <h4 className="font-bold text-blue-800 mb-2">{t.pyme_view.advisor.legal_notice_title}</h4>
          <p className="text-xs text-blue-700 leading-relaxed">
            {t.pyme_view.advisor.legal_notice_desc}
          </p>
        </div>
      </div>
    </div>
  );
}

function PYMEDirectorio() {
  const { showToast, t } = useAppContext();
  const [selectedState, setSelectedState] = useState('CDMX');
  const [selectedMunicipio, setSelectedMunicipio] = useState('');
  const [locModal, setLocModal] = useState(false);
  
  // States for hiring options
  const [selectedHirePro, setSelectedHirePro] = useState<any | null>(null);
  const [isCalling, setIsCalling] = useState(false);
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [emailBody, setEmailBody] = useState(t.pyme_view.directory.hiring.email_default_body || 'Hola, mi empresa está buscando asesoría contable especializada. Me gustaría agendar una reunión para discutir nuestra situación fiscal.');
  const [showWaModal, setShowWaModal] = useState(false);
  const [waMessage, setWaMessage] = useState(t.pyme_view.directory.hiring.wa_default_body || 'Hola, vi el perfil de su despacho en Puente contable y nos interesa una propuesta para nuestra PYME.');

  const MEXICO_LOCATIONS: Record<string, string[]> = {
    'Aguascalientes': ['Aguascalientes', 'Asientos', 'Calvillo'],
    'Baja California': ['Ensenada', 'Mexicali', 'Tijuana'],
    'Baja California Sur': ['La Paz', 'Los Cabos'],
    'Campeche': ['Campeche', 'Ciudad del Carmen'],
    'Chiapas': ['Tuxtla Gutiérrez', 'San Cristóbal de las Casas', 'Tapachula'],
    'Chihuahua': ['Chihuahua', 'Ciudad Juárez', 'Delicias', 'Cuauhtémoc'],
    'Coahuila': ['Saltillo', 'Torreón', 'Monclova'],
    'Colima': ['Colima', 'Manzanillo', 'Villa de Álvarez'],
    'CDMX': ['Benito Juárez', 'Coyoacán', 'Cuauhtémoc', 'Miguel Hidalgo', 'Álvaro Obregón', 'Tlalpan'],
    'Durango': ['Durango', 'Gómez Palacio', 'Lerdo'],
    'Guanajuato': ['León', 'Irapuato', 'Celaya', 'Guanajuato', 'Salamanca'],
    'Guerrero': ['Acapulco', 'Chilpancingo', 'Iguala', 'Zihuatanejo'],
    'Hidalgo': ['Pachuca', 'Tulancingo', 'Tizayuca'],
    'Jalisco': ['Guadalajara', 'Zapopan', 'Tlaquepaque', 'Tonalá', 'Puerto Vallarta'],
    'México': ['Toluca', 'Ecapetec', 'Naucalpan', 'Tlalnepantla', 'Chimalhuacán'],
    'Michoacán': ['Morelia', 'Uruapan', 'Zamora'],
    'Morelos': ['Cuernavaca', 'Jiutepec', 'Cuautla'],
    'Nayarit': ['Tepic', 'Bahía de Banderas'],
    'Nuevo León': ['Monterrey', 'San Pedro Garza García', 'Guadalupe', 'Apodaca', 'San Nicolás'],
    'Oaxaca': ['Oaxaca de Juárez', 'San Juan Bautista Tuxtepec'],
    'Puebla': ['Puebla de Zaragoza', 'Tehuacán', 'San Andrés Cholula'],
    'Querétaro': ['Querétaro', 'San Juan del Río'],
    'Quintana Roo': ['Cancún', 'Playa del Carmen', 'Chetumal'],
    'San Luis Potosí': ['San Luis Potosí', 'Ciudad Valles'],
    'Sinaloa': ['Culiacán', 'Mazatlán', 'Los Mochis'],
    'Sonora': ['Hermosillo', 'Ciudad Obregón', 'Nogales'],
    'Tabasco': ['Villahermosa', 'Cárdenas'],
    'Tamaulipas': ['Reynosa', 'Matamoros', 'Nuevo Laredo', 'Tampico'],
    'Tlaxcala': ['Tlaxcala', 'Apizaco'],
    'Veracruz': ['Veracruz', 'Xalapa', 'Coatzacoalcos', 'Boca del Río'],
    'Yucatán': ['Mérida', 'Kanasín', 'Valladolid'],
    'Zacatecas': ['Zacatecas', 'Fresnillo', 'Guadalupe']
  };

  const PROS_DB: Record<string, Record<string, any[]>> = {
    'CDMX': {
      'Benito Juárez': [
        { name: 'C.P. Miguel Ríos', spec: 'PYME / Corporativo', stars: 4.9, dist: '0.8 km', img: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=200&h=200&fit=crop' },
        { name: 'Mtro. Arturo Vaca', spec: 'Fiscal / Auditoría', stars: 4.7, dist: '1.5 km', img: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&h=200&fit=crop' },
        { name: 'Lic. Brenda Ortiz', spec: 'Consultoría Estratégica', stars: 4.5, dist: '2.1 km', img: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&h=200&fit=crop' }
      ],
      'Miguel Hidalgo': [
        { name: 'C.P.C. Ana Soto', spec: 'Estrategia de Precios', stars: 4.8, dist: '2.3 km', img: 'https://images.unsplash.com/photo-1567532939604-b6b5b0db2604?w=200&h=200&fit=crop' },
        { name: 'Lic. Javier Duarte', spec: 'Nóminas Complejas', stars: 4.6, dist: 'Polanco', img: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=200&h=200&fit=crop' },
        { name: 'Despacho Polanco & Asoc.', spec: 'Fiscal Internacional', stars: 5.0, dist: '0.2 km', img: 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=200&h=200&fit=crop' }
      ],
      'Coyoacán': [
        { name: 'C.P. Elena Gómez', spec: 'Impuestos Locales', stars: 4.4, dist: 'Del Carmen', img: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=200&h=200&fit=crop' },
        { name: 'Mtro. Felipe Ruiz', spec: 'Auditoría Legal', stars: 4.9, dist: '0.9 km', img: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop' }
      ]
    },
    'Nuevo León': {
      'San Pedro Garza García': [
        { name: 'Despacho Consultores Elite', spec: 'Outsourcing Fiscal / Internacional', stars: 5.0, dist: 'Valle', img: 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=200&h=200&fit=crop' },
        { name: 'C.P. Carlos Mendoza', spec: 'Estrategia Fiscal Senior', stars: 4.9, dist: '0.5 km', img: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop' }
      ],
      'Monterrey': [
        { name: 'Mtra. Lucía Ferri', spec: 'PYMES / Startups', stars: 4.8, dist: 'Centro', img: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=200&h=200&fit=crop' },
        { name: 'Lic. Sergio Salinas', spec: 'Finanzas Corporativas', stars: 4.7, dist: 'Santa María', img: 'https://images.unsplash.com/photo-1556157382-97eda2d62296?w=200&h=200&fit=crop' }
      ]
    },
    'Jalisco': {
      'Guadalajara': [
        { name: 'Lic. Roberto Mejía', spec: 'Comercio Exterior', stars: 4.9, dist: 'Andares', img: 'https://images.unsplash.com/photo-1556157382-97eda2d62296?w=200&h=200&fit=crop' },
        { name: 'C.P. Sofía Velázquez', spec: 'Auditoría Jurídica', stars: 4.7, dist: 'Centro', img: 'https://images.unsplash.com/photo-1567532939604-b6b5b0db2604?w=200&h=200&fit=crop' }
      ],
      'Zapopan': [
        { name: 'Mtro. Daniel Ortiz', spec: 'Impuestos Especiales', stars: 4.6, dist: 'Puerta de Hierro', img: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=200&h=200&fit=crop' }
      ]
    },
    'Querétaro': {
      'Querétaro': [
        { name: 'C.P. Ricardo Anaya', spec: 'Impuestos Federales', stars: 4.9, dist: 'Juriquilla', img: 'https://images.unsplash.com/photo-1463453091185-61582044d556?w=200&h=200&fit=crop' },
        { name: 'Lic. Claudia Nava', spec: 'Contabilidad Gubernamental', stars: 4.8, dist: 'Centro', img: 'https://images.unsplash.com/photo-1554151228-14d9def656e4?w=200&h=200&fit=crop' }
      ]
    },
    'Yucatán': {
      'Mérida': [
        { name: 'C.P. Manuel Ek', spec: 'RIF / Resico Especialista', stars: 4.9, dist: 'Altabrisa', img: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=200&h=200&fit=crop' },
        { name: 'Mtra. Irma Xool', spec: 'Asesoría Turística', stars: 4.7, dist: 'Centro', img: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&h=200&fit=crop' }
      ]
    }
  };

  const getFilteredPros = () => {
    const stateData = PROS_DB[selectedState];
    if (!stateData) return [
      { name: 'C.P. Alberto Domínguez', spec: 'Contabilidad General Empresas', stars: 4.5, dist: 'Disponible Online', img: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=100&h=100&fit=crop' }
    ];
    
    if (selectedMunicipio && stateData[selectedMunicipio]) {
      return stateData[selectedMunicipio];
    }
    
    return Object.values(stateData).flat();
  };

  const currentPros = getFilteredPros();

  return (
    <div className="space-y-6">
      <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-gray-100 flex flex-col md:flex-row justify-between items-center gap-6">
        <div className="flex items-center gap-3">
          <div className="bg-tertiary/10 p-4 rounded-3xl">
            <Building2 className="w-8 h-8 text-tertiary"/>
          </div>
          <div>
            <h3 className="text-xl font-bold text-dark italic">{t.pyme_view.directory.title.replace('{location}', selectedState || (t.pyme_view.directory.your_zone || 'tu zona'))}</h3>
            <p className="text-sm text-gray-500 font-medium font-serif">{t.pyme_view.directory.subtitle}</p>
          </div>
        </div>
        <button 
          onClick={() => setLocModal(true)}
          className="bg-tertiary hover:bg-tertiary-dark text-white px-8 py-3.5 rounded-2xl text-sm font-bold shadow-lg shadow-tertiary/20 transition-all flex items-center gap-2"
        >
          📍 {t.pyme_view.directory.change_loc}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pb-20">
        {currentPros.map((pro, i) => (
          <motion.div 
            key={pro.name} 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-white p-6 rounded-[2.5rem] shadow-sm border border-gray-100 flex flex-col sm:flex-row gap-6 hover:shadow-xl transition-all group relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-32 h-32 bg-tertiary/5 rounded-bl-[5rem] group-hover:scale-110 transition-transform" />
            
            <div className="relative z-10 w-24 h-24 shrink-0 mx-auto sm:mx-0">
               <img src={pro.img || 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=100&h=100&fit=crop'} alt={pro.name} className="w-full h-full object-cover rounded-3xl shadow-inner border border-gray-100" />
               <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-green-500 border-4 border-white rounded-full" />
            </div>

            <div className="flex-1 relative z-10 text-center sm:text-left">
              <h4 className="font-bold text-dark text-xl">{pro.name}</h4>
              <p className="text-xs text-tertiary font-black uppercase tracking-[0.2em] mt-1 mb-3">{pro.spec}</p>
              
              <div className="flex flex-wrap justify-center sm:justify-start gap-5 text-sm font-bold text-gray-400">
                <span className="flex items-center gap-1.5 text-amber-500">
                  <Star className="w-4 h-4 fill-amber-500"/> {pro.stars}
                </span>
                <span className="flex items-center gap-1.5">
                   <Compass className="w-4 h-4" /> {pro.dist}
                </span>
                <span className="flex items-center gap-1.5">
                   <ShieldCheck className="w-4 h-4" /> {t.pyme_view.messages.validated || 'Verificado'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-2 mt-4 sm:mt-0 sm:justify-center relative z-10">
              <button 
                onClick={() => setSelectedHirePro(pro)}
                className="bg-tertiary text-white px-8 py-3 rounded-xl text-xs font-black shadow-lg shadow-tertiary/20 hover:bg-tertiary-dark transition-all active:scale-95 whitespace-nowrap"
              >
                {t.pyme_view.directory.hire}
              </button>
              <button 
                onClick={() => setSelectedHirePro(pro)}
                className="bg-gray-50 text-dark px-8 py-3 rounded-xl text-xs font-bold border border-gray-100 hover:bg-white transition-all shadow-sm"
              >
                {t.pyme_view.directory.view_profile}
              </button>
            </div>
          </motion.div>
        ))}
      </div>

      {locModal && (
        <div className="fixed inset-0 bg-dark/60 backdrop-blur-md flex items-center justify-center z-[250] p-4" onClick={() => setLocModal(false)}>
          <div className="bg-white rounded-[2.5rem] p-8 w-full max-w-sm shadow-2xl relative" onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-center mb-6">
               <h3 className="text-2xl font-bold text-dark">{t.pyme_view.directory.modal.title}</h3>
               <button onClick={() => setLocModal(false)} className="text-gray-300 hover:text-dark transition-colors"><XCircle className="w-7 h-7" /></button>
            </div>
            
            <div className="space-y-5">
              <div>
                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5 block">{t.pyme_view.directory.modal.state}</label>
                <select 
                  value={selectedState} 
                  onChange={e => { setSelectedState(e.target.value); setSelectedMunicipio(''); }}
                  className="w-full border border-gray-100 rounded-2xl p-3.5 bg-gray-50 outline-none focus:ring-2 focus:ring-tertiary/20 transition-all text-sm font-medium"
                >
                  <option value="">{t.pyme_view.directory.modal.select_state}</option>
                  {Object.keys(MEXICO_LOCATIONS).map(st => <option key={st} value={st}>{st}</option>)}
                </select>
              </div>

              {selectedState && (
                <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
                  <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5 block">{t.pyme_view.directory.modal.city}</label>
                  <select 
                    value={selectedMunicipio} 
                    onChange={e => setSelectedMunicipio(e.target.value)}
                    className="w-full border border-gray-100 rounded-2xl p-3.5 bg-gray-50 outline-none focus:ring-2 focus:ring-tertiary/20 transition-all text-sm font-medium"
                  >
                    <option value="">{t.pyme_view.directory.modal.select_city}</option>
                    {MEXICO_LOCATIONS[selectedState].map(mun => <option key={mun} value={mun}>{mun}</option>)}
                  </select>
                </motion.div>
              )}
              
              <button 
                disabled={!selectedState}
                onClick={() => setLocModal(false)}
                className="w-full bg-tertiary disabled:bg-gray-200 disabled:text-gray-400 hover:bg-tertiary-dark text-white py-4 rounded-2xl font-bold shadow-xl shadow-tertiary/20 transition-all mt-4"
              >
                {t.pyme_view.directory.modal.confirm_btn}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* HIRING MODALS LOGIC (Call, WA, Email) */}
      <AnimatePresence>
        {selectedHirePro && !isCalling && !showEmailModal && !showWaModal && (
          <div className="fixed inset-0 bg-dark/60 backdrop-blur-md z-[300] flex items-center justify-center p-4" onClick={() => setSelectedHirePro(null)}>
            <motion.div 
              initial={{ opacity: 0, y: 50, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 50, scale: 0.9 }}
              className="bg-white w-full max-w-sm rounded-[3rem] p-8 shadow-2xl relative text-center overflow-hidden"
              onClick={e => e.stopPropagation()}
            >
              <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-b from-tertiary/10 to-transparent" />
              
              <div className="relative mb-8 pt-4">
                <div className="w-28 h-28 mx-auto rounded-[2rem] overflow-hidden border-4 border-white shadow-2xl">
                   <img src={selectedHirePro.img} alt="" className="w-full h-full object-cover" />
                </div>
                <div className="absolute bottom-0 right-1/4 bg-amber-400 text-white p-2.5 rounded-2xl shadow-xl border-4 border-white">
                  <Star className="w-5 h-5 fill-white" />
                </div>
              </div>

              <h3 className="text-2xl font-bold text-dark mb-1">{selectedHirePro.name}</h3>
              <p className="text-xs font-black text-tertiary uppercase tracking-[0.2em] mb-10">{selectedHirePro.spec}</p>

              <div className="space-y-4">
                <button 
                  onClick={() => setIsCalling(true)}
                  className="w-full bg-blue-500 hover:bg-blue-600 text-white py-4.5 rounded-[1.5rem] font-black flex items-center justify-center gap-3 shadow-xl shadow-blue-500/30 transition-all active:scale-95"
                >
                  <Phone className="w-6 h-6" /> {t.pyme_view.directory.hiring.call}
                </button>
                <button 
                  onClick={() => setShowWaModal(true)}
                  className="w-full bg-[#25D366] hover:bg-[#20ba5a] text-white py-4.5 rounded-[1.5rem] font-black flex items-center justify-center gap-3 shadow-xl shadow-[#25D366]/30 transition-all active:scale-95"
                >
                  <MessageSquare className="w-6 h-6 fill-white" /> {t.pyme_view.directory.hiring.whatsapp}
                </button>
                <button 
                  onClick={() => setShowEmailModal(true)}
                  className="w-full bg-dark hover:bg-black text-white py-4.5 rounded-[1.5rem] font-black flex items-center justify-center gap-3 shadow-xl shadow-dark/30 transition-all active:scale-95"
                >
                  <Mail className="w-6 h-6" /> {t.pyme_view.directory.hiring.proposal}
                </button>
              </div>

              <button 
                onClick={() => setSelectedHirePro(null)}
                className="mt-8 text-sm font-bold text-gray-400 hover:text-dark transition-colors uppercase tracking-widest"
              >
                {t.common.back}
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Modal de Llamada */}
      <AnimatePresence>
        {isCalling && (
          <div className="fixed inset-0 bg-dark/98 z-[400] flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className="text-center text-white space-y-16"
            >
              <div className="relative">
                <div className="w-40 h-40 mx-auto rounded-full overflow-hidden border-8 border-white/10 animate-pulse">
                  <img src={selectedHirePro.img} alt="" className="w-full h-full object-cover" />
                </div>
                <div className="absolute inset-0 border-[10px] border-tertiary rounded-full animate-ping opacity-30" />
              </div>
              
              <div className="space-y-4">
                <p className="text-xs font-black text-tertiary uppercase tracking-[0.5em] animate-bounce">{t.pyme_view.directory.hiring.connecting}</p>
                <h4 className="text-4xl font-bold tracking-tight">{selectedHirePro.name}</h4>
                <p className="text-white/40 font-medium">{t.pyme_view.directory.hiring.seeking_line}</p>
              </div>

              <div className="flex flex-col items-center gap-6 pt-10">
                <button 
                  onClick={() => {
                    setIsCalling(false);
                    setSelectedHirePro(null);
                    showToast(t.pyme_view.directory.hiring.finish_toast || "✓ Llamada finalizada con éxito");
                  }}
                  className="w-24 h-24 bg-red-500 rounded-full flex items-center justify-center shadow-[0_0_50px_rgba(239,68,68,0.4)] hover:scale-110 active:scale-90 transition-all group"
                >
                  <XCircle className="w-12 h-12 group-hover:rotate-90 transition-transform" />
                </button>
                <span className="text-xs font-black text-white/30 uppercase tracking-[0.3em]">{t.pyme_view.directory.hiring.finish}</span>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Modal de Email */}
      <AnimatePresence>
        {showEmailModal && (
          <div className="fixed inset-0 bg-dark/60 backdrop-blur-md z-[400] flex items-center justify-center p-4" onClick={() => setShowEmailModal(false)}>
            <motion.div 
              initial={{ opacity: 0, y: 100 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 100 }}
              className="bg-white w-full max-w-lg rounded-[3rem] p-10 shadow-2xl relative overflow-hidden"
              onClick={e => e.stopPropagation()}
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-tertiary/5 rounded-bl-[5rem]" />
              <h3 className="text-2xl font-bold text-dark mb-8 flex items-center gap-4">
                <div className="bg-tertiary/10 p-2.5 rounded-2xl"><Mail className="w-7 h-7 text-tertiary" /></div> 
                {t.pyme_view.directory.hiring.email_title}
              </h3>
              
              <div className="space-y-6">
                <div>
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 block">{t.pyme_view.directory.hiring.recipient}</label>
                  <div className="bg-gray-50 p-4 rounded-2xl border border-gray-100 text-sm font-bold text-dark flex items-center justify-between">
                    <span>{selectedHirePro.name.toLowerCase().split(' ').join('.')}@empresa.mx</span>
                    <ShieldCheck className="w-4 h-4 text-green-500" />
                  </div>
                </div>
                <div>
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 block">{t.pyme_view.directory.hiring.body}</label>
                  <textarea 
                    value={emailBody}
                    onChange={(e) => setEmailBody(e.target.value)}
                    rows={6}
                    className="w-full bg-gray-50 border border-tertiary/20 rounded-[1.5rem] p-6 text-sm font-medium outline-none focus:ring-8 focus:ring-tertiary/5 transition-all leading-relaxed"
                  />
                </div>
              </div>

              <div className="flex gap-4 mt-10">
                <button 
                  onClick={() => setShowEmailModal(false)}
                  className="flex-1 py-4 text-sm font-bold text-gray-400 hover:text-dark transition-colors uppercase tracking-widest"
                >
                  {t.common.close}
                </button>
                <button 
                  onClick={() => {
                    setShowEmailModal(false);
                    setSelectedHirePro(null);
                    showToast(t.pyme_view.directory.hiring.email_success_toast || "✓ Propuesta enviada al despacho");
                  }}
                  className="flex-1 py-5 bg-tertiary text-white rounded-[1.5rem] font-black shadow-xl shadow-tertiary/20 hover:bg-tertiary-dark transition-all active:scale-95"
                >
                  {t.pyme_view.directory.hiring.send_now}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Modal de WhatsApp */}
      <AnimatePresence>
        {showWaModal && (
          <div className="fixed inset-0 bg-dark/60 backdrop-blur-md z-[400] flex items-center justify-center p-4" onClick={() => setShowWaModal(false)}>
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-white w-full max-w-md rounded-[3rem] p-8 shadow-2xl relative overflow-hidden"
              onClick={e => e.stopPropagation()}
            >
              <div className="bg-[#25D366] h-2 absolute top-0 left-0 w-full" />
              <h3 className="text-2xl font-bold text-dark mb-8 flex items-center gap-4">
                <div className="bg-[#25D366] p-2.5 rounded-2xl"><MessageSquare className="w-6 h-6 fill-white" /></div> 
                WhatsApp Business
              </h3>
              
              <div className="space-y-6">
                <div className="bg-[#e5ddd5] rounded-[2rem] p-6 relative min-h-[140px] shadow-inner">
                  <div className="bg-white p-4 rounded-2xl rounded-tl-none shadow-md text-sm text-gray-800 max-w-[95%] relative">
                    <div className="absolute -left-2 top-0 w-0 h-0 border-t-[10px] border-t-white border-l-[10px] border-l-transparent"></div>
                    <p className="font-medium leading-relaxed">{waMessage}</p>
                    <div className="text-[10px] text-gray-400 text-right mt-2 font-bold flex items-center justify-end gap-1">
                      10:55 AM <CheckCircle2 className="w-3 h-3 text-blue-400" />
                    </div>
                  </div>
                </div>
                
                <div>
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 block">{t.pyme_view.directory.hiring.wa_customize || 'Personalizar Mensaje'}</label>
                  <textarea 
                    value={waMessage}
                    onChange={(e) => setWaMessage(e.target.value)}
                    rows={3}
                    className="w-full bg-gray-50 border border-gray-100 rounded-[1.5rem] p-5 text-sm font-medium outline-none focus:ring-4 focus:ring-[#25D366]/10 transition-all"
                    placeholder={t.common.search || "Escribe aquí..."}
                  />
                </div>
              </div>

              <div className="flex gap-4 mt-10">
                <button 
                  onClick={() => setShowWaModal(false)}
                  className="flex-1 py-4 text-sm font-bold text-gray-400 hover:text-dark transition-colors uppercase tracking-widest"
                >
                  {t.common.cancel || 'Cancelar'}
                </button>
                <button 
                  onClick={() => {
                    setShowWaModal(false);
                    setSelectedHirePro(null);
                    showToast(t.pyme_view.directory.hiring.wa_success_toast || "✓ Mensaje enviado correctamente");
                  }}
                  className="flex-1 py-5 bg-[#25D366] text-white rounded-[1.5rem] font-black shadow-xl shadow-[#25D366]/20 hover:bg-[#20ba5a] transition-all active:scale-95"
                >
                  {t.pyme_view.directory.hiring.wa_send || 'Enviar WhatsApp'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function PYMEPerfil() {
  const { showToast, t } = useAppContext();
  const [photo, setPhoto] = useState<string | null>(null);

  const handlePhotoUpload = async (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const localUrl = URL.createObjectURL(file);
      // Actualización inmediata para que el usuario no espere
      setPhoto(localUrl);

      // Opcional: compresión en segundo plano
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      const img = new Image();
      img.onload = () => {
        const MAX_WIDTH = 500;
        const MAX_HEIGHT = 500;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
        }
        canvas.width = width;
        canvas.height = height;
        ctx?.drawImage(img, 0, 0, width, height);
        
        const base64String = canvas.toDataURL('image/jpeg', 0.8);
        try {
          localStorage.setItem('pymeProfilePhoto', base64String);
        } catch (e) {
          console.warn("Could not save to localStorage", e);
        }
      };
      img.src = localUrl;
    }
  };

  useEffect(() => {
    const savedPhoto = localStorage.getItem('pymeProfilePhoto');
    if (savedPhoto) {
      setPhoto(savedPhoto);
    }
  }, []);

  const handleSave = () => {
    if (!photo) {
      showToast(t.pyme_view.profile.logo_required || "Por favor, sube el logotipo de tu empresa. Es un requisito obligatorio.", "error");
      return;
    }
    showToast(t.pyme_view.profile.save_success || 'Perfil actualizado con éxito.');
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 flex flex-col items-center text-center">
        <h2 className="text-2xl font-bold text-dark mb-2">{t.pyme_view.profile.title}</h2>
        <p className="text-gray-500 text-sm mb-6 max-w-lg">
          {t.pyme_view.profile.subtitle}
          <span className="block mt-2 font-medium text-tertiary">{t.pyme_view.profile.logo_info || 'Añadir una foto o logo muestra mayor seguridad y formalidad para las firmas contables interesadas en brindarte asesoría. (Obligatorio)'}</span>
        </p>

        <div className="relative mb-6 group cursor-pointer">
          <div className="w-32 h-32 rounded-2xl bg-gray-100 border-4 border-white shadow-lg overflow-hidden flex items-center justify-center relative">
            {photo ? (
              <img src={photo} alt="Perfil PYME" className="w-full h-full object-cover" />
            ) : (
              <Building2 className="w-10 h-10 text-gray-300" />
            )}
            <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
              <UploadCloud className="w-8 h-8 text-white" />
            </div>
            <input 
              type="file" 
              accept="image/*" 
              className="absolute inset-0 opacity-0 cursor-pointer" 
              onChange={handlePhotoUpload}
            />
          </div>
          {!photo && <p className="text-[10px] text-red-500 font-bold mt-2 uppercase">{t.pyme_view.profile.logo_required}</p>}
        </div>

        <div className="w-full max-w-md space-y-4 text-left">
          <div>
            <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">{t.pyme_view.profile.name}</label>
            <input type="text" defaultValue="Mi Empresa S.A de C.V" className="w-full border border-gray-200 rounded-xl p-3 outline-none focus:border-tertiary text-sm bg-gray-50 focus:bg-white transition-colors" />
          </div>
          <div>
            <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">{t.pyme_view.profile.rfc}</label>
            <input type="text" defaultValue="EMP1234567A" className="w-full border border-gray-200 rounded-xl p-3 outline-none focus:border-tertiary text-sm bg-gray-50 focus:bg-white transition-colors" />
          </div>
          <button onClick={handleSave} className="w-full bg-tertiary hover:bg-tertiary-dark text-white py-3 rounded-xl font-bold shadow-sm transition-all mt-4">
            {t.pyme_view.profile.save_btn}
          </button>
        </div>
      </div>
      <div className="mt-8">
        <AppearanceSettings />
      </div>
    </div>
  );
}
