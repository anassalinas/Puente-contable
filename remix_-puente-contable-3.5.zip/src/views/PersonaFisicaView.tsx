import { useState, ChangeEvent, FormEvent, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import AppearanceSettings from '../components/AppearanceSettings';
import { 
  Stethoscope, ReceiptText, MapPin, CheckCircle2, AlertCircle, 
  MessageSquare, Plus, FileText, Bot, DollarSign, Send, Star, 
  Compass, BriefcaseBusiness, ChevronRight, Camera, UploadCloud, 
  Calendar, XCircle, CalendarDays, Pencil, ShieldCheck, Eye, Phone, Mail,
  Clock, FileType, Check, ArrowLeft, Trash2, Info, TrendingUp, ArrowUpRight,
  RefreshCw, MoreVertical
} from 'lucide-react';
import { useAppContext } from '../App';
import CFDIViewer from '../components/CFDIViewer';
import DoctorProfile from '../components/DoctorProfile';
import AppointmentNotification from '../components/AppointmentNotification';
import { Médico, Factura } from '../types';
import { db, storage } from '../lib/firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage';

export default function PersonaFisicaView() {
  const { currentView } = useAppContext();

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <AnimatePresence mode="wait">
        <motion.div
          key={currentView}
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -15 }}
          transition={{ duration: 0.2 }}
        >
          {currentView === 'dashboard' && <PFDashboard />}
          {currentView === 'medicos' && <PFMedicos />}
          {currentView === 'facturas' && <PFFacturas />}
          {currentView === 'asesor' && <PFAsesor />}
          {currentView === 'directorio' && <PFDirectorio />}
          {currentView === 'perfil' && <PFPerfil />}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

function PFDashboard() {
  const { showToast, t } = useAppContext();
  const [hasAppointment, setHasAppointment] = useState(false);
  const [showCalendar, setShowCalendar] = useState(false);
  const [selectedDoctorForProfile, setSelectedDoctorForProfile] = useState<Médico | null>(null);
  const [showNotification, setShowNotification] = useState<{ doctor: string, date: string } | null>(null);
  const [daysRemaining, setDaysRemaining] = useState<number | null>(null);
  const [selectedStat, setSelectedStat] = useState<{label: string, value: string, icon: any, color: string} | null>(null);

  const calculateDays = (dateStr: string) => {
    const today = new Date();
    const appointmentDate = new Date(dateStr);
    const diffTime = appointmentDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays > 0 ? diffDays : 0;
  };

  const facturasData: Factura[] = [
    { folio: 'A-102', emisor: 'Dr. José Ramírez', date: '20 Oct', monto: '$1,200', uso: t.pf_view.invoice?.uso_cfdi || 'D01', status: 'ok' },
    { folio: 'B-304', emisor: 'Dra. Mónica López', date: '18 Oct', monto: '$950', uso: t.pf_view.invoice?.uso_cfdi || 'D01', status: 'pending' },
    { folio: 'HOS-99', emisor: 'Hospital Ángeles', date: '12 Oct', monto: '$4,100', uso: t.pf_view.invoice?.uso_cfdi || 'D01', status: 'pending' },
  ];

  const medicosData: Médico[] = [
    { nombre: 'Dr. José Ramírez', especialidad: t.common.specialties.cardiology, correo: 'jose.ramirez@medico.com', telefono: '555-123-4455', encargado: 'Srta. Betty', whatsapp: '5551234455', correoFacturacion: 'facturas@ramirez.com', plazoRecordatorio: `3 ${t.common.business_days}` },
    { nombre: 'Dra. Mónica López', especialidad: t.common.specialties.dermatology, correo: 'monica.lope.s@medico.com', telefono: '555-987-6655', encargado: 'Lic. Jorge', whatsapp: '5559876655', correoFacturacion: 'admin@lopez.com', plazoRecordatorio: `5 ${t.common.business_days}` },
  ];

  return (
    <div className="space-y-6">
      {!hasAppointment ? (
        <div className="bg-gradient-to-r from-secondary/10 to-secondary/5 border border-secondary/20 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="bg-secondary/20 p-2 rounded-xl">
              <CalendarDays className="w-6 h-6 text-secondary" />
            </div>
            <div>
              <p className="font-bold text-dark flex items-center gap-2">
                {t.pf_view.promo_title}
              </p>
              <p className="text-sm text-gray-600 font-medium">{t.pf_view.promo_desc}</p>
            </div>
          </div>
          <button 
            onClick={() => setShowCalendar(true)}
            className="whitespace-nowrap bg-secondary hover:bg-secondary-dark text-white px-5 py-2.5 rounded-xl text-sm font-bold shadow-sm transition-colors"
          >
            {t.pf_view.add_apt}
          </button>
        </div>
      ) : (
        <div className="bg-white border border-gray-100 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-sm">
           <div className="flex items-center gap-4">
              <div className="bg-secondary text-white p-3 rounded-2xl font-black text-xl">
                {daysRemaining !== null ? daysRemaining : '0'}
                <span className="block text-[8px] uppercase tracking-tighter">{t.pf_view.days_remaining}</span>
              </div>
              <div>
                <p className="font-bold text-dark italic">{t.pf_view.next_apt}: {showNotification?.doctor}</p>
                <p className="text-xs text-gray-500 font-medium">{t.pf_view.next_apt_desc}</p>
              </div>
           </div>
           <button 
             onClick={() => { setHasAppointment(false); setDaysRemaining(null); }}
             className="text-xs font-bold text-gray-400 hover:text-red-500 transition-colors"
           >
             {t.pf_view.del_apt}
           </button>
        </div>
      )}

      {showCalendar && (
        <div className="fixed inset-0 bg-dark/60 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={() => setShowCalendar(false)}>
          <div className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-2xl" onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold text-dark">{t.pf_view.apt_modal.title}</h3>
              <button onClick={() => setShowCalendar(false)} className="text-gray-400 hover:text-gray-600"><XCircle className="w-6 h-6"/></button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">{t.pf_view.apt_modal.doctor}</label>
                <select id="appointment-doctor" className="w-full border border-gray-200 rounded-xl p-3 outline-none focus:border-secondary text-sm bg-gray-50 focus:bg-white transition-colors">
                  <option>{t.pf_view.apt_modal.select_doctor}</option>
                  <option>Dr. José Ramírez</option>
                  <option>Dra. Mónica López</option>
                  <option>Hospital Ángeles</option>
                  <option>Dr. Roberto Torres</option>
                </select>
              </div>
              <div>
                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">{t.pf_view.apt_modal.date}</label>
                <div className="grid grid-cols-2 gap-2">
                  <input id="appointment-date" type="date" className="w-full border border-gray-200 rounded-xl p-3 outline-none focus:border-secondary text-sm bg-gray-50 focus:bg-white transition-colors cursor-pointer" />
                  <input id="appointment-time" type="time" className="w-full border border-gray-200 rounded-xl p-3 outline-none focus:border-secondary text-sm bg-gray-50 focus:bg-white transition-colors cursor-pointer" />
                </div>
              </div>
              <button 
                onClick={() => { 
                  const docEl = document.getElementById('appointment-doctor') as HTMLSelectElement;
                  const dateEl = document.getElementById('appointment-date') as HTMLInputElement;
                  const timeEl = document.getElementById('appointment-time') as HTMLInputElement;
                  if (docEl && dateEl && dateEl.value) {
                    setHasAppointment(true); 
                    setShowCalendar(false); 
                    setShowNotification({ 
                      doctor: docEl.value, 
                      date: `${dateEl.value} ${timeEl?.value || '10:00'}` 
                    });
                    setDaysRemaining(calculateDays(dateEl.value));
                    showToast(t.pf_view.apt_modal.toast_success.replace('{doctor}', docEl.value));
                  }
                }}
                className="w-full bg-secondary hover:bg-secondary-dark text-white py-3 rounded-xl font-bold shadow-sm transition-all mt-2"
              >
                {t.pf_view.apt_modal.confirm}
              </button>
            </div>
          </div>
        </div>
      )}

      {showNotification && (
        <AppointmentNotification 
          data={showNotification} 
          onClose={() => setShowNotification(null)} 
        />
      )}

      {selectedDoctorForProfile && (
        <DoctorProfile 
          doctor={selectedDoctorForProfile} 
          history={facturasData.filter(f => f.emisor === selectedDoctorForProfile.nombre)}
          onClose={() => setSelectedDoctorForProfile(null)}
          onViewInvoice={(invoice) => {
            showToast(`Visualizando factura ${invoice.folio}`);
          }}
        />
      )}

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { id: 'medical_expenses', label: t.pf_view?.stats?.medical_expenses || 'Gastos', value: '$14,200', icon: DollarSign, color: 'text-secondary' },
          { id: 'received', label: t.pf_view?.stats?.invoices_received || 'Recibidas', value: '8 de 10', icon: FileText, color: 'text-secondary' },
          { id: 'pending', label: t.pf_view?.stats?.invoices_pending || 'Pendientes', value: '2', icon: AlertCircle, color: 'text-amber-500' },
          { id: 'doctors', label: t.pf_view?.stats?.doctors_registered || 'Doctores', value: '4', icon: Stethoscope, color: 'text-blue-500' }
        ].map((stat, i) => (
          <div 
            key={i} 
            onClick={() => setSelectedStat(stat)}
            className="bg-white p-5 rounded-2xl shadow-sm border border-gray-100 flex flex-col gap-3 cursor-pointer hover:shadow-md transition-all active:scale-[0.98]"
          >
            <div className={`p-2 w-fit rounded-lg bg-gray-50 flex items-center justify-center ${stat.color}`}>
              <stat.icon className="w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold text-dark">{stat.value}</p>
              <p className="text-xs text-gray-500 mt-1 font-medium">{stat.label}</p>
            </div>
          </div>
        ))}
      </div>

      {selectedStat && (
        <div className="fixed inset-0 bg-dark/60 backdrop-blur-sm z-[200] flex items-center justify-center p-4" onClick={() => setSelectedStat(null)}>
           <motion.div 
             initial={{ opacity: 0, scale: 0.9 }}
             animate={{ opacity: 1, scale: 1 }}
             className="bg-white w-full max-w-sm rounded-[2.5rem] p-8 shadow-2xl relative text-center"
             onClick={e => e.stopPropagation()}
           >
              <button onClick={() => setSelectedStat(null)} className="absolute top-6 right-6 p-2 text-gray-400 hover:text-dark transition-colors"><XCircle className="w-6 h-6"/></button>
              <div className={`w-16 h-16 mx-auto rounded-2xl bg-gray-50 flex items-center justify-center mb-4 ${selectedStat.color}`}>
                <selectedStat.icon className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-dark mb-1">{selectedStat.label}</h3>
              <p className="text-3xl font-black mb-6">{selectedStat.value}</p>
              
              <div className="bg-gray-50 p-4 rounded-xl border border-gray-100 text-left text-sm text-gray-600">
                <p className="font-bold text-dark flex items-center gap-2 mb-2"><Info className="w-4 h-4"/> {t.common.data_source}:</p>
                {selectedStat.id === 'income' && <p>{t.pf_view.income_info}</p>}
                {selectedStat.id === 'deductions' && <p>{t.pf_view.deductions_info}</p>}
                {selectedStat.id === 'withheld' && <p>{t.pf_view.withheld_info}</p>}
                {selectedStat.id === 'medical_expenses' && <p>{t.pf_view.medical_expense_info}</p>}
                {selectedStat.id === 'received' && <p>{t.pf_view.received_info}</p>}
                {selectedStat.id === 'pending' && <p>{t.pf_view.pending_info}</p>}
                {selectedStat.id === 'doctors' && <p>{t.pf_view.doctors_info}</p>}
              </div>

              <button 
                onClick={() => setSelectedStat(null)}
                className="w-full bg-secondary text-white py-3.5 rounded-2xl font-bold shadow-lg shadow-secondary/20 hover:bg-secondary-dark transition-all mt-6 active:scale-95"
              >
                {t.common.got_it}
              </button>
           </motion.div>
        </div>
      )}

      {/* SECCIÓN DE DESGLOSE VISUAL SOLICITADA */}
      <div className="bg-white p-8 rounded-[3rem] shadow-sm border border-gray-100">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6 mb-8">
          <div className="text-center md:text-left">
            <h3 className="text-2xl font-black text-dark tracking-tighter">{t.pf_view.tax_breakdown}</h3>
            <p className="text-xs text-gray-400 font-bold uppercase tracking-widest mt-1">{t.pf_view.tax_subtitle}</p>
          </div>
          <motion.div 
            whileHover={{ scale: 1.05 }}
            className="bg-secondary/10 px-6 py-3 rounded-2xl flex items-center gap-3 border border-secondary/20"
          >
            <TrendingUp className="w-5 h-5 text-secondary" />
            <span className="text-sm font-black text-secondary uppercase tracking-widest">{t.pf_view.balance_favor}: $8,420</span>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            { id: 'income', label: t.pf_view.income, value: '$245,600', color: 'text-dark', bg: 'bg-indigo-50', icon: DollarSign },
            { id: 'deductions', label: t.pf_view.deductions, value: '$18,450', color: 'text-secondary', bg: 'bg-secondary/5', icon: FileText },
            { id: 'withheld', label: t.pf_view.withheld, value: '$32,100', color: 'text-tertiary', bg: 'bg-tertiary/5', icon: ShieldCheck }
          ].map((item, idx) => (
            <motion.div
              key={idx}
              whileHover={{ y: -5 }}
              onClick={() => {
                setSelectedStat({ id: item.id, label: item.label, value: item.value, icon: item.icon, color: item.color });
              }}
              className={`${item.bg} p-6 rounded-[2.5rem] border border-transparent hover:border-gray-200 transition-all cursor-pointer group active:scale-95`}
            >
              <div className="flex justify-between items-start mb-6">
                 <div className={`p-3 rounded-2xl bg-white shadow-sm group-hover:scale-110 transition-transform ${item.color}`}>
                   <item.icon className="w-6 h-6" />
                 </div>
                 <ArrowUpRight className="w-5 h-5 text-gray-300 group-hover:text-dark transition-colors" />
              </div>
              <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">{item.label}</p>
              <p className={`text-2xl font-black ${item.color}`}>{item.value}</p>
              <p className="text-[9px] font-medium text-gray-400 mt-3 flex items-center gap-1">
                 <Info className="w-3 h-3" /> {t.pf_view.sat_details}
              </p>
            </motion.div>
          ))}
        </div>
      </div>

      {hasAppointment && (
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-secondary text-white p-6 rounded-[2.5rem] shadow-xl shadow-secondary/20 flex flex-col md:flex-row items-center gap-6 relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -mr-20 -mt-20 blur-3xl" />
          <div className="bg-white/20 p-6 rounded-[2rem] text-center min-w-[120px] backdrop-blur-md border border-white/20">
            <p className="text-[10px] font-black uppercase tracking-[0.2em] mb-1 opacity-70">{t.pf_view.next_apt}</p>
            <p className="text-5xl font-black">{daysRemaining !== null ? daysRemaining : '0'}</p>
            <p className="text-[10px] font-bold uppercase tracking-widest mt-1">{t.pf_view.days_remaining}</p>
          </div>
          <div className="flex-1 text-center md:text-left">
            <h4 className="text-2xl font-bold mb-1 italic">Dra/Dr {showNotification?.doctor}</h4>
            <p className="text-secondary-light font-medium opacity-90">{t.pf_view.billing_reminder}</p>
          </div>
          <div className="flex gap-2">
            <button 
              onClick={() => showToast(t.pf_view.reminders_updated)}
              className="bg-white/10 hover:bg-white/20 p-4 rounded-2xl transition-all border border-white/10"
            >
              <Clock className="w-6 h-6" />
            </button>
            <button 
              onClick={() => { setHasAppointment(false); showToast(t.pf_view.appointment_finished); }}
              className="bg-white text-secondary px-6 py-4 rounded-2xl font-black text-sm hover:bg-secondary-light transition-all active:scale-95"
            >
              {t.pf_view.mark_attended}
            </button>
          </div>
        </motion.div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="p-5 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
            <h3 className="font-semibold text-dark">{t.pf_view.doctor_dir}</h3>
          </div>
          <div className="divide-y divide-gray-50">
             {medicosData.map((m, i) => (
               <div key={i} className="p-4 flex items-center justify-between hover:bg-gray-50 transition-colors cursor-pointer" onClick={() => setSelectedDoctorForProfile(m)}>
                 <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-secondary/10 text-secondary rounded-xl flex items-center justify-center font-bold">{m.nombre[0]}</div>
                    <div>
                       <p className="font-bold text-sm text-dark">{m.nombre}</p>
                       <p className="text-xs text-gray-500">{m.especialidad}</p>
                    </div>
                 </div>
                 <ChevronRight className="w-4 h-4 text-gray-300" />
               </div>
             ))}
          </div>
        </div>

        <div className="lg:col-span-1 border border-gray-100 bg-white rounded-2xl shadow-sm p-6 flex flex-col gap-4">
          <h3 className="font-semibold text-dark border-b border-gray-100 pb-3">{t.pf_view.follow_up}</h3>
          
          <div className="bg-amber-50 border border-amber-200 text-amber-700 p-3 rounded-xl text-sm flex gap-3 items-start">
            <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
            <p className="leading-tight font-medium">{t.pf_view.medical_payment_alert}</p>
          </div>
          
          <div className="bg-blue-50 border border-blue-200 text-blue-700 p-3 rounded-xl text-sm flex gap-3 items-start">
            <MessageSquare className="w-5 h-5 shrink-0 mt-0.5" />
            <p className="leading-tight font-medium">{t.pf_view.wa_sent_alert}</p>
          </div>

          <div className="mt-auto pt-4 border-t border-gray-100">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium text-gray-600">{t.pf_view.deductible_progress}</span>
              <span className="text-sm font-bold text-secondary">80%</span>
            </div>
            <div className="h-2 w-full bg-black/20 rounded-full overflow-hidden shadow-inner">
              <div className="h-full bg-secondary rounded-full" style={{ width: '80%' }}></div>
            </div>
            <p className="text-xs text-gray-400 mt-2">80% {t.pf_view.backed_by_cfdi}</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function PFMedicos() {
  const { showToast, t } = useAppContext();
  const [showForm, setShowForm] = useState(false);
  const [formMode, setFormMode] = useState<'add' | 'edit'>('add');
  const [editingId, setEditingId] = useState<number | null>(null);
  const [meds, setMeds] = useState<Médico[]>([
    { 
      nombre: 'Dr. José Ramírez', 
      especialidad: 'Cardiología', 
      correo: 'jose.ramirez@hmedico.com', 
      telefono: '5551234455', 
      whatsapp: '5551234455',
      encargado: 'Srta. Beatriz',
      correoFacturacion: 'facturas@ramirezmed.mx',
      plazoRecordatorio: '3 días',
      img: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=128&h=128&fit=crop'
    },
    { 
      nombre: 'Dra. Mónica López', 
      especialidad: 'Dermatología', 
      correo: 'monica.lopez@clinica.com', 
      telefono: '5559876655', 
      whatsapp: '5559876655',
      encargado: 'Lic. Ricardo',
      correoFacturacion: 'admin@lopezdermatologia.com',
      plazoRecordatorio: '5 días',
      img: 'https://images.unsplash.com/photo-1594824476967-48c8b964273f?w=128&h=128&fit=crop'
    },
    { 
      nombre: 'Hospital Ángeles', 
      especialidad: 'Laboratorio', 
      correo: 'contacto@angeles.mx', 
      telefono: '5551112233', 
      whatsapp: '5551112233',
      encargado: 'Area de Facturación',
      correoFacturacion: 'facturas@angeles.mx',
      plazoRecordatorio: '1 día',
      img: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=128&h=128&fit=crop'
    },
    { 
      nombre: 'Dr. Roberto Torres', 
      especialidad: 'Ortopedia', 
      correo: 'roberto.torres@medico.mx', 
      telefono: '5554443322', 
      whatsapp: '5554443322',
      encargado: 'Sra. Lupita',
      correoFacturacion: 'torres.factura@gmail.com',
      plazoRecordatorio: '3 días',
      img: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=128&h=128&fit=crop'
    }
  ]);
  const [formData, setFormData] = useState({ name: '', spec: '' });

  // Contact Modal State
  const [selectedContactDoc, setSelectedContactDoc] = useState<Médico | null>(null);
  const [contactView, setContactView] = useState<'main' | 'wa_med' | 'mail_med' | 'wa_billing' | 'mail_billing' | 'schedule' | 'request' | 'calling'>('main');
  
  // Patient Data
  const patient = {
    name: "Ana Salinas",
    rfc: "SALA950101HJK",
    email: "ana.salinas@example.com",
    phone: "(81) 8000-0000",
    cp: "64000",
    regimen: t.pf_view.patient?.regime || "605 - Sueldos y Salarios",
    usoCFDI: t.pf_view?.invoice?.uso_cfdi || "D01 Medical Fees"
  };

  const [mailForm, setMailForm] = useState({ subject: '', body: '' });
  const [waMessage, setWaMessage] = useState('');
  const [scheduleForm, setScheduleForm] = useState({ date: '', time: '', reason: '' });
  const [requestType, setRequestType] = useState('Receta médica');

  const addToHistory = (docName: string, action: string) => {
    console.log(`Historial [${new Date().toLocaleString()}]: ${docName} - ${action}`);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
        <div>
          <h2 className="text-lg font-bold text-dark italic">{t.pf_view.doctors_section.title}</h2>
          <p className="text-sm text-gray-500">{t.pf_view.doctors_section.subtitle}</p>
        </div>
        <button 
          onClick={() => {
            setFormMode('add');
            setFormData({ name: '', spec: '' });
            setShowForm(!showForm);
          }}
          className="bg-secondary hover:bg-secondary-dark text-white px-5 py-2.5 rounded-xl text-sm font-semibold transition-colors flex items-center gap-2 shadow-sm"
        >
          <Plus className="w-4 h-4" /> {t.pf_view.doctors_section.add_btn}
        </button>
      </div>

      {showForm && (
        <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} className="overflow-hidden">
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 lg:w-2/3">
            <div className="border border-secondary/20 bg-secondary/5 text-secondary p-3 rounded-xl text-sm flex gap-3 items-start mb-6">
              <AlertCircle className="w-5 h-5 shrink-0" />
              <p className="font-medium">{t.pf_view.medical_payment_alert_full || <span>Asegúrate que la forma de pago sea a <strong>CRÉDITO</strong>. La cuenta debe ser del consultorio u hospital, NO del médico directamente.</span>}</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div>
                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">{t.pf_view.apt_modal.doctor}</label>
                <input type="text" value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} className="w-full border border-gray-200 rounded-xl p-2.5 outline-none focus:border-secondary text-sm" placeholder="Ej. Dr. Martínez" />
              </div>
              <div>
                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">{t.pyme_view.providers.modal.fields.spec}</label>
                <input type="text" value={formData.spec} onChange={(e) => setFormData({...formData, spec: e.target.value})} className="w-full border border-gray-200 rounded-xl p-2.5 outline-none focus:border-secondary text-sm" placeholder="Ej. Cardiología" />
              </div>
              <div>
                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">{t.pyme_view.providers.modal.fields.billing_contact || 'Facturación'}</label>
                <input type="text" className="w-full border border-gray-200 rounded-xl p-2.5 outline-none focus:border-secondary text-sm" placeholder={t.common.search} />
              </div>
              <div>
                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">WhatsApp</label>
                <input type="text" className="w-full border border-gray-200 rounded-xl p-2.5 outline-none focus:border-secondary text-sm" placeholder="+52 123 456 7890" />
              </div>
              <div>
                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">{t.pf_view.follow_up}</label>
                <select className="w-full border border-gray-200 rounded-xl p-2.5 outline-none focus:border-secondary text-sm bg-white">
                  <option>3 {t.pf_view.days_remaining}</option>
                  <option>5 {t.pf_view.days_remaining}</option>
                </select>
              </div>
            </div>
            <div className="flex justify-end gap-3">
              <button onClick={() => setShowForm(false)} className="px-5 py-2.5 text-sm font-semibold text-gray-500 hover:text-dark">{t.common.cancel}</button>
              <button 
                onClick={() => { 
                  if(formMode === 'add') {
                    setMeds([...meds, { 
                      nombre: formData.name || 'Nuevo Médico', 
                      especialidad: formData.spec || 'Especialidad',
                      correo: 'nuevo@medico.com',
                      telefono: '5550009988',
                      whatsapp: '5550009988',
                      encargado: 'Secretaria',
                      correoFacturacion: 'facturas@nuevo.com',
                      plazoRecordatorio: '3 días'
                    }]);
                    showToast(`✓ ${t.pf_view.doctors_section.add_btn} ${t.common.success}`);
                  } else {
                    const newMeds = [...meds];
                    if (editingId !== null && newMeds[editingId]) {
                      newMeds[editingId].nombre = formData.name;
                      newMeds[editingId].especialidad = formData.spec;
                      setMeds(newMeds);
                      showToast(`✓ ${t.common.save} ${t.common.success}`);
                    }
                  }
                  setShowForm(false); 
                }}
                className="bg-secondary hover:bg-secondary-dark text-white px-5 py-2.5 rounded-xl text-sm font-semibold transition-colors"
              >{formMode === 'add' ? t.common.add : t.common.save}</button>
            </div>
          </div>
        </motion.div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {meds.map((md, i) => (
          <div key={i} className="bg-white p-5 rounded-[1.5rem] shadow-sm border border-gray-100 flex justify-between items-center group hover:shadow-md transition-all">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-secondary/10 flex items-center justify-center text-secondary">
                <Stethoscope className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-dark">{md.nombre}</h3>
                  <button 
                    onClick={() => {
                      setFormMode('edit');
                      setEditingId(i);
                      setFormData({ name: md.nombre, spec: md.especialidad });
                      setShowForm(true);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className="text-gray-400 hover:text-secondary opacity-0 group-hover:opacity-100 transition-opacity"
                    title="Editar contacto"
                  >
                    <Pencil className="w-3.5 h-3.5" />
                  </button>
                  <button 
                    onClick={() => {
                      if(window.confirm(`¿Estás seguro de eliminar a ${md.nombre}?`)) {
                        setMeds(meds.filter((_, index) => index !== i));
                        showToast(`🗑️ ${md.nombre} eliminado from el directorio`);
                      }
                    }}
                    className="text-gray-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                    title="Eliminar médico"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
                <p className="text-xs text-gray-500 font-bold uppercase tracking-wider">{md.especialidad}</p>
                <div className="mt-2">
                  <span className={`text-[10px] uppercase font-black px-2 py-1 rounded-md ${
                    i === 0 || i === 3 ? 'text-secondary bg-secondary-light' : 
                    i === 1 ? 'text-amber-600 bg-amber-50' : 'text-red-600 bg-red-50'
                  }`}>
                    {i === 0 || i === 3 ? (t.pf_view.doctors_section?.status?.up_to_date || 'UP TO DATE') : i === 1 ? (t.pf_view.doctors_section?.status?.pending || 'PENDING') : (t.pf_view.doctors_section?.status?.no_response || '5 DAYS NO RESPONSE')}
                  </span>
                </div>
              </div>
            </div>
            
            <div className="flex gap-2">
               <button 
                 onClick={() => {
                   showToast(`✓ WhatsApp enviado a ${md.nombre}`);
                   addToHistory(md.nombre, "WhatsApp Recordatorio");
                 }}
                 className="flex items-center justify-center w-11 h-11 rounded-2xl bg-[#25D366]/10 text-[#25D366] hover:bg-[#25D366]/20 transition-all active:scale-95 shadow-sm"
                 title="Recordatorio WA"
               >
                 <MessageSquare className="w-5 h-5" />
               </button>
               <button 
                 onClick={() => {
                   setSelectedContactDoc(md);
                   setContactView('main');
                 }}
                 className="flex items-center justify-center w-11 h-11 rounded-2xl bg-blue-50 text-blue-600 hover:bg-blue-100 transition-all active:scale-95 shadow-sm border border-blue-100/50"
                 title="Contactar Médico"
               >
                 <Mail className="w-5 h-5" />
               </button>
            </div>
          </div>
        ))}
      </div>

      {/* MODAL MAESTRO DE CONTACTO */}
      <AnimatePresence>
        {selectedContactDoc && (
          <div className="fixed inset-0 bg-dark/70 backdrop-blur-md z-[300] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 30 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 30 }}
              className="bg-white w-full max-w-[380px] rounded-[2.5rem] shadow-2xl relative overflow-hidden flex flex-col max-h-[90vh]"
              onClick={e => e.stopPropagation()}
            >
              {/* Header Modal - Refined */}
              <div className="p-7 border-b border-gray-50 bg-white relative flex flex-col items-center text-center">
                <button 
                  onClick={() => setSelectedContactDoc(null)}
                  className="absolute top-6 right-6 p-1.5 text-gray-300 hover:text-dark hover:bg-gray-100 rounded-full transition-all"
                >
                  <XCircle className="w-6 h-6" />
                </button>

                <div className="w-16 h-16 bg-secondary/10 rounded-2xl flex items-center justify-center text-secondary mb-4 border border-secondary/20 shadow-sm relative overflow-hidden">
                   {selectedContactDoc.img ? (
                     <img src={selectedContactDoc.img} alt={selectedContactDoc.nombre} className="w-full h-full object-cover" />
                   ) : (
                     <Stethoscope className="w-9 h-9" />
                   )}
                   <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-green-500 border-4 border-white rounded-full"></div>
                </div>
                <h3 className="text-xl font-bold text-dark leading-tight">Contactar a {selectedContactDoc.nombre}</h3>
                <p className="text-[10px] font-black text-secondary uppercase tracking-[0.2em] mt-1">{selectedContactDoc.especialidad}</p>
              </div>

              {/* Views */}
              <div className="flex-1 overflow-y-auto p-5 custom-scrollbar bg-gray-50/30">
                {/* VISTA PRINCIPAL (ESTRUCTURA SOLICITADA) */}
                {contactView === 'main' && (
                  <div className="space-y-7 py-2">
                    {/* Sección 1: Contacto directo */}
                    <div>
                      <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.15em] mb-4 ml-1">Contacto directo con el médico</p>
                      <div className="space-y-3">
                        <ContactOption 
                          icon={MessageSquare} 
                          title="WhatsApp al médico" 
                          desc="Respuesta en ~24hrs" 
                          onClick={() => {
                            setContactView('wa_med');
                            const apellido = selectedContactDoc.nombre.split(' ').pop();
                            setWaMessage(`Hola Dr. ${apellido}, le escribe ${patient.name}. Me gustaría consultarle sobre mi tratamiento.`);
                          }} 
                        />
                        <ContactOption 
                          icon={Mail} 
                          title="Correo al médico" 
                          desc="Consultas formales" 
                          onClick={() => {
                            setContactView('mail_med');
                            const apellido = selectedContactDoc.nombre.split(' ').pop();
                            setMailForm({
                              subject: `Consulta médica — ${patient.name}`,
                              body: `Estimado Dr. ${apellido}:\n\nEspero se encuentre bien. Le escribo para consultarle sobre...\n\nAtentamente,\n${patient.name}`
                            });
                          }} 
                        />
                      </div>
                    </div>

                    {/* Sección 2: Facturación */}
                    <div>
                      <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.15em] mb-4 ml-1">Contacto con encargado de facturación</p>
                      <div className="space-y-3">
                        <ContactOption 
                          icon={MessageSquare} 
                          title={`WhatsApp a ${selectedContactDoc.encargado || 'Secretaría'}`} 
                          desc="Envío de comprobante de pago" 
                          disabled={!selectedContactDoc.whatsapp}
                          onClick={() => {
                            setContactView('wa_billing');
                            setWaMessage(`Hola ${selectedContactDoc.encargado}, le escribimos de parte de ${patient.name} para solicitar la factura de la consulta del día de hoy. Adjunto mis datos fiscales para el CFDI. ¡Gracias!`);
                          }} 
                        />
                        <ContactOption 
                          icon={Mail} 
                          title="Correo a facturación" 
                          desc="Envío formal de datos fiscales" 
                          disabled={!selectedContactDoc.correoFacturacion}
                          onClick={() => {
                            setContactView('mail_billing');
                            setMailForm({
                              subject: `Solicitud de Factura — ${patient.name} — ${new Date().toLocaleDateString()}`,
                              body: `Buen día ${selectedContactDoc.encargado}:\n\nSolicito amablemente la factura correspondiente a la consulta del día de hoy con el Dr. ${selectedContactDoc.nombre}.\n\nMis datos fiscales son:\nRFC: ${patient.rfc}\nNombre: ${patient.name}\nCP: ${patient.cp}\nRégimen: ${patient.regimen}\nUso CFDI: ${patient.usoCFDI}\n\nQuedo al pendiente. ¡Gracias!`
                            });
                          }} 
                        />
                      </div>
                    </div>

                    {/* Sección 3: Acciones rápidas */}
                    <div>
                      <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.15em] mb-4 ml-1">Acciones rápidas</p>
                      <div className="space-y-3">
                        <ContactOption 
                          icon={CalendarDays} 
                          title="Agendar próxima cita" 
                          desc="Ver disponibilidad" 
                          onClick={() => setContactView('schedule')} 
                        />
                        <ContactOption 
                          icon={FileText} 
                          title="Solicitar receta / documento" 
                          desc="Certificados y laboratorios" 
                          onClick={() => setContactView('request')} 
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* VISTA LLAMADA */}
                {contactView === 'calling' && (
                  <div className="flex flex-col items-center justify-center py-12 text-center">
                    <div className="relative mb-8">
                       <div className="w-28 h-28 bg-blue-500 rounded-full animate-pulse flex items-center justify-center">
                          <Phone className="w-12 h-12 text-white" />
                       </div>
                       <div className="absolute inset-0 border-4 border-blue-500/20 rounded-full animate-ping" />
                    </div>
                    <h4 className="text-2xl font-bold text-dark mb-1">Llamando...</h4>
                    <p className="text-blue-500 font-bold mb-8">Dr. {selectedContactDoc.nombre.split(' ').pop()}</p>
                    
                    <div className="bg-gray-100 px-6 py-2 rounded-full font-mono text-xl font-bold mb-12">
                      00:08
                    </div>

                    <button 
                      onClick={() => {
                        setContactView('main');
                        showToast(`✓ Llamada finalizada`);
                        addToHistory(selectedContactDoc.nombre, "Llamada finalizada");
                      }}
                      className="w-16 h-16 bg-red-500 text-white rounded-full flex items-center justify-center shadow-lg shadow-red-500/30 hover:scale-110 active:scale-95 transition-all"
                    >
                      <XCircle className="w-8 h-8" />
                    </button>
                    <button onClick={() => setContactView('main')} className="mt-8 text-xs font-bold text-gray-400 uppercase tracking-widest flex items-center gap-2">
                       <ArrowLeft className="w-3 h-3" /> Atrás
                    </button>
                  </div>
                )}

                {/* VISTA WA MEDICO */}
                {contactView === 'wa_med' && (
                  <div className="space-y-6">
                    <div className="flex items-center gap-3 mb-2">
                       <button onClick={() => setContactView('main')} className="p-2 bg-gray-100 rounded-xl hover:bg-gray-200 transition-colors"><ArrowLeft className="w-4 h-4" /></button>
                       <h4 className="font-bold">WhatsApp al Médico</h4>
                    </div>
                    
                    <div className="bg-[#e5ddd5] p-6 rounded-3xl shadow-inner min-h-[160px] relative">
                       <div className="bg-white p-4 rounded-[1.5rem] rounded-tl-none shadow-md text-sm text-gray-800 max-w-[90%] relative">
                          <div className="absolute -left-2 top-0 w-0 h-0 border-t-[10px] border-t-white border-l-[10px] border-l-transparent"></div>
                          {waMessage} <span className="text-gray-400 border-b-2 border-secondary animate-pulse px-1">...</span>
                       </div>
                    </div>

                    <div>
                      <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 block">Editar mensaje</label>
                      <textarea 
                        value={waMessage}
                        onChange={e => setWaMessage(e.target.value)}
                        className="w-full border border-gray-100 rounded-2xl p-4 bg-gray-50 text-sm outline-none focus:ring-2 focus:ring-[#25D366]/20"
                        rows={3}
                      />
                    </div>

                    <button 
                      onClick={() => {
                        setSelectedContactDoc(null);
                        showToast(`✓ Mensaje enviado al Dr./Dra. ${selectedContactDoc.nombre}`);
                        addToHistory(selectedContactDoc.nombre, "WhatsApp Médico");
                      }}
                      className="w-full bg-[#25D366] text-white py-4 rounded-2xl font-bold shadow-lg shadow-[#25D366]/20 flex items-center justify-center gap-2"
                    >
                      <MessageSquare className="w-5 h-5 fill-white" /> Enviar vía WhatsApp
                    </button>
                  </div>
                )}

                {/* VISTA MAIL MEDICO */}
                {contactView === 'mail_med' && (
                  <div className="space-y-5">
                    <div className="flex items-center gap-3">
                       <button onClick={() => setContactView('main')} className="p-2 bg-gray-100 rounded-xl hover:bg-gray-200 transition-colors"><ArrowLeft className="w-4 h-4" /></button>
                       <h4 className="font-bold">Correo al Médico</h4>
                    </div>
                    
                    <div>
                      <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 block">Para</label>
                      <div className="bg-gray-50 p-3 rounded-xl border border-gray-100 text-xs font-bold text-gray-500">{selectedContactDoc.correo || 'N/A'}</div>
                    </div>

                    <div>
                      <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 block">Asunto</label>
                      <input 
                        type="text" 
                        value={mailForm.subject}
                        onChange={e => setMailForm({...mailForm, subject: e.target.value})}
                        className="w-full border border-gray-100 rounded-xl p-3 bg-gray-50 text-sm outline-none focus:ring-2 focus:ring-blue-100"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 block">Cuerpo del mensaje</label>
                      <textarea 
                        value={mailForm.body}
                        onChange={e => setMailForm({...mailForm, body: e.target.value})}
                        className="w-full border border-gray-100 rounded-xl p-3 bg-gray-50 text-sm outline-none focus:ring-2 focus:ring-blue-100"
                        rows={4}
                      />
                    </div>

                    <button 
                      onClick={() => {
                        setSelectedContactDoc(null);
                        showToast(`✓ Correo enviado`);
                        addToHistory(selectedContactDoc.nombre, "Email Médico");
                      }}
                      className="w-full bg-blue-500 text-white py-4 rounded-2xl font-bold shadow-lg shadow-blue-500/20"
                    >
                      Enviar Correo
                    </button>
                  </div>
                )}

                {/* VISTA WA FACTURACION */}
                {contactView === 'wa_billing' && (
                  <div className="space-y-6">
                    <div className="flex items-center gap-3">
                       <button onClick={() => setContactView('main')} className="p-2 bg-gray-100 rounded-xl hover:bg-gray-200 transition-colors"><ArrowLeft className="w-4 h-4" /></button>
                       <h4 className="font-bold">WhatsApp Facturación</h4>
                    </div>
                    
                    <div className="bg-[#e5ddd5] p-4 rounded-3xl space-y-4">
                       <div className="bg-white p-3 rounded-[1.2rem] rounded-tl-none shadow-md text-xs text-gray-800 max-w-[95%] relative leading-relaxed">
                          <div className="absolute -left-2 top-0 w-0 h-0 border-t-[10px] border-t-white border-l-[10px] border-l-transparent"></div>
                          {waMessage}
                       </div>
                       
                       {/* Tarjeta de Datos Fiscales */}
                       <div className="bg-white p-4 rounded-2xl shadow-md border-l-4 border-secondary">
                          <p className="text-[9px] font-black text-secondary uppercase tracking-[0.2em] mb-2">Datos para facturación</p>
                          <div className="space-y-1 text-[11px] font-bold text-dark">
                             <p>RFC: <span className="text-gray-500">{patient.rfc}</span></p>
                             <p>Nombre: <span className="text-gray-500">{patient.name}</span></p>
                             <p>CP: <span className="text-gray-500">{patient.cp}</span></p>
                             <p>Régimen: <span className="text-gray-500">{patient.regimen}</span></p>
                             <p>Uso CFDI: <span className="text-gray-500">D01</span></p>
                          </div>
                       </div>
                    </div>

                    <button 
                      onClick={() => {
                        setSelectedContactDoc(null);
                        showToast(`✓ Solicitud de factura enviada`);
                        addToHistory(selectedContactDoc.nombre, "WhatsApp Facturación");
                      }}
                      className="w-full bg-[#25D366] text-white py-4 rounded-2xl font-bold shadow-lg shadow-[#25D366]/20 flex items-center justify-center gap-2"
                    >
                      <MessageSquare className="w-5 h-5 fill-white" /> Enviar vía WhatsApp
                    </button>
                  </div>
                )}

                {/* VISTA MAIL FACTURACION */}
                {contactView === 'mail_billing' && (
                  <div className="space-y-5">
                    <div className="flex items-center gap-3">
                       <button onClick={() => setContactView('main')} className="p-2 bg-gray-100 rounded-xl hover:bg-gray-200 transition-colors"><ArrowLeft className="w-4 h-4" /></button>
                       <h4 className="font-bold">Correo a Facturación</h4>
                    </div>
                    
                    <div>
                      <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 block">Destinatario</label>
                      <div className="bg-gray-50 p-3 rounded-xl border border-gray-100 text-xs font-bold text-gray-500">{selectedContactDoc.correoFacturacion || 'N/A'}</div>
                    </div>

                    <div className="bg-gray-50 p-4 rounded-2xl border border-gray-100 space-y-3">
                      <p className="text-[10px] font-bold text-dark italic">"Adjunto mis datos fiscales: {patient.rfc}, {patient.name}, CP {patient.cp}, Régimen {patient.regimen}, Uso {patient.usoCFDI}."</p>
                    </div>

                    <div>
                      <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 block">Mensaje editable</label>
                      <textarea 
                        value={mailForm.body}
                        onChange={e => setMailForm({...mailForm, body: e.target.value})}
                        className="w-full border border-gray-100 rounded-xl p-3 bg-gray-50 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                        rows={5}
                      />
                    </div>

                    <button 
                      onClick={() => {
                        setSelectedContactDoc(null);
                        showToast(`✓ Solicitud enviada al encargado`);
                        addToHistory(selectedContactDoc.nombre, "Email Facturación");
                      }}
                      className="w-full bg-secondary text-white py-4 rounded-2xl font-bold"
                    >
                      Enviar Solicitud
                    </button>
                  </div>
                )}

                {/* VISTA AGENDAR CITA */}
                {contactView === 'schedule' && (
                  <div className="space-y-5">
                    <div className="flex items-center gap-3">
                       <button onClick={() => setContactView('main')} className="p-2 bg-gray-100 rounded-xl hover:bg-gray-200 transition-colors"><ArrowLeft className="w-4 h-4" /></button>
                       <h4 className="font-bold">Nueva cita con Dr. {selectedContactDoc.nombre.split(' ').pop()}</h4>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                       <div>
                         <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1 block">Fecha</label>
                         <input 
                           type="date" 
                           value={scheduleForm.date}
                           onChange={e => setScheduleForm({...scheduleForm, date: e.target.value})}
                           className="w-full border border-gray-100 rounded-xl p-3 bg-gray-50 text-sm" 
                         />
                       </div>
                       <div>
                         <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1 block">Hora</label>
                         <input 
                           type="time" 
                           value={scheduleForm.time}
                           onChange={e => setScheduleForm({...scheduleForm, time: e.target.value})}
                           className="w-full border border-gray-100 rounded-xl p-3 bg-gray-50 text-sm" 
                         />
                       </div>
                    </div>

                    <div>
                       <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1 block">Motivo de consulta</label>
                       <input 
                         type="text" 
                         placeholder="Ej: Revisión general"
                         value={scheduleForm.reason}
                         onChange={e => setScheduleForm({...scheduleForm, reason: e.target.value})}
                         className="w-full border border-gray-100 rounded-xl p-3 bg-gray-50 text-sm" 
                       />
                    </div>

                    <div className="space-y-2 pt-2">
                       <button 
                         onClick={() => {
                            setSelectedContactDoc(null);
                            showToast(`✓ Cita agendada para el ${scheduleForm.date} a las ${scheduleForm.time}`);
                            addToHistory(selectedContactDoc.nombre, "Cita Agendada");
                         }}
                         className="w-full bg-secondary text-white py-3.5 rounded-2xl font-bold flex items-center justify-center gap-2"
                       >
                         <Calendar className="w-4 h-4" /> Agregar al Calendario
                       </button>
                       <button className="w-full bg-[#25D366] text-white py-3.5 rounded-2xl font-bold flex items-center justify-center gap-2">
                         <MessageSquare className="w-4 h-4 fill-white" /> Recordarme por WhatsApp
                       </button>
                       <button className="w-full bg-blue-500 text-white py-3.5 rounded-2xl font-bold flex items-center justify-center gap-2">
                         <Mail className="w-4 h-4" /> Recordarme por Correo
                       </button>
                    </div>
                  </div>
                )}

                {/* VISTA SOLICITAR DOCUMENTO */}
                {contactView === 'request' && (
                  <div className="space-y-6">
                    <div className="flex items-center gap-3">
                       <button onClick={() => setContactView('main')} className="p-2 bg-gray-100 rounded-xl hover:bg-gray-200 transition-colors"><ArrowLeft className="w-4 h-4" /></button>
                       <h4 className="font-bold">Solicitar Documento</h4>
                    </div>

                    <div className="space-y-2">
                       {['Receta médica', 'Resumen clínico', 'Constancia de consulta', 'Resultados de estudios', 'Otro'].map(type => (
                          <button 
                            key={type}
                            onClick={() => setRequestType(type)}
                            className={`w-full p-4 rounded-2xl border flex items-center justify-between transition-all ${
                              requestType === type ? 'border-secondary bg-secondary/5' : 'border-gray-50 bg-gray-50/50 hover:bg-gray-100'
                            }`}
                          >
                             <span className={`text-sm font-bold ${requestType === type ? 'text-secondary' : 'text-gray-500'}`}>{type}</span>
                             {requestType === type && <div className="w-5 h-5 bg-secondary rounded-full flex items-center justify-center"><Check className="w-3 h-3 text-white" /></div>}
                          </button>
                       ))}
                    </div>

                    <button 
                      onClick={() => {
                        setSelectedContactDoc(null);
                        showToast(`✓ Solicitud de ${requestType} enviada`);
                        addToHistory(selectedContactDoc.nombre, `Solicitud: ${requestType}`);
                      }}
                      className="w-full bg-secondary text-white py-4 rounded-2xl font-black shadow-lg shadow-secondary/20"
                    >
                      Enviar Solicitud por WhatsApp
                    </button>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

// Helper para opciones de contacto - Refined
function ContactOption({ icon: Icon, title, desc, onClick, disabled }: any) {
  return (
    <button 
      onClick={onClick}
      disabled={disabled}
      className={`w-full p-4 rounded-2xl border transition-all flex items-center justify-between group shadow-sm ${
        disabled 
          ? 'bg-gray-50 border-gray-100 opacity-50 cursor-not-allowed' 
          : 'bg-white border-gray-100 hover:border-secondary hover:bg-secondary/5 active:scale-95'
      }`}
    >
      <div className="flex items-center gap-4">
        <div className={`w-12 h-12 rounded-full flex items-center justify-center transition-transform ${
          disabled ? 'bg-gray-200 text-gray-400' : 'bg-green-100 text-green-600 group-hover:scale-110'
        }`}>
          <Icon className="w-5 h-5" />
        </div>
        <div className="text-left">
          <h5 className={`text-sm font-bold ${disabled ? 'text-gray-400' : 'text-dark'}`}>{title}</h5>
          <p className="text-[10px] text-gray-400 font-medium">{desc}</p>
        </div>
      </div>
      {!disabled && <ChevronRight className="w-4 h-4 text-gray-300 group-hover:translate-x-1 transition-transform" />}
    </button>
  );
}

function PFFacturas() {
  const { showToast, setIsAdminMode, isAdminMode, t } = useAppContext();
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState<any | null>(null);
  const [showNotification, setShowNotification] = useState<{ doctor: string, date: string } | null>(null);
  const [paymentMethod, setPaymentMethod] = useState('');

  const facturas = [
    { folio: 'A-102', emisor: 'Dr. José Ramírez', date: '20/10/2025', monto: '$1,200', uso: t.pf_view.invoice?.uso_cfdi || 'D01 Medical Fees', status: 'ok' },
    { folio: 'HOS-99', emisor: 'Hospital Ángeles', date: '12/10/2025', monto: '$4,100', uso: t.pf_view.invoice?.uso_cfdi || 'D01 Medical Fees', status: 'pending' },
    { folio: 'B-304', emisor: 'Dra. Mónica López', date: '18/10/2025', monto: '$950', uso: t.pf_view.invoice?.uso_cfdi || 'D01 Medical Fees', status: 'pending' },
    { folio: 'C-01', emisor: 'Dr. Roberto Torres', date: '05/10/2025', monto: '$1,800', uso: t.pf_view.invoice?.uso_cfdi || 'D01 Medical Fees', status: 'ok' },
  ];

  const medicos = [
    { name: 'Dr. José Ramírez' },
    { name: 'Dra. Mónica López' },
    { name: 'Hospital Ángeles' },
    { name: 'Dr. Roberto Torres' }
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-end items-center gap-4">
        {/* Switch Modo Administrador Reubicado */}
        <div className="flex items-center gap-3 bg-white px-5 py-3 rounded-2xl border border-gray-100 shadow-sm transition-all hover:shadow-md">
          <span className={`text-[10px] font-black uppercase tracking-widest ${isAdminMode ? 'text-gray-300' : 'text-dark'}`}>Personal</span>
          <button 
            onClick={() => {
              setIsAdminMode(!isAdminMode);
              showToast(isAdminMode ? "Vista Personal activada" : "🛠️ Modo edición administrativa activado");
            }}
            className={`w-14 h-7 rounded-full relative transition-all duration-300 ${isAdminMode ? 'bg-secondary' : 'bg-gray-200'}`}
          >
            <motion.div 
              layout
              className={`absolute top-1 w-5 h-5 rounded-full transition-all duration-300 flex items-center justify-center ${
                isAdminMode ? 'left-8 bg-white shadow-md' : 'left-1 bg-gray-500 shadow-sm'
              }`}
            >
              {isAdminMode && <Check className="w-3 h-3 text-secondary" />}
            </motion.div>
          </button>
          <span className={`text-[10px] font-black uppercase tracking-widest ${isAdminMode ? 'text-secondary' : 'text-gray-300'}`}>Admin</span>
        </div>

        <button 
          onClick={() => setShowAddModal(true)}
          className="bg-secondary text-white px-8 py-3.5 rounded-2xl font-black transition-all flex items-center gap-2.5 shadow-xl shadow-secondary/30 active:scale-95"
        >
          <Plus className="w-5 h-5" />
          <span>{t.pf_view.add_factura || 'Agregar Factura'}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-secondary text-white p-6 rounded-2xl shadow-sm">
          <p className="text-secondary-light text-sm font-medium uppercase tracking-wider mb-1">{t.pf_view.total_deductible || 'Total Deducible (2025)'}</p>
          <p className="text-4xl font-bold font-serif tracking-tight">$7,850 <span className="text-xl font-sans text-secondary-light font-normal">MXN</span></p>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
          <p className="text-gray-400 text-sm font-medium uppercase tracking-wider mb-1">{t.pf_view.waiting_cfdi || 'En espera de CFDI'}</p>
          <p className="text-4xl font-bold font-serif text-dark tracking-tight">$4,350 <span className="text-xl font-sans text-gray-400 font-normal">MXN</span></p>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="p-5 border-b border-gray-100">
          <h3 className="font-semibold text-dark">{t.pf_view.cfdi_history || 'Historial de CFDI'}</h3>
        </div>
        <div className="hidden md:block overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-gray-100 text-gray-500 bg-gray-50/50 italic">
                <th className="p-4 font-medium uppercase tracking-widest text-[10px]">{t.pyme_view.validation?.table?.folio || 'Folio'}</th>
                <th className="p-4 font-medium uppercase tracking-widest text-[10px]">{t.pyme_view.validation?.table?.provider || 'Emisor'}</th>
                <th className="p-4 font-medium uppercase tracking-widest text-[10px]">{t.common.date || 'Fecha'}</th>
                <th className="p-4 font-medium uppercase tracking-widest text-[10px]">{t.common.amount || 'Monto'}</th>
                <th className="p-4 font-medium uppercase tracking-widest text-[10px]">{t.pf_view.cfdi_usage || 'Uso CFDI'}</th>
                <th className="p-4 font-medium uppercase tracking-widest text-[10px]">{t.common.status_label || 'Estado'}</th>
                <th className="p-4 font-medium text-right uppercase tracking-widest text-[10px]">{t.common.actions || 'Acción'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {facturas.map((row, i) => (
                <tr key={i} className="hover:bg-gray-50 transition-colors">
                  <td className="p-4 text-xs font-mono text-gray-500 font-bold">{row.folio}</td>
                  <td className="p-4 font-bold text-dark">{row.emisor}</td>
                  <td className="p-4 text-gray-500">{row.date}</td>
                  <td className="p-4 font-bold text-secondary">{row.monto}</td>
                  <td className="p-4 text-xs text-gray-400 font-medium">{row.uso}</td>
                  <td className="p-4">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold uppercase ${row.status === 'ok' ? 'bg-secondary-light text-secondary' : 'bg-amber-50 text-amber-600'}`}>
                      {row.status === 'ok' ? t.pf_view.invoice?.status_ok || 'OK' : t.pf_view.invoice?.status_pending || 'Pendiente'}
                    </span>
                  </td>
                  <td className="p-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                       <button 
                         onClick={() => setSelectedInvoice({ ...row, receptor: 'Ana García' })}
                         className="p-2 text-secondary hover:bg-secondary-light rounded-xl transition-all"
                         title="Ver CFDI"
                       >
                         <Eye className="w-4 h-4" />
                       </button>

                       {isAdminMode && (
                         <>
                           <button 
                             onClick={() => showToast(`🛠️ Editando folio ${row.folio}...`)}
                             className="p-2 bg-blue-50 text-blue-500 rounded-lg hover:bg-blue-100 transition-all active:scale-90"
                             title="Editar Factura"
                           >
                             <Pencil className="w-3.5 h-3.5" />
                           </button>
                           <button 
                             onClick={() => showToast(`🗑️ Factura ${row.folio} eliminada`)}
                             className="p-2 bg-red-50 text-red-500 rounded-lg hover:bg-red-100 transition-all active:scale-90"
                             title="Eliminar Factura"
                           >
                             <XCircle className="w-3.5 h-3.5" />
                           </button>
                         </>
                       )}
                       
                       {row.status === 'pending' && !isAdminMode && (
                         <button onClick={() => showToast("✓ Notificación enviada")} className="inline-flex items-center gap-1 text-[10px] font-bold uppercase text-amber-600 hover:text-amber-700 bg-amber-50 hover:bg-amber-100 px-3 py-1.5 rounded-lg transition-colors">
                           <MessageSquare className="w-3.5 h-3.5" /> {t.pf_view.invoice?.claim || 'Claim'}
                         </button>
                       )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Mobile View */}
        <div className="md:hidden divide-y divide-gray-100">
          {facturas.map((row, idx) => (
            <div key={idx} className="p-4 flex flex-col gap-3 bg-white">
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="font-bold text-dark">{row.emisor}</h4>
                  <p className="text-[10px] font-mono text-gray-400 mt-0.5">{row.folio} · {row.uso}</p>
                </div>
                <div className="text-right">
                  <p className="font-bold text-dark">{row.monto}</p>
                  <p className="text-[10px] text-gray-500">{row.date}</p>
                </div>
              </div>
              <div className="flex justify-between items-center pt-2">
                {row.status === 'ok' ? (
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-secondary-light text-secondary">{t.pf_view.invoice?.status_ok || 'Válida'}</span>
                ) : (
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-amber-50 text-amber-600">{t.pf_view.invoice?.status_pending || 'Pendiente'}</span>
                )}
                
                <div className="flex gap-2">
                  <button 
                    onClick={() => setSelectedInvoice({ ...row, receptor: 'Ana García' })}
                    className="p-2 text-secondary hover:bg-secondary-light rounded-lg"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                  {row.status === 'pending' && (
                    <button 
                      onClick={() => showToast("✓ Notificación enviada")} 
                      className="text-[10px] font-bold uppercase text-amber-600 bg-amber-50 px-3 py-1.5 rounded-lg active:scale-95 transition-transform"
                    >
                      {t.pf_view.invoice?.claim || 'Claim'}
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {showAddModal && (
        <div className="fixed inset-0 bg-dark/60 backdrop-blur-sm z-[200] flex items-center justify-center p-4" onClick={() => setShowAddModal(false)}>
           <motion.div 
             initial={{ opacity: 0, scale: 0.9 }}
             animate={{ opacity: 1, scale: 1 }}
             className="bg-white w-full max-w-lg rounded-[2.5rem] p-8 shadow-2xl relative"
             onClick={e => e.stopPropagation()}
           >
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-2xl font-bold text-dark">Agregar Factura</h3>
                <button onClick={() => setShowAddModal(false)} className="p-2 hover:bg-gray-100 rounded-full"><XCircle className="w-6 h-6 text-gray-400"/></button>
              </div>

              <div className="space-y-5">
                 <div>
                   <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5 block">Médico</label>
                   <select id="invoice-medico" className="w-full border border-gray-100 rounded-2xl p-3.5 bg-gray-50 outline-none focus:ring-2 focus:ring-secondary/20 transition-all text-sm font-medium">
                      {medicos.map(m => <option key={m.name}>{m.name}</option>)}
                   </select>
                 </div>
                 <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5 block">Fecha de consulta</label>
                      <input id="invoice-date" type="date" className="w-full border border-gray-100 rounded-2xl p-3.5 bg-gray-50 outline-none focus:ring-2 focus:ring-secondary/20 transition-all text-sm font-medium" />
                    </div>
                    <div>
                       <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5 block">Monto pagado</label>
                       <div className="relative">
                          <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 font-bold">$</span>
                          <input type="number" placeholder="0,000.00" className="w-full border border-gray-100 rounded-2xl py-3.5 pl-8 pr-4 bg-gray-50 outline-none focus:ring-2 focus:ring-secondary/20 transition-all text-sm font-bold" />
                       </div>
                    </div>
                 </div>
                 <div>
                   <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5 block">Método de pago</label>
                   <select 
                     value={paymentMethod}
                     onChange={e => setPaymentMethod(e.target.value)}
                     className="w-full border border-gray-100 rounded-2xl p-3.5 bg-gray-50 outline-none focus:ring-2 focus:ring-secondary/20 transition-all text-sm font-medium"
                   >
                      <option value="">Selecciona método</option>
                      <option value="Transferencia">Transferencia</option>
                      <option value="Tarjeta de crédito">Tarjeta de crédito</option>
                      <option value="Tarjeta de débito">Tarjeta de débito</option>
                      <option value="Efectivo">Efectivo</option>
                   </select>
                   {paymentMethod === 'Efectivo' && (
                     <div className="mt-2 p-3 bg-red-50 border border-red-100 rounded-xl flex items-center gap-2 text-xs text-red-700 font-bold italic">
                        <AlertCircle className="w-4 h-4" /> ⚠ Los pagos en efectivo NO son deducibles.
                     </div>
                   )}
                 </div>

                 <button 
                  onClick={() => {
                    const el = document.getElementById('invoice-medico') as HTMLSelectElement;
                    const dateEl = document.getElementById('invoice-date') as HTMLInputElement;
                    setShowAddModal(false);
                    if (el && dateEl) {
                      setShowNotification({ doctor: el.value, date: dateEl.value });
                    }
                    showToast("✓ Factura registrada correctamente");
                  }}
                  className="w-full py-4 bg-secondary text-white rounded-2xl font-bold shadow-xl shadow-secondary/30 hover:bg-secondary-dark transition-all mt-4"
                 >
                   Guardar Factura
                 </button>
              </div>
           </motion.div>
        </div>
      )}

      {showNotification && (
        <AppointmentNotification 
          data={showNotification} 
          onClose={() => setShowNotification(null)} 
        />
      )}

      {selectedInvoice && (
        <CFDIViewer 
          data={selectedInvoice} 
          onClose={() => setSelectedInvoice(null)} 
        />
      )}
    </div>
  );
}

function PFAsesor() {
  const { showToast, setCurrentView, t } = useAppContext();
  const [messages, setMessages] = useState([
    { role: 'system', content: t.pf_view.advisor.greeting + '\n\n**Note:** ' + t.pf_view.advisor.legal_notice }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [questionCount, setQuestionCount] = useState(0);
  const MAX_QUESTIONS = 10;

  const getAIResponse = (text: string) => {
    const msg = text.toLowerCase();
    
    // Keywords in multiple languages (partial match)
    const matchesCash = ['efectivo', 'cash', 'argent', 'dinheiro', 'contanti', '现金'];
    const matchesDeductibles = ['deducib', 'qué puedo', 'gastos', 'deductible', 'what can i', 'expenses', 'déductible', 'puedo deducir', 'despesas', 'dedutível', 'deducibile', 'detraibile', 'spese', '可扣除', '费用'];
    const matchesLimits = ['límite', 'cuánto', 'monto', 'limit', 'how much', 'amount', 'limite', 'combien', 'montant', 'quanto', 'quantia', 'importo', '限制', '限额', '多少'];
    const matchesFamily = ['hijo', 'espos', 'famili', 'padre', 'child', 'wife', 'family', 'parent', 'enfant', 'famille', 'père', 'mère', 'filho', 'esposa', 'família', 'pai', 'mãe', 'figlio', 'moglie', 'famiglia', 'padre', 'madre', '孩子', '妻子', '家庭', '父母'];
    const matchesLabs = ['estud', 'laborato', 'study', 'lab', 'étude', 'laboratoire', 'estudo', 'laboratório', 'studio', 'laboratorio', '实验室'];
    const matchesMedicine = ['medicament', 'medicine', 'medication', 'médicament', 'medicamento', 'farmaco', '药物'];
    const matchesGlasses = ['lente', 'glasses', 'lunettes', 'óculos', 'occhiali', '眼镜'];

    if (matchesCash.some(k => msg.includes(k))) {
      return t.pf_view.advisor.replies.cash;
    }
    
    if (matchesDeductibles.some(k => msg.includes(k))) {
      return t.pf_view.advisor.replies.deductibles;
    }

    if (matchesLimits.some(k => msg.includes(k))) {
      return t.pf_view.advisor.replies.limits;
    }

    if (matchesFamily.some(k => msg.includes(k))) {
      return t.pf_view.advisor.replies.family;
    }

    if (matchesLabs.some(k => msg.includes(k))) {
      return t.pf_view.advisor.replies.labs;
    }

    if (matchesMedicine.some(k => msg.includes(k))) {
      return t.pf_view.advisor.replies.medicine;
    }

    if (matchesGlasses.some(k => msg.includes(k))) {
      return t.pf_view.advisor.replies.glasses;
    }

    return t.pf_view.advisor.replies.default;
  };

  const sendPrompt = (text: string) => {
    if(!text.trim() || isTyping || questionCount >= MAX_QUESTIONS) return;
    
    const newUserMessage = { role: 'user', content: text };
    setMessages(prev => [...prev, newUserMessage]);
    setInput('');
    setIsTyping(true);
    
    const newCount = questionCount + 1;
    setQuestionCount(newCount);
    
    setTimeout(() => {
      let reply = getAIResponse(text);
      
      if (newCount >= MAX_QUESTIONS) {
        reply += t.pf_view.advisor.limit_notice;
      }
      
      setMessages(prev => [...prev, { role: 'system', content: reply }]);
      setIsTyping(false);
      
      if (newCount >= MAX_QUESTIONS) {
        showToast(t.pf_view.advisor.limit_reached);
      }
    }, 1500);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-200px)] bg-white rounded-3xl shadow-xl border border-gray-100 overflow-hidden">
      <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-secondary rounded-2xl flex items-center justify-center text-white">
            < Bot className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold text-dark">{t.pf_view.advisor.title}</h3>
            <span className="text-[10px] text-secondary font-bold uppercase">{t.pf_view.advisor.online}</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
           <button 
             onClick={() => {
               setMessages([{ role: 'system', content: t.pf_view.advisor.greeting }]);
               setQuestionCount(0);
               showToast(t.pf_view.advisor.reset_toast);
             }}
             className="p-2 text-gray-400 hover:text-secondary hover:bg-secondary/5 rounded-xl transition-all"
             title="Limpiar chat"
           >
             <RefreshCw className="w-5 h-5" />
           </button>
           <button 
             disabled
             className="p-2 text-gray-400 hover:bg-gray-50 rounded-xl transition-all"
           >
             <MoreVertical className="w-5 h-5" />
           </button>
        </div>
      </div>
      <div className="bg-blue-50 px-6 py-3 border-b border-blue-100 flex items-center gap-3">
        <Info className="w-4 h-4 text-blue-500 shrink-0" />
        <p className="text-xs text-blue-700 font-medium leading-tight">
          {t.pf_view.advisor.legal_notice}
        </p>
      </div>

      <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-4 md:space-y-6 bg-gray-50/30">
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === 'user' ? 'justify-end pl-12' : 'justify-start pr-12'}`}>
            <div className={`max-w-[100%] md:max-w-[85%] px-5 py-3.5 rounded-2xl ${m.role === 'user' ? 'bg-secondary text-white rounded-tr-none shadow-lg shadow-secondary/10' : 'bg-white border border-gray-200 text-gray-800 rounded-tl-none shadow-sm'}`}>
              <p className="text-sm leading-relaxed whitespace-pre-wrap">{m.content}</p>
            </div>
          </div>
        ))}
        {isTyping && <div className="text-xs text-gray-400 animate-pulse pl-2 flex items-center gap-2">
          <span className="flex gap-1">
            <span className="w-1.5 h-1.5 bg-gray-300 rounded-full animate-bounce"></span>
            <span className="w-1.5 h-1.5 bg-gray-300 rounded-full animate-bounce [animation-delay:0.2s]"></span>
            <span className="w-1.5 h-1.5 bg-gray-300 rounded-full animate-bounce [animation-delay:0.4s]"></span>
          </span>
          {t.pf_view.advisor.typing}
        </div>}
      </div>

      <div className="p-6 border-t border-gray-100 bg-white">
        {questionCount >= MAX_QUESTIONS ? (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col items-center text-center gap-4 py-2"
          >
            <p className="text-sm font-medium text-gray-500 italic">"La mejor estrategia fiscal se hace de la mano de un experto."</p>
            <button 
              onClick={() => setCurrentView('directorio')}
              className="w-full bg-dark text-white py-4 rounded-2xl font-bold shadow-xl shadow-black/20 hover:scale-[1.02] transition-all flex items-center justify-center gap-3 active:scale-95"
            >
              <BriefcaseBusiness className="w-5 h-5 text-secondary" /> 
              {t.pf_view.advisor.consult_accountant}
            </button>
          </motion.div>
        ) : (
          <div className="flex gap-2">
            <input 
              type="text" 
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && sendPrompt(input)}
              placeholder={t.pf_view.advisor.placeholder}
              className="flex-1 bg-gray-50 border border-gray-100 rounded-2xl px-4 py-3 outline-none focus:ring-2 focus:ring-secondary/20 transition-all"
            />
            <button 
              onClick={() => sendPrompt(input)} 
              className="bg-secondary text-white p-3 rounded-2xl hover:bg-secondary-dark transition-all disabled:opacity-50"
              disabled={isTyping}
            >
              <Send className="w-5 h-5"/>
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function PFDirectorio() {
  const { showToast, t } = useAppContext();
  const [selectedState, setSelectedState] = useState('CDMX');
  const [selectedMunicipio, setSelectedMunicipio] = useState('');
  const [locModal, setLocModal] = useState(false);
  
  // States for hiring options
  const [selectedHirePro, setSelectedHirePro] = useState<any | null>(null);
  const [isCalling, setIsCalling] = useState(false);
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [emailBody, setEmailBody] = useState('Hola, quisiera solicitar sus servicios para la gestión de mis facturas y declaraciones mensuales. Quedo atento a su respuesta.');
  const [showWaModal, setShowWaModal] = useState(false);
  const [waMessage, setWaMessage] = useState('Hola, vi su perfil en Puente contable y me interesa contratar sus servicios contables.');
  
  const MEXICO_LOCATIONS: Record<string, string[]> = {
    'Aguascalientes': ['Aguascalientes', 'Asientos', 'Calvillo'],
    'Baja California': ['Ensenada', 'Mexicali', 'Tijuana'],
    'Baja California Sur': ['La Paz', 'Los Cabos'],
    'Campeche': ['Campeche', 'Ciudad del Carmen'],
    'Chiapas': ['Tuxtla Gutiérrez', 'San Cristóbal de las Casas', 'Tapachula'],
    'Chihuahua': ['Chihuahua', 'Ciudad Juárez', 'Delicias', 'Cuauhtémoc'],
    'Coahuila': ['Saltillo', 'Torreón', 'Monclova'],
    'Colima': ['Colima', 'Manzanillo', 'Villa de Álvarez'],
    'CDMX': ['Benito Juárez', 'Coyoacán', 'Cuauhtémoc', 'Miguel Hidalgo', 'Álvaro Obregón', 'Tlalpan'],
    'Durango': ['Durango', 'Gómez Palacio', 'Lerdo'],
    'Guanajuato': ['León', 'Irapuato', 'Celaya', 'Guanajuato', 'Salamanca'],
    'Guerrero': ['Acapulco', 'Chilpancingo', 'Iguala', 'Zihuatanejo'],
    'Hidalgo': ['Pachuca', 'Tulancingo', 'Tizayuca'],
    'Jalisco': ['Guadalajara', 'Zapopan', 'Tlaquepaque', 'Tonalá', 'Puerto Vallarta'],
    'México': ['Toluca', 'Ecapetec', 'Naucalpan', 'Tlalnepantla', 'Chimalhuacán'],
    'Michoacán': ['Morelia', 'Uruapan', 'Zamora'],
    'Morelos': ['Cuernavaca', 'Jiutepec', 'Cuautla'],
    'Nayarit': ['Tepic', 'Bahía de Banderas'],
    'Nuevo León': ['Monterrey', 'San Pedro Garza García', 'Guadalupe', 'Apodaca', 'San Nicolás'],
    'Oaxaca': ['Oaxaca de Juárez', 'San Juan Bautista Tuxtepec'],
    'Puebla': ['Puebla de Zaragoza', 'Tehuacán', 'San Andrés Cholula'],
    'Querétaro': ['Querétaro', 'San Juan del Río'],
    'Quintana Roo': ['Cancún', 'Playa del Carmen', 'Chetumal'],
    'San Luis Potosí': ['San Luis Potosí', 'Ciudad Valles'],
    'Sinaloa': ['Culiacán', 'Mazatlán', 'Los Mochis'],
    'Sonora': ['Hermosillo', 'Ciudad Obregón', 'Nogales'],
    'Tabasco': ['Villahermosa', 'Cárdenas'],
    'Tamaulipas': ['Reynosa', 'Matamoros', 'Nuevo Laredo', 'Tampico'],
    'Tlaxcala': ['Tlaxcala', 'Apizaco'],
    'Veracruz': ['Veracruz', 'Xalapa', 'Coatzacoalcos', 'Boca del Río'],
    'Yucatán': ['Mérida', 'Kanasín', 'Valladolid'],
    'Zacatecas': ['Zacatecas', 'Fresnillo', 'Guadalupe']
  };

  const PROS_DB: Record<string, Record<string, any[]>> = {
    'CDMX': {
      'Benito Juárez': [
        { name: 'C.P. Carlos Mendoza', spec: 'Fiscal / Personas Físicas', stars: 4.9, dist: '0.5 km', img: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop' },
        { name: 'Mtra. Elena Pozos', spec: 'Asesoría Integral', stars: 4.7, dist: '1.2 km', img: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&h=200&fit=crop' }
      ],
      'Coyoacán': [
        { name: 'C.P.C. Laura Vega', spec: 'Auditoría / PYMES', stars: 4.8, dist: '2.1 km', img: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&h=200&fit=crop' },
        { name: 'Lic. Pedro Salazar', spec: 'Defensa SAT', stars: 4.6, dist: '3.5 km', img: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=200&h=200&fit=crop' }
      ],
      'Miguel Hidalgo': [
        { name: 'Mtro. Roberto Ruiz', spec: 'Estrategia Fiscal Luxury', stars: 5.0, dist: '0.8 km', img: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&h=200&fit=crop' },
        { name: 'C.P. Ana Beltrán', spec: 'Declaraciones Extranjeros', stars: 4.9, dist: 'Polanco', img: 'https://images.unsplash.com/photo-1548142813-c348350df52b?w=200&h=200&fit=crop' }
      ]
    },
    'Jalisco': {
      'Guadalajara': [
        { name: 'Lic. Fernanda Ortiz', spec: 'Impuestos Estatales', stars: 4.9, dist: 'La Minerva', img: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&h=200&fit=crop' },
        { name: 'C.P. Mario Gómez', spec: 'Sueldos y Salarios', stars: 4.4, dist: 'Centro', img: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=200&h=200&fit=crop' }
      ],
      'Zapopan': [
        { name: 'C.P. Jorge Silva', spec: 'Costos y Presupuestos', stars: 4.6, dist: 'Andares', img: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop' },
        { name: 'Mtra. Sofía Luján', spec: 'Finanzas Corporativas', stars: 4.8, dist: 'Puerta de Hierro', img: 'https://images.unsplash.com/photo-1567532939604-b6b5b0db2604?w=200&h=200&fit=crop' }
      ]
    },
    'Nuevo León': {
      'San Pedro Garza García': [
        { name: 'C.P. Patricia Luna', spec: 'Comercio Exterior / Wealth', stars: 5.0, dist: 'Valle Oriente', img: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&h=200&fit=crop' },
        { name: 'Dr. Miguel Garza', spec: 'Estrategia Patrimonial', stars: 4.8, dist: 'Valle Poniente', img: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=200&h=200&fit=crop' }
      ],
      'Monterrey': [
        { name: 'Lic. Sergio Varela', spec: 'Contabilidad Business', stars: 4.7, dist: 'Santa María', img: 'https://images.unsplash.com/photo-1556157382-97eda2d62296?w=200&h=200&fit=crop' },
        { name: 'C.P. Claudia Treviño', spec: 'Nóminas y Seguridad Social', stars: 4.5, dist: 'Centro', img: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=200&h=200&fit=crop' }
      ]
    },
    'Querétaro': {
      'Querétaro': [
        { name: 'C.P. Ricardo Anaya', spec: 'Impuestos Federales', stars: 4.9, dist: 'Juriquilla', img: 'https://images.unsplash.com/photo-1463453091185-61582044d556?w=200&h=200&fit=crop' },
        { name: 'Lic. Marisol Vega', spec: 'Contabilidad para Médicos', stars: 4.8, dist: 'El Campanario', img: 'https://images.unsplash.com/photo-1554151228-14d9def656e4?w=200&h=200&fit=crop' }
      ]
    },
    'Yucatán': {
      'Mérida': [
        { name: 'C.P. Manuel Ek', spec: 'RIF / Resico Especialista', stars: 4.9, dist: 'Altabrisa', img: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=200&h=200&fit=crop' },
        { name: 'Lic. Beatriz Cupul', spec: 'Auditoría Gubernamental', stars: 4.7, dist: 'Centro', img: 'https://images.unsplash.com/photo-1531123897727-8f129e16fd8c?w=200&h=200&fit=crop' }
      ]
    }
  };

  const getFilteredPros = () => {
    const stateData = PROS_DB[selectedState];
    if (!stateData) return [
      { name: 'C.P. Alberto Domínguez', spec: 'Contabilidad General', stars: 4.5, dist: 'Disponible Online', img: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=100&h=100&fit=crop' }
    ];
    
    if (selectedMunicipio && stateData[selectedMunicipio]) {
      return stateData[selectedMunicipio];
    }
    
    // Si no hay municipio seleccionado, unir todos los del estado
    return Object.values(stateData).flat();
  };

  const currentPros = getFilteredPros();

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex flex-col md:flex-row justify-between items-center gap-4">
        <div className="flex items-center gap-3">
          <div className="bg-secondary/10 p-3 rounded-2xl">
            <MapPin className="w-6 h-6 text-secondary" />
          </div>
          <div>
            <h3 className="font-bold text-dark text-lg leading-tight">{t.contador_view?.directorio?.title ? t.contador_view.directorio.title.replace('{location}', selectedState || 'tu zona') : `Contadores en ${selectedState || 'tu zona'}`}</h3>
            <p className="text-sm text-gray-500 font-medium">{t.contador_view?.directorio?.subtitle || 'Encuentra al experto ideal para tu situación fiscal'}</p>
          </div>
        </div>
        <button onClick={() => setLocModal(true)} className="bg-secondary hover:bg-secondary-dark text-white px-6 py-3 rounded-xl text-sm font-bold transition-all shadow-lg shadow-secondary/20">
          {t.contador_view?.directorio?.change_location || '📍 Cambiar Ubicación'}
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pb-12">
        {currentPros.map((pro, i) => (
          <motion.div 
            key={pro.name} 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-white p-5 rounded-[2rem] border border-gray-100 shadow-sm flex flex-col sm:flex-row gap-5 hover:shadow-md transition-all group relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-24 h-24 bg-secondary/5 rounded-bl-[4rem] group-hover:scale-110 transition-transform" />
            
            <div className="relative z-10 w-20 h-20 shrink-0 mx-auto sm:mx-0">
               <img src={pro.img} alt={pro.name} className="w-full h-full object-cover rounded-2xl shadow-inner border border-gray-100" />
               <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-green-500 border-2 border-white rounded-full" />
            </div>

            <div className="flex-1 relative z-10 text-center sm:text-left">
              <h4 className="font-bold text-dark text-lg">{pro.name}</h4>
              <p className="text-xs text-secondary font-bold uppercase tracking-widest mt-0.5 mb-2">{pro.spec}</p>
              
              <div className="flex flex-wrap justify-center sm:justify-start gap-4 text-xs font-bold text-gray-400">
                <span className="flex items-center gap-1 text-amber-500">
                  <Star className="w-3.5 h-3.5 fill-amber-500"/> {pro.stars}
                </span>
                <span className="flex items-center gap-1">
                  <BriefcaseBusiness className="w-3.5 h-3.5" /> 120+ Clientes
                </span>
                <span className="flex items-center gap-1">
                  <Compass className="w-3.5 h-3.5" /> {pro.dist}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-2 mt-4 sm:mt-0 sm:justify-center relative z-10">
              <button 
                onClick={() => setSelectedHirePro(pro)}
                className="bg-secondary text-white px-6 py-2.5 rounded-xl text-xs font-black shadow-md hover:bg-secondary-dark transition-all"
              >
                {t.contador_view?.directorio?.hire || 'Contratar'}
              </button>
              <button 
                onClick={() => setSelectedHirePro(pro)}
                className="bg-gray-50 text-dark px-6 py-2.5 rounded-xl text-xs font-bold border border-gray-100 hover:bg-white"
              >
                {t.contador_view?.directorio?.profile || 'Perfil'}
              </button>
            </div>
          </motion.div>
        ))}
      </div>

      {locModal && (
        <div className="fixed inset-0 bg-dark/60 backdrop-blur-sm z-[200] flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-3xl p-6 shadow-2xl">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold">{t.contador_view?.directorio?.change_location?.replace('📍', '').trim() || 'Ubicación'}</h3>
              <button onClick={() => setLocModal(false)}><XCircle className="w-6 h-6 text-gray-300"/></button>
            </div>
            <div className="space-y-4">
              <select 
                value={selectedState} 
                onChange={e => { setSelectedState(e.target.value); setSelectedMunicipio(''); }}
                className="w-full border border-gray-100 rounded-xl p-3 bg-gray-50 outline-none"
              >
                <option value="">{t.contador_view?.directorio?.location_modal?.state_title || 'Seleccionar Estado'}</option>
                {Object.keys(MEXICO_LOCATIONS).map(st => <option key={st}>{st}</option>)}
              </select>
              {selectedState && (
                <select 
                  value={selectedMunicipio} 
                  onChange={e => setSelectedMunicipio(e.target.value)}
                  className="w-full border border-gray-100 rounded-xl p-3 bg-gray-50 outline-none"
                >
                  <option value="">{t.contador_view?.directorio?.location_modal?.municipality_title || 'Seleccionar Municipio'}</option>
                  {MEXICO_LOCATIONS[selectedState].map(m => <option key={m}>{m}</option>)}
                </select>
              )}
              <button onClick={() => setLocModal(false)} className="w-full bg-secondary text-white py-3 rounded-xl font-bold">{t.contador_view?.directorio?.booking?.confirm || 'Confirmar'}</button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Principal de Contratación */}
      <AnimatePresence>
        {selectedHirePro && !isCalling && !showEmailModal && !showWaModal && (
          <div className="fixed inset-0 bg-dark/60 backdrop-blur-md z-[200] flex items-center justify-center p-4" onClick={() => setSelectedHirePro(null)}>
            <motion.div 
              initial={{ opacity: 0, y: 50, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 50, scale: 0.9 }}
              className="bg-white w-full max-w-sm rounded-[2.5rem] p-8 shadow-2xl relative text-center overflow-hidden"
              onClick={e => e.stopPropagation()}
            >
              <div className="absolute top-0 left-0 w-full h-24 bg-gradient-to-b from-secondary/5 to-transparent" />
              
              <div className="relative mb-6">
                <div className="w-24 h-24 mx-auto rounded-3xl overflow-hidden border-4 border-white shadow-xl">
                   <img src={selectedHirePro.img} alt="" className="w-full h-full object-cover" />
                </div>
                <div className="absolute -bottom-2 -right-2 bg-secondary text-white p-2 rounded-xl shadow-lg">
                  <Star className="w-4 h-4 fill-white" />
                </div>
              </div>

              <h3 className="text-xl font-bold text-dark mb-1">{selectedHirePro.name}</h3>
              <p className="text-xs font-bold text-secondary uppercase tracking-widest mb-8">{selectedHirePro.spec}</p>

              <div className="space-y-3">
                <button 
                  onClick={() => setIsCalling(true)}
                  className="w-full bg-blue-500 hover:bg-blue-600 text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-3 shadow-lg shadow-blue-500/20 transition-all active:scale-95"
                >
                  <Phone className="w-5 h-5" /> Llamar
                </button>
                <button 
                  onClick={() => setShowWaModal(true)}
                  className="w-full bg-[#25D366] hover:bg-[#20ba5a] text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-3 shadow-lg shadow-[#25D366]/20 transition-all active:scale-95"
                >
                  <MessageSquare className="w-5 h-5 fill-white" /> WhatsApp
                </button>
                <button 
                  onClick={() => setShowEmailModal(true)}
                  className="w-full bg-dark hover:bg-black text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-3 shadow-lg shadow-dark/20 transition-all active:scale-95"
                >
                  <Mail className="w-5 h-5" /> Correo
                </button>
              </div>

              <button 
                onClick={() => setSelectedHirePro(null)}
                className="mt-6 text-sm font-bold text-gray-400 hover:text-dark transition-colors"
              >
                Cancelar
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Modal de Llamada */}
      <AnimatePresence>
        {isCalling && (
          <div className="fixed inset-0 bg-dark/95 z-[300] flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className="text-center text-white space-y-12"
            >
              <div className="relative">
                <div className="w-32 h-32 mx-auto rounded-full overflow-hidden border-4 border-white/20 animate-pulse">
                  <img src={selectedHirePro.img} alt="" className="w-full h-full object-cover" />
                </div>
                <div className="absolute inset-0 border-[6px] border-secondary rounded-full animate-ping opacity-40" />
              </div>
              
              <div>
                <p className="text-sm font-bold text-secondary uppercase tracking-[0.3em] mb-2">Llamando...</p>
                <h4 className="text-3xl font-bold">{selectedHirePro.name}</h4>
              </div>

              <div className="flex flex-col items-center gap-8 pt-12">
                <button 
                  onClick={() => {
                    setIsCalling(false);
                    setSelectedHirePro(null);
                    showToast("✓ Llamada finalizada");
                  }}
                  className="w-20 h-20 bg-red-500 rounded-full flex items-center justify-center shadow-2xl shadow-red-500/40 hover:scale-110 active:scale-90 transition-all"
                >
                  <XCircle className="w-10 h-10" />
                </button>
                <span className="text-xs font-bold text-white/40 uppercase tracking-widest">Colgar</span>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Modal de Email */}
      <AnimatePresence>
        {showEmailModal && (
          <div className="fixed inset-0 bg-dark/60 backdrop-blur-sm z-[300] flex items-center justify-center p-4" onClick={() => setShowEmailModal(false)}>
            <motion.div 
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 50 }}
              className="bg-white w-full max-w-md rounded-[2.5rem] p-8 shadow-2xl relative"
              onClick={e => e.stopPropagation()}
            >
              <h3 className="text-xl font-bold text-dark mb-6 flex items-center gap-3">
                <Mail className="w-6 h-6 text-secondary" /> Nuevo Correo
              </h3>
              
              <div className="space-y-4">
                <div>
                  <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5 block">Para</label>
                  <div className="bg-gray-50 p-3 rounded-xl border border-gray-100 text-sm font-bold text-dark">
                    {selectedHirePro.name.toLowerCase().replace(/ /g, '.')}@contable.mx
                  </div>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5 block">Asunto</label>
                  <div className="bg-gray-50 p-3 rounded-xl border border-gray-100 text-sm font-bold text-dark">
                    Solicitud de factura / Servicios Contables
                  </div>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5 block">Mensaje</label>
                  <textarea 
                    value={emailBody}
                    onChange={(e) => setEmailBody(e.target.value)}
                    rows={5}
                    className="w-full bg-gray-50 border border-secondary/20 rounded-2xl p-4 text-sm font-medium outline-none focus:ring-4 focus:ring-secondary/10 transition-all"
                  />
                </div>
              </div>

              <div className="flex gap-4 mt-8">
                <button 
                  onClick={() => setShowEmailModal(false)}
                  className="flex-1 py-4 text-sm font-bold text-gray-500 hover:text-dark transition-colors"
                >
                  Descartar
                </button>
                <button 
                  onClick={() => {
                    setShowEmailModal(false);
                    setSelectedHirePro(null);
                    showToast("✓ Correo enviado con éxito");
                  }}
                  className="flex-1 py-4 bg-secondary text-white rounded-2xl font-bold shadow-lg shadow-secondary/20 hover:bg-secondary-dark transition-all active:scale-95"
                >
                  Enviar Correo
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Modal de WhatsApp */}
      <AnimatePresence>
        {showWaModal && (
          <div className="fixed inset-0 bg-dark/60 backdrop-blur-sm z-[300] flex items-center justify-center p-4" onClick={() => setShowWaModal(false)}>
            <motion.div 
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 50 }}
              className="bg-white w-full max-w-md rounded-[2.5rem] p-8 shadow-2xl relative"
              onClick={e => e.stopPropagation()}
            >
              <h3 className="text-xl font-bold text-[#25D366] mb-6 flex items-center gap-3">
                <MessageSquare className="w-6 h-6 fill-[#25D366]" /> Chat con {selectedHirePro.name}
              </h3>
              
              <div className="space-y-4">
                <div className="bg-[#e5ddd5] rounded-2xl p-4 relative min-h-[100px]">
                  <div className="bg-white p-3 rounded-xl rounded-tl-none shadow-sm text-sm text-gray-800 max-w-[90%] relative">
                    <div className="absolute -left-2 top-0 w-0 h-0 border-t-[8px] border-t-white border-l-[8px] border-l-transparent"></div>
                    {waMessage}
                    <div className="text-[9px] text-gray-400 text-right mt-1">10:42 AM ✓✓</div>
                  </div>
                </div>
                
                <div>
                  <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5 block">Editar Mensaje</label>
                  <textarea 
                    value={waMessage}
                    onChange={(e) => setWaMessage(e.target.value)}
                    rows={2}
                    className="w-full bg-gray-50 border border-gray-100 rounded-2xl p-4 text-sm font-medium outline-none focus:ring-2 focus:ring-[#25D366]/20 transition-all"
                  />
                </div>
              </div>

              <div className="flex gap-4 mt-8">
                <button 
                  onClick={() => setShowWaModal(false)}
                  className="flex-1 py-4 text-sm font-bold text-gray-500 hover:text-dark transition-colors"
                >
                  Cerrar
                </button>
                <button 
                  onClick={() => {
                    setShowWaModal(false);
                    setSelectedHirePro(null);
                    showToast("✓ Mensaje de WhatsApp enviado");
                  }}
                  className="flex-1 py-4 bg-[#25D366] text-white rounded-2xl font-bold shadow-lg shadow-[#25D366]/20 hover:bg-[#20ba5a] transition-all active:scale-95"
                >
                  Enviar WhatsApp
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function PFPerfil() {
  const { showToast, t } = useAppContext();
  const [photo, setPhoto] = useState<string | null>(null);
  const [formData, setFormData] = useState({ name: 'Juliana Guzmán', email: 'juliana@ejemplo.com' });
  const [isSaving, setIsSaving] = useState(false);
  const [loading, setLoading] = useState(true);

  // Sync with Firestore
  useEffect(() => {
    const fetchProfile = async () => {
      try {
        if (db.app.options.projectId === 'remixed-project-id') {
          throw new Error('Using dummy Firebase config');
        }
        const docRef = doc(db, 'users', 'demo-pf-user');
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const data = docSnap.data();
          setFormData({ name: data.name || 'Juliana Guzmán', email: data.email || 'juliana@ejemplo.com' });
          if (data.photoUrl) setPhoto(data.photoUrl);
        }
      } catch (e: any) {
        if (e.message !== 'Using dummy Firebase config') {
          console.error("Firebase no configurado o error", e);
        }
        // Fallback a localStorage si Firebase tiene placeholder
        const saved = localStorage.getItem('pf_profile');
        if (saved) {
          const parsed = JSON.parse(saved);
          setFormData({ name: parsed.name, email: parsed.email });
          if (parsed.photoUrl) setPhoto(parsed.photoUrl);
        }
      } finally {
        setLoading(false);
      }
    };
    fetchProfile();
  }, []);

  const handlePhotoChange = async (e: ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files?.[0]) return;
    const file = e.target.files[0];
    
    // Optimistic UI update
    const objectUrl = URL.createObjectURL(file);
    setPhoto(objectUrl);
    showToast("Procesando foto de perfil...");

    try {
      if (db.app.options.projectId === 'remixed-project-id') {
        throw new Error('Using dummy Firebase config');
      }
      const imgRef = ref(storage, `users/demo-pf-user/profile_${Date.now()}`);
      const uploadTask = await uploadBytesResumable(imgRef, file);
      const downloadURL = await getDownloadURL(uploadTask.ref);
      setPhoto(downloadURL); // Replace ObjectUrl with remote url
      showToast("✓ Foto subida y guardada en Cloud Storage");
      
      // Save instantly to Firestore
      await setDoc(doc(db, 'users', 'demo-pf-user'), {
        name: formData.name,
        email: formData.email,
        photoUrl: downloadURL
      }, { merge: true });
    } catch (err: any) {
      if (err.message !== 'Using dummy Firebase config') {
        console.error("Error subiendo foto. Revisar config Firebase", err);
      }
      // Fallback a LocalStorage para el DEMO si Firebase falla
      const reader = new FileReader();
      reader.onload = (event) => {
        const base64 = event.target?.result as string;
        setPhoto(base64);
        localStorage.setItem('pf_profile', JSON.stringify({ ...formData, photoUrl: base64 }));
        showToast("✓ Foto guardada localmente (Firebase no configurado)");
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = async (e: FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email) {
      showToast("❌ Por favor completa los campos obligatorios");
      return;
    }
    
    setIsSaving(true);
    try {
      if (db.app.options.projectId === 'remixed-project-id') {
        throw new Error('Using dummy Firebase config');
      }
      await setDoc(doc(db, 'users', 'demo-pf-user'), {
        name: formData.name,
        email: formData.email,
        photoUrl: photo
      }, { merge: true });
      showToast("✓ Perfil actualizado en Cloud Firestore");
    } catch (err: any) {
      if (err.message !== 'Using dummy Firebase config') {
        console.error("Error guardando perfil", err);
      }
      localStorage.setItem('pf_profile', JSON.stringify({ ...formData, photoUrl: photo }));
      showToast("✓ Perfil actualizado localmente (Firebase no configurado)");
    } finally {
      setIsSaving(false);
    }
  };

  if (loading) {
    return <div className="text-center p-12 text-gray-500 font-bold animate-pulse">{t.pf_view.profile.loading}</div>;
  }

  return (
    <div className="max-w-xl mx-auto bg-white rounded-[2.5rem] p-8 shadow-xl border border-gray-100 text-center">
      <h2 className="text-2xl font-bold text-dark mb-4">{t.pf_view.profile.title}</h2>
      
      <div className="relative w-32 h-32 mx-auto mb-8 group overflow-hidden rounded-full border-4 border-white shadow-xl bg-gray-100">
        {photo ? <img src={photo} className="w-full h-full object-cover" /> : <Camera className="w-10 h-10 text-gray-300 m-auto mt-10" />}
        <input 
          type="file" 
          accept="image/*" 
          className="absolute inset-0 opacity-0 cursor-pointer"
          onChange={handlePhotoChange}
        />
        <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
          <UploadCloud className="w-8 h-8 text-white" />
        </div>
      </div>

      <form onSubmit={handleSave} className="space-y-4 text-left">
        <div>
          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest block mb-1">
            {t.pf_view.profile.full_name} <span className="text-red-500">*</span>
          </label>
          <input 
            type="text" 
            required
            value={formData.name} 
            onChange={(e) => setFormData({...formData, name: e.target.value})}
            className="w-full border border-gray-100 rounded-xl p-3.5 bg-gray-50 outline-none focus:border-secondary focus:bg-white transition-all" 
          />
        </div>
        <div>
          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest block mb-1">
            {t.pf_view.profile.email} <span className="text-red-500">*</span>
          </label>
          <input 
            type="email" 
            required
            value={formData.email} 
            onChange={(e) => setFormData({...formData, email: e.target.value})}
            className="w-full border border-gray-100 rounded-xl p-3.5 bg-gray-50 outline-none focus:border-secondary focus:bg-white transition-all" 
          />
        </div>
        <button 
          type="submit" 
          disabled={isSaving}
          className="w-full bg-secondary text-white py-4 rounded-2xl font-bold shadow-lg shadow-secondary/20 transition-all mt-4 active:scale-[0.98] disabled:opacity-50"
        >
          {isSaving ? t.pf_view.profile.saving : t.pf_view.profile.save_btn}
        </button>
      </form>

      <div className="mt-8">
        <AppearanceSettings />
      </div>
    </div>
  );
}
