import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Users, ReceiptText, TrendingUp, AlertCircle, 
  Search, ShieldCheck, Mail, MessageSquare, 
  ChevronRight, Filter, Download, MoreVertical,
  CheckCircle2, Clock, XCircle, ChevronDown
} from 'lucide-react';
import { useAppContext } from '../App';

export default function AdminView() {
  const { currentView } = useAppContext();

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <motion.div
        key={currentView}
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.2 }}
      >
        <AdminDashboard />
      </motion.div>
    </div>
  );
}

function AdminDashboard() {
  const { setProfile, t, showToast } = useAppContext();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [showAllUsers, setShowAllUsers] = useState(false);
  const [selectedStat, setSelectedStat] = useState<any>(null);
  const [showIncomeCharts, setShowIncomeCharts] = useState(false);
  const [announcement, setAnnouncement] = useState<{ title: string; desc: string } | null>(null);

  const handleExport = (type: string) => {
    setAnnouncement({
      title: t.admin_view.actions.improving,
      desc: `${type} ${t.admin_view.actions.export_success}`
    });
    setTimeout(() => setAnnouncement(null), 3000);
  };

  // Dynamic Activity Mapping
  const activityItems = [
    t.admin_view.modals?.activity1 || 'Declaración Anual enviada',
    t.admin_view.modals?.activity2 || '45 CFDI validados hoy',
    t.admin_view.modals?.activity3 || 'Conciliación bancaria en curso'
  ];

  const stats = [
    { id: 'users', label: t.admin_view.stats.active_users, value: '1,284', icon: Users, color: 'text-blue-500', bg: 'bg-blue-50', details: t.admin_view.stats.details?.users || 'Crecimiento de +12% este mes' },
    { id: 'invoices', label: t.admin_view.stats.processed_invoices, value: '45,892', icon: ReceiptText, color: 'text-secondary', bg: 'bg-secondary/10', details: t.admin_view.stats.details?.invoices || '99.9% de precisión en validación SAT' },
    { id: 'revenue', label: t.admin_view.stats.monthly_revenue, value: '$128,400', icon: TrendingUp, color: 'text-emerald-500', bg: 'bg-emerald-50', details: t.admin_view.stats.details?.revenue || 'Comisiones acumuladas de 1,200 contadores' },
    { id: 'review', label: t.admin_view.stats.pending_review, value: '12', icon: AlertCircle, color: 'text-amber-500', bg: 'bg-amber-50', details: t.admin_view.stats.details?.review || 'Tiempo promedio de respuesta: 45 min' },
  ];

  const recentUsers = [
    { id: 1, name: 'Ana García', type: 'Persona Física', status: 'Activo', email: 'ana.g@email.com', joined: `${t.common.times.today}, 10:24 AM`, rfc: 'GARA880101XXX', plan: 'Premium' },
    { id: 2, name: 'Tecno-Mundo SA', type: 'PYME', status: 'Pendiente', email: 'contabilidad@tecno.com', joined: t.common.times.yesterday, rfc: 'TSA220505YYY', plan: 'Empresarial' },
    { id: 3, name: 'Roberto Torres', type: 'Persona Física', status: 'Activo', email: 'roberto.t@email.com', joined: t.common.times.days_ago.replace('{n}', '2'), rfc: 'TORR900101ZZZ', plan: 'Básico' },
    { id: 4, name: 'Consultoría Plus', type: 'PYME', status: 'Inactivo', email: 'info@plus.mx', joined: t.common.times.week_ago, rfc: 'CPLUS101010AAA', plan: 'Personalizado' },
    { id: 5, name: 'C.P. Ana Soto', type: 'Contador Certificado', status: 'Activo', email: 'ana.soto@contadores.mx', joined: t.common.times.month_ago, rfc: 'SOTA850101HHH', plan: 'Pro' },
  ];

  const handleNewAlert = () => {
    showToast(`${t.common?.info || 'ℹ'} ${t.admin_view.actions?.import_info || 'Preparando sistema'}`);
  };

  return (
    <div className="space-y-8">
      {/* Welcome Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-white p-8 rounded-[2rem] shadow-sm border border-gray-100">
        <div>
          <h1 className="text-3xl font-extrabold text-dark flex items-center gap-3">
            {t.admin_view.welcome.title} <ShieldCheck className="w-8 h-8 text-secondary" />
          </h1>
          <p className="text-gray-500 mt-1 font-medium">{t.admin_view.welcome.subtitle}</p>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={() => setProfile(null)}
            className="flex items-center gap-2 px-6 py-3 bg-red-50 hover:bg-red-100 text-red-600 font-extrabold rounded-2xl text-xs transition-all border border-red-100 shadow-sm active:scale-95"
          >
            <XCircle className="w-4 h-4" /> {t.admin_view.actions.exit_admin}
          </button>
          <button 
            onClick={() => handleExport(t.admin_view.actions.export_report)}
            className="flex items-center gap-2 px-4 py-2 bg-gray-50 hover:bg-gray-100 text-dark font-bold rounded-xl text-sm transition-all border border-gray-100 active:scale-95 shadow-sm"
          >
            <Download className="w-4 h-4" /> {t.admin_view.actions.export_report}
          </button>
          <button 
            onClick={handleNewAlert}
            className="px-4 py-2 bg-secondary hover:bg-secondary-dark text-white font-bold rounded-xl text-sm shadow-lg shadow-secondary/20 transition-all active:scale-95"
          >
            {t.admin_view.actions.new_global_alert}
          </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, i) => (
          <button 
            key={i} 
            onClick={() => setSelectedStat(stat)}
            className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 group hover:shadow-md transition-all text-left active:scale-[0.98]"
          >
            <div className={`p-3 w-fit rounded-2xl ${stat.bg} ${stat.color} mb-4`}>
              <stat.icon className="w-6 h-6" />
            </div>
            <div>
              <p className="text-2xl font-black text-dark">{stat.value}</p>
              <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mt-1">{stat.label}</p>
            </div>
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Table Area */}
        <div className="lg:col-span-2 bg-white rounded-[2.5rem] shadow-xl border border-gray-100 overflow-hidden">
          <div className="p-8 border-b border-gray-100 flex flex-col sm:flex-row justify-between gap-4">
            <h3 className="text-xl font-bold text-dark">{t.admin_view.sections.user_management}</h3>
            <div className="flex items-center gap-2 bg-gray-50 border border-gray-100 rounded-2xl px-4 py-2 focus-within:bg-white focus-within:ring-2 focus-within:ring-secondary/20 transition-all">
              <Search className="w-4 h-4 text-gray-400" />
              <input 
                type="text" 
                placeholder={t.admin_view.search_placeholder}
                className="bg-transparent border-none outline-none text-sm w-full font-medium"
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-gray-50/50 text-[10px] font-bold text-gray-400 uppercase tracking-widest border-b border-gray-100">
                  <th className="px-8 py-4">{t.admin_view.table.user}</th>
                  <th className="px-6 py-4">{t.admin_view.table.type}</th>
                  <th className="px-6 py-4">{t.admin_view.table.status}</th>
                  <th className="px-6 py-4">{t.admin_view.table.joined}</th>
                  <th className="px-8 py-4 text-right">{t.admin_view.table.actions}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {recentUsers.map((user) => (
                  <tr key={user.id} className="hover:bg-gray-50/50 transition-colors group">
                    <td className="px-8 py-5">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-2xl bg-secondary/10 flex items-center justify-center text-secondary font-black">
                          {user.name[0]}
                        </div>
                        <div>
                          <p className="font-bold text-dark text-sm">{user.name}</p>
                          <p className="text-[10px] text-gray-400 font-medium">{user.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-5">
                      <span className={`text-[10px] font-black px-2 py-1 rounded-md uppercase tracking-wide ${
                        user.type === 'PYME' ? 'bg-blue-50 text-blue-600' : 
                        user.type === 'Contador Certificado' ? 'bg-emerald-50 text-emerald-600' :
                        'bg-secondary-light text-secondary'
                      }`}>
                        {user.type === 'PYME' ? t.pyme : user.type === 'Contador Certificado' ? t.contador : t.pf}
                      </span>
                    </td>
                    <td className="px-6 py-5">
                      <div className="flex items-center gap-2">
                        {user.status === 'Activo' && <CheckCircle2 className="w-4 h-4 text-secondary" />}
                        {user.status === 'Pendiente' && <Clock className="w-4 h-4 text-amber-500" />}
                        {user.status === 'Inactivo' && <XCircle className="w-4 h-4 text-red-500" />}
                        <span className="text-xs font-bold text-gray-600">
                          {user.status === 'Activo' ? t.pyme_view.providers?.filters?.active || 'Activo' : 
                           user.status === 'Pendiente' ? t.pyme_view.messages.in_review : t.pyme_view.messages.rejected}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-5 text-xs text-gray-400 font-medium">{user.joined}</td>
                    <td className="px-8 py-5 text-right">
                       <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                         <button 
                           onClick={() => setSelectedUser(user)}
                           className="flex items-center gap-2 px-3 py-1.5 bg-secondary text-white rounded-lg text-[10px] font-black hover:bg-secondary-dark transition-all active:scale-95 shadow-sm shadow-secondary/20 uppercase tracking-tighter"
                         >
                           {t.common.view || 'Ver'} {t.nav.activity || 'Actividad'}
                         </button>
                         <button 
                           onClick={() => showToast(`${t.common?.success || '✓'} Sent to ${user.name}`)}
                           className="p-2 hover:bg-white rounded-xl shadow-sm text-gray-400 hover:text-secondary transition-all active:scale-90 border border-gray-100"
                         >
                           <Mail className="w-4 h-4"/>
                         </button>
                         <button 
                           onClick={() => setSelectedUser(user)}
                           className="p-2 hover:bg-white rounded-xl shadow-sm text-gray-400 hover:text-secondary transition-all active:scale-90 border border-gray-100"
                         >
                           <MoreVertical className="w-4 h-4"/>
                         </button>
                       </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="p-6 bg-gray-50/50 border-t border-gray-100 text-center">
             <button 
               onClick={() => setShowAllUsers(true)}
               className="text-xs font-bold text-secondary uppercase tracking-widest hover:underline active:opacity-70 transition-opacity"
             >
               {t.admin_view.actions.view_all_users}
             </button>
          </div>
        </div>

        {/* System Health / Alerts */}
        <div className="space-y-6">
          <div className="bg-white rounded-[2.5rem] p-8 shadow-xl border border-gray-100">
            <h3 className="text-xl font-bold text-dark mb-6">{t.admin_view.sections.system_health}</h3>
            <div className="space-y-5">
               <button 
                 onClick={() => showToast(`${t.admin_view.system.sat_server}: ${t.admin_view.system.stable}`)}
                 className="w-full flex items-center justify-between hover:bg-gray-50 p-2 -m-2 rounded-xl transition-colors text-left"
                >
                 <span className="text-sm font-bold text-gray-600 flex items-center gap-2">
                   <div className="w-2 h-2 bg-secondary rounded-full animate-pulse"></div>
                   {t.admin_view.system.sat_server}
                 </span>
                 <span className="text-xs font-black text-secondary uppercase bg-secondary-light px-3 py-1 rounded-full">{t.admin_view.system.stable}</span>
               </button>
               <button 
                 onClick={() => showToast(`${t.admin_view.system.database}: ${t.admin_view.system.normal}`)}
                 className="w-full flex items-center justify-between hover:bg-gray-50 p-2 -m-2 rounded-xl transition-colors text-left"
               >
                 <span className="text-sm font-bold text-gray-600 flex items-center gap-2">
                   <div className="w-2 h-2 bg-secondary rounded-full"></div>
                   {t.admin_view.system.database}
                 </span>
                 <span className="text-xs font-black text-secondary uppercase bg-secondary-light px-3 py-1 rounded-full">{t.admin_view.system.normal}</span>
               </button>
               <button 
                 onClick={() => showToast(`${t.admin_view.system.gemini_api}: ${t.admin_view.system.latency}`)}
                 className="w-full flex items-center justify-between hover:bg-gray-50 p-2 -m-2 rounded-xl transition-colors text-left"
               >
                 <span className="text-sm font-bold text-gray-600 flex items-center gap-2">
                   <div className="w-2 h-2 bg-amber-500 rounded-full"></div>
                   {t.admin_view.system.gemini_api}
                 </span>
                 <span className="text-xs font-black text-amber-600 uppercase bg-amber-50 px-3 py-1 rounded-full">{t.admin_view.system.latency}</span>
               </button>
            </div>
          </div>

          <div className="bg-gradient-to-br from-secondary to-secondary-dark rounded-[2.5rem] p-8 text-white shadow-2xl shadow-secondary/20 relative overflow-hidden group">
            <TrendingUp className="absolute -bottom-10 -right-10 w-48 h-48 opacity-10 group-hover:scale-110 transition-transform duration-500" />
            <h3 className="text-xl font-bold mb-2 relative z-10">{t.admin_view.metrics.title}</h3>
            <p className="text-xs text-secondary-light mb-6 opacity-80 relative z-10 leading-relaxed font-medium">{t.admin_view.metrics.desc}</p>
            <button 
              onClick={() => setShowIncomeCharts(true)}
              className="w-full bg-white text-secondary py-3 rounded-2xl font-black text-sm shadow-xl hover:bg-gray-50 transition-colors relative z-10 active:scale-95"
            >
              {t.contador_view.actions?.view_income_charts || 'Ver Gráficas de Ingresos'}
            </button>
          </div>
        </div>
      </div>

      {/* Details Modal */}
      <AnimatePresence>
        {selectedStat && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setSelectedStat(null)} className="absolute inset-0 bg-black/40 backdrop-blur-sm" />
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} className="bg-white rounded-[2.5rem] p-8 max-w-sm w-full shadow-2xl relative z-10 border border-gray-100">
               <div className={`p-4 rounded-2xl ${selectedStat.bg} ${selectedStat.color} w-fit mb-6`}>
                 <selectedStat.icon className="w-8 h-8" />
               </div>
               <h4 className="text-xl font-black text-dark mb-1">{selectedStat.label}</h4>
               <p className="text-4xl font-black text-secondary mb-4">{selectedStat.value}</p>
               <p className="text-sm text-gray-500 font-medium leading-relaxed">{selectedStat.details}</p>
               <button onClick={() => setSelectedStat(null)} className="w-full mt-8 py-3 bg-gray-50 hover:bg-gray-100 text-dark font-bold rounded-2xl transition-colors">{t.admin_view.modals?.close || 'Cerrar'}</button>
            </motion.div>
          </div>
        )}

        {selectedUser && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setSelectedUser(null)} className="absolute inset-0 bg-black/40 backdrop-blur-sm" />
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} className="bg-white rounded-[2.5rem] p-8 max-w-md w-full shadow-2xl relative z-10 border border-gray-100">
               <div className="flex items-center gap-4 mb-8">
                 <div className="w-16 h-16 rounded-[2rem] bg-secondary/10 flex items-center justify-center text-secondary font-black text-2xl">
                   {selectedUser.name[0]}
                 </div>
                 <div>
                   <h4 className="text-2xl font-black text-dark">{selectedUser.name}</h4>
                   <p className="text-sm text-gray-400 font-bold uppercase tracking-wider">{selectedUser.type}</p>
                 </div>
               </div>
               <div className="grid grid-cols-2 gap-4 mb-8">
                 <div className="bg-gray-50 p-4 rounded-2xl">
                   <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">RFC</p>
                   <p className="text-sm font-bold text-dark">{selectedUser.rfc}</p>
                 </div>
                 <div className="bg-gray-50 p-4 rounded-2xl">
                   <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">{t.admin_view.modals?.plan || 'PLAN'}</p>
                   <p className="text-sm font-bold text-dark">{selectedUser.plan}</p>
                 </div>
                 <div className="bg-gray-50 p-4 rounded-2xl">
                   <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">{t.admin_view.modals?.joined || 'UNIDO'}</p>
                   <p className="text-sm font-bold text-dark">{selectedUser.joined}</p>
                 </div>
                 <div className="bg-gray-50 p-4 rounded-2xl">
                   <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">{t.admin_view.modals?.state || 'ESTADO'}</p>
                   <p className="text-sm font-bold text-secondary">{selectedUser.status}</p>
                 </div>
               </div>
               <div className="space-y-3">
                 <div className="bg-gray-50 p-4 rounded-2xl mb-2">
                   <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3">{t.admin_view.modals?.activityTitle || 'Actividad de Contador Certificado'}</p>
                   <div className="space-y-2">
                     {activityItems.map((item, idx) => (
                       <div key={idx} className="flex items-center gap-2 text-xs font-bold text-gray-600">
                         {idx < 2 ? <CheckCircle2 className="w-3 h-3 text-secondary" /> : <Clock className="w-3 h-3 text-amber-500" />} {item}
                       </div>
                     ))}
                   </div>
                 </div>
                 <button 
                   onClick={() => showToast(`${t.common?.info || 'ℹ'} ${t.admin_view.actions?.import_info || 'Preparando sistema'}`)}
                   className="w-full py-4 bg-secondary text-white font-black rounded-2xl shadow-xl shadow-secondary/20 hover:bg-secondary-dark transition-all active:scale-95"
                 >
                   {t.admin_view.modals?.historyBtn || 'Ver Historial Completo'}
                 </button>
                 <button onClick={() => setSelectedUser(null)} className="w-full py-3 bg-gray-50 hover:bg-gray-100 text-dark font-bold rounded-2xl transition-colors">{t.admin_view.modals?.back || 'Volver'}</button>
               </div>
            </motion.div>
          </div>
        )}

        {showAllUsers && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setShowAllUsers(false)} className="absolute inset-0 bg-black/40 backdrop-blur-sm" />
            <motion.div initial={{ y: 50, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 50, opacity: 0 }} className="bg-white rounded-[3rem] p-8 max-w-4xl w-full max-h-[80vh] overflow-hidden shadow-2xl relative z-10 border border-gray-100 flex flex-col">
               <div className="flex justify-between items-center mb-6">
                 <h4 className="text-2xl font-black text-dark">{t.admin_view.modals?.userManagementTitle || 'Gestión de Usuarios Completa'}</h4>
                 <button onClick={() => setShowAllUsers(false)} className="p-3 bg-gray-50 rounded-full hover:bg-gray-100 transition-colors"><XCircle className="w-6 h-6 text-gray-400" /></button>
               </div>
               <div className="overflow-y-auto flex-1 pr-2 custom-scrollbar">
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                   {[...recentUsers, ...recentUsers, ...recentUsers].map((u, i) => (
                     <div key={i} className="flex items-center gap-4 p-4 border border-gray-100 rounded-3xl hover:bg-gray-50 transition-colors group">
                       <div className="w-12 h-12 rounded-2xl bg-secondary/10 flex items-center justify-center text-secondary font-black text-lg group-hover:scale-110 transition-transform">
                         {u.name[0]}
                       </div>
                       <div className="flex-1">
                         <p className="font-bold text-dark">{u.name}</p>
                         <div className="flex items-center gap-2 mt-1">
                           <span className="text-[9px] font-black uppercase text-secondary px-2 bg-secondary-light rounded-full">{u.type}</span>
                           <span className="text-xs text-gray-400 font-medium">{u.email}</span>
                         </div>
                       </div>
                       <button onClick={() => { setShowAllUsers(false); setSelectedUser(u); }} className="p-2 hover:bg-white rounded-xl shadow-sm text-gray-400 hover:text-secondary opacity-0 group-hover:opacity-100 transition-opacity"><MoreVertical className="w-4 h-4" /></button>
                     </div>
                   ))}
                 </div>
               </div>
               <div className="mt-8 p-4 bg-gray-50 rounded-2xl flex items-center justify-between">
                 <p className="text-xs font-bold text-gray-500 uppercase tracking-widest">{t.admin_view.modals?.total || 'Total: 1,284 usuarios registrados'}</p>
                 <button 
                   onClick={() => showToast(`${t.common?.success || '✓'} ${t.admin_view.actions?.export_success || 'Exportación exitosa'}`)}
                   className="px-6 py-2 bg-dark text-white font-bold rounded-xl text-xs hover:bg-black transition-colors active:scale-95"
                 >
                   {t.admin_view.table.actions || 'Exportar CSV'}
                 </button>
               </div>
            </motion.div>
          </div>
        )}

        {showIncomeCharts && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setShowIncomeCharts(false)} className="absolute inset-0 bg-black/40 backdrop-blur-sm" />
            <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }} className="bg-white rounded-[3rem] p-8 max-w-4xl w-full shadow-22 relative z-10 border border-gray-100 overflow-hidden">
               <div className="flex justify-between items-center mb-8">
                 <div>
                   <h4 className="text-2xl font-black text-dark">{t.admin_view.metrics.title}</h4>
                   <p className="text-sm text-gray-400 font-medium">{t.admin_view.welcome.subtitle}</p>
                 </div>
                 <button onClick={() => setShowIncomeCharts(false)} className="p-3 bg-gray-100 rounded-full hover:bg-gray-200 transition-colors"><XCircle className="w-6 h-6 text-dark" /></button>
               </div>

               <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                 <div className="p-6 bg-emerald-50 rounded-[2rem] border border-emerald-100">
                    <p className="text-[10px] font-black text-emerald-600 uppercase tracking-widest mb-1">{t.admin_view.stats.monthly_revenue}</p>
                    <p className="text-2xl font-black text-emerald-800">$84,200</p>
                 </div>
                 <div className="p-6 bg-blue-50 rounded-[2rem] border border-blue-100">
                    <p className="text-[10px] font-black text-blue-600 uppercase tracking-widest mb-1">{t.admin_view.stats.active_users}</p>
                    <p className="text-2xl font-black text-blue-800">$32,500</p>
                 </div>
                 <div className="p-6 bg-purple-50 rounded-[2rem] border border-purple-100">
                    <p className="text-[10px] font-black text-purple-600 uppercase tracking-widest mb-1">{t.admin_view.metrics.title}</p>
                    <p className="text-2xl font-black text-purple-800">$2.4M</p>
                 </div>
               </div>

               <div className="bg-gray-50 p-8 rounded-[3rem] border border-gray-100 mb-8 h-64 flex items-end justify-between gap-4">
                  {[45, 60, 40, 75, 90, 65, 85, 95, 70, 80, 55, 88].map((h, i) => (
                    <motion.div 
                      key={i}
                      initial={{ height: 0 }}
                      animate={{ height: `${h}%` }}
                      className={`flex-1 ${h > 80 ? 'bg-secondary' : 'bg-secondary/40'} rounded-t-xl relative group`}
                    >
                      <div className="absolute -top-10 left-1/2 -translate-x-1/2 p-2 bg-dark text-white rounded-lg text-[10px] font-bold opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap shadow-xl">
                        $12,400 mes {i+1}
                      </div>
                    </motion.div>
                  ))}
               </div>

               <p className="text-center text-xs font-bold text-gray-400 uppercase tracking-[0.2em] mb-4">{t.admin_view.modals?.monthlyAccumulated || 'INGRESOS MENSUALES ACUMULADOS 2024'}</p>
               
               <div className="flex gap-4">
                 <button 
                   onClick={() => handleExport(t.admin_view.modals?.exportExcel || 'Excel')}
                   className="flex-1 py-4 bg-dark text-white font-black rounded-2xl hover:bg-black transition-all active:scale-95"
                 >
                   {t.admin_view.modals?.exportExcel || 'Exportar Reporte Excel'}
                 </button>
                 <button 
                   onClick={() => handleExport(t.admin_view.modals?.print || 'Print')}
                   className="flex-1 py-4 bg-gray-100 text-dark font-black rounded-2xl hover:bg-gray-200 transition-all active:scale-95"
                 >
                   {t.admin_view.modals?.print || 'Imprimir'}
                 </button>
               </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Announcement Modal */}
      <AnimatePresence>
        {announcement && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }} 
              exit={{ opacity: 0 }} 
              className="absolute inset-0 bg-black/60 backdrop-blur-md" 
            />
            <motion.div 
              initial={{ scale: 0.8, opacity: 0, y: 20 }} 
              animate={{ scale: 1, opacity: 1, y: 0 }} 
              exit={{ scale: 0.8, opacity: 0, y: 20 }} 
              className="bg-white rounded-[3rem] p-10 max-w-sm w-full shadow-2xl relative z-10 border border-gray-100 text-center"
            >
               <div className="w-20 h-20 bg-secondary/10 text-secondary rounded-[2rem] flex items-center justify-center mx-auto mb-6">
                 <CheckCircle2 className="w-10 h-10" />
               </div>
               <h4 className="text-2xl font-black text-dark mb-2">{announcement.title}</h4>
               <p className="text-gray-500 font-medium leading-relaxed">{announcement.desc}</p>
               <div className="mt-8 flex justify-center">
                 <div className="flex gap-1">
                   {[1,2,3].map(i => (
                     <motion.div 
                       key={i}
                       animate={{ opacity: [0.3, 1, 0.3] }}
                       transition={{ duration: 1, repeat: Infinity, delay: i * 0.2 }}
                       className="w-2 h-2 bg-secondary rounded-full"
                     />
                   ))}
                 </div>
               </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

