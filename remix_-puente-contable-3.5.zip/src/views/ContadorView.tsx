import { useState, ChangeEvent, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import AppearanceSettings from '../components/AppearanceSettings';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, 
  PieChart, Pie, AreaChart, Area
} from 'recharts';
import { 
  Users, DollarSign, Star, CheckCircle2, XCircle, ChevronRight, 
  BriefcaseBusiness, Camera, UploadCloud, TrendingUp, Wallet, 
  ArrowUpRight, UserCheck, Search, Filter, Mail, Phone, Percent,
  Calendar, CreditCard, Activity, PieChart as PieIcon,
  ShieldCheck, AlertCircle, ArrowLeft, MoreVertical, Bell, Compass, MapPin, Download, Info,
  Sparkles, RefreshCw, Zap
} from 'lucide-react';
import { useAppContext } from '../App';
import DemoPaymentModal from '../components/DemoPaymentModal';

const INITIAL_CLIENTS = [
  { 
    id: 1, 
    name: 'Tech Solutions SA', 
    profileType: 'PM', 
    type: 'PYME Digital', 
    email: 'finanzas@techsolutions.mx', 
    service: 'Mensual PYME', 
    statusKey: 'paid', 
    amount: '$1,800', 
    img: 'https://api.dicebear.com/7.x/initials/svg?seed=TS', 
    performance: [40, 50, 60, 45, 70],
    helpNeeded: 'Optimización de esquema de nómina para 15 empleados y estrategia de deducciones de IVA trimestral.',
    monthlyIncome: '$450,000 MXN',
    taxRegime: 'Régimen General de Ley Personas Morales',
    rfc: 'TSO140228K81',
    lastAudit: 'Hace 3 meses'
  },
  { 
    id: 2, 
    name: 'María Hernández', 
    profileType: 'PF', 
    type: 'Ventas por Catálogo', 
    email: 'maria.h@gmail.com', 
    service: 'Anual PF', 
    statusKey: 'paid', 
    amount: '$2,500', 
    img: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Maria', 
    performance: [30, 45, 35, 55, 60],
    helpNeeded: 'Declaración anual extemporánea y recuperación de saldos a favor por gastos hipotecarios y primas de seguros.',
    monthlyIncome: '$32,500 MXN',
    taxRegime: 'Sueldos y Salarios / RESICO',
    rfc: 'HEMM920315R31',
    lastAudit: 'Hace 1 mes'
  },
  { 
    id: 3, 
    name: 'Jorge Ruiz', 
    profileType: 'PF', 
    type: 'Freelance IT', 
    email: 'jorge.it@ruiz.dev', 
    service: 'Consultoría Especial', 
    statusKey: 'pending', 
    amount: '$800', 
    img: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Jorge', 
    performance: [20, 25, 30, 28, 40],
    helpNeeded: 'Regularización de declaraciones provisionales mensuales no presentadas en el ejercicio 2023.',
    monthlyIncome: '$58,000 MXN',
    taxRegime: 'Actividades Profesionales (Honorarios)',
    rfc: 'RUIJ850101M22',
    lastAudit: 'Nunca'
  },
  { 
    id: 4, 
    name: 'Boutique Elena', 
    profileType: 'PM', 
    type: 'Comercio Local', 
    email: 'contacto@elena.mx', 
    service: 'Mensual PYME', 
    statusKey: 'paid', 
    amount: '$1,500', 
    img: 'https://api.dicebear.com/7.x/initials/svg?seed=BE', 
    performance: [50, 40, 60, 70, 65],
    helpNeeded: 'Conciliación de inventarios físicos vs registros contables para cierre fiscal de año.',
    monthlyIncome: '$125,000 MXN',
    taxRegime: 'Régimen Simplificado de Confianza (PM)',
    rfc: 'BEL210512T45',
    lastAudit: 'Hace 6 meses'
  },
];

export default function ContadorView() {
  const { currentView } = useAppContext();
  const [clientes, setClientes] = useState(INITIAL_CLIENTS);

  return (
    <div className="p-4 md:p-8 max-w-7xl mx-auto space-y-6">
      <AnimatePresence mode="wait">
        <motion.div 
          key={currentView}
          initial={{ opacity: 0, y: 15 }} 
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -15 }}
          transition={{ duration: 0.2 }}
        >
          {currentView === 'dashboard' && <ContadorDashboard clientes={clientes} setClientes={setClientes} />}
          {currentView === 'clientes' && <ContadorClientes clientes={clientes} />}
          {currentView === 'comisiones' && <ContadorComisiones />}
          {currentView === 'perfil' && <ContadorPerfil />}
          {currentView === 'directorio' && <ContadorDirectorio />}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

function ContadorDashboard({ clientes, setClientes }: { clientes: any[], setClientes: any }) {
  const { showToast, setCurrentView, t } = useAppContext();
  const [acceptedClient, setAcceptedClient] = useState<any | null>(null);
  const [chartPeriod, setChartPeriod] = useState<'mensual' | 'semanal'>('mensual');
  const [activeOverlay, setActiveOverlay] = useState<'clientes' | 'ingresos' | 'cobros' | 'marketplace' | 'alerts' | 'loyalty' | null>(null);
  const [selectedRequest, setSelectedRequest] = useState<any | null>(null);
  const [loyaltyConfig, setLoyaltyConfig] = useState({ discount: '15%', validity: '30 días' });
  const [isLoyaltyActive, setIsLoyaltyActive] = useState(false);
  
  const incomeDataMensual = [
    { name: 'Ene', real: 12500, espera: 2000 },
    { name: 'Feb', real: 14200, espera: 3500 },
    { name: 'Mar', real: 18400, espera: 4100 },
    { name: 'Abr', real: 16900, espera: 5200 },
  ];

  const incomeDataSemanal = [
    { name: 'Sem 1', real: 4200, espera: 800 },
    { name: 'Sem 2', real: 3800, espera: 1200 },
    { name: 'Sem 3', real: 4900, espera: 1500 },
    { name: 'Sem 4', real: 4000, espera: 1700 },
  ];

  const currentChartData = chartPeriod === 'mensual' ? incomeDataMensual : incomeDataSemanal;

  const [requests, setRequests] = useState([
    { id: 1, name: 'Ricardo Gómez', type: 'Asesoría Anual PF', offer: '$2,500', date: 'Hace 2 horas', img: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop', reason: 'Necesito recuperar saldos a favor de ejercicios anteriores y planeación para 2024.', details: { id: 'PF-992', rfc: 'GOMR850101', status: 'En Trámite', balance: '$0.00' } },
    { id: 2, name: 'Elena Martínez', type: 'Asesoría Mensual PYME', offer: '$1,800/mes', date: 'Ayer', img: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop', reason: 'Busco contador para regularizar la nómina de mi boutique y declaraciones mensuales.', details: { id: 'PY-102', rfc: 'MART920315', status: 'Activa', balance: '$24,500.00' } },
  ]);

  const handleAccept = (req: any) => {
    setRequests(prev => prev.filter(r => r.id !== req.id));
    setAcceptedClient(req);
    
    // Add to clients list
    const newClient = {
      id: Date.now(),
      name: req.name,
      profileType: req.type.includes('PYME') ? 'PM' : 'PF',
      type: req.type,
      email: `${req.name.toLowerCase().replace(' ', '.')}@example.com`,
      service: req.type,
      status: 'Activo',
      amount: req.offer,
      img: req.img,
      performance: [20, 30, 40, 35, 50],
      helpNeeded: req.reason,
      monthlyIncome: '$45,000 MXN',
      taxRegime: req.type.includes('PYME') ? 'Régimen General' : 'Sueldos y Salarios',
      rfc: req.details?.rfc || 'XAXX010101000',
      lastAudit: 'Reciente'
    };
    
    setClientes((prev: any[]) => [newClient, ...prev]);
    showToast(t.contador_view.messages.accepted.replace('{name}', req.name));
  };

  const handleReject = (id: number) => {
    setRequests(prev => prev.filter(r => r.id !== id));
    showToast(t.contador_view.messages.rejected);
  };

  const [sendingReminders, setSendingReminders] = useState(false);
  const handleSendReminders = () => {
    setSendingReminders(true);
    setTimeout(() => {
      setSendingReminders(false);
      showToast(t.contador_view.messages.reminders_sent);
    }, 2000);
  };

  return (
    <div className="space-y-6">
      {/* STATS GRID */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { id: 'clientes', label: t.contador_view.stats.client_portfolio, value: clientes.length.toString(), icon: Users, color: 'text-tertiary', trend: t.contador_view.stats.trends.clients, onClick: () => setActiveOverlay('clientes') },
          { id: 'ingresos', label: t.contador_view.stats.net_income, value: '$18,400', icon: DollarSign, color: 'text-secondary', trend: t.contador_view.stats.trends.income, onClick: () => setActiveOverlay('ingresos') },
          { id: 'cobros', label: t.contador_view.stats.to_collect, value: '$5,200', icon: Wallet, color: 'text-amber-500', trend: t.contador_view.stats.trends.pending, onClick: () => setActiveOverlay('cobros') },
          { id: 'rating', label: t.contador_view.stats.global_rating, value: '4.9', icon: Star, color: 'text-primary', trend: t.contador_view.stats.trends.top, onClick: () => setCurrentView('perfil') }
        ].map((stat, i) => (
          <button 
            key={i} 
            onClick={stat.onClick}
            className="bg-white p-6 rounded-[2rem] shadow-sm border border-gray-100 group hover:shadow-xl hover:scale-[1.02] transition-all text-left w-full"
          >
            <div className={`p-3 w-fit rounded-2xl bg-gray-50 flex items-center justify-center mb-4 group-hover:bg-dark group-hover:text-white transition-colors ${stat.color}`}>
              <stat.icon className="w-5 h-5" />
            </div>
            <p className="text-3xl font-black text-dark tracking-tight leading-none mb-2">{stat.value}</p>
            <p className="text-[10px] text-gray-400 uppercase tracking-widest font-black">{stat.label}</p>
            <div className="flex items-center gap-2 mt-3">
              <p className="text-[10px] text-primary font-bold bg-primary/5 px-2 py-1 rounded-lg w-fit">{stat.trend}</p>
              <ArrowUpRight className="w-3 h-3 text-gray-300 group-hover:text-primary transition-colors" />
            </div>
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* INCOME CHART */}
        <div className="lg:col-span-2 bg-white rounded-[2.5rem] shadow-sm border border-gray-100 overflow-hidden">
          <div className="p-6 border-b border-gray-100 bg-gray-50/50 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h3 className="font-black text-dark text-xs uppercase tracking-widest leading-none mb-1">{t.contador_view.sections.financial_performance}</h3>
              <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">{t.contador_view.sections.real_vs_waiting}</p>
            </div>
            <div className="flex bg-gray-100 p-1 rounded-xl">
              <button 
                onClick={() => setChartPeriod('mensual')}
                className={`px-4 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${chartPeriod === 'mensual' ? 'bg-white text-dark shadow-sm' : 'text-gray-400 hover:text-gray-600'}`}
              >
                {t.contador_view.sections.monthly}
              </button>
              <button 
                onClick={() => setChartPeriod('semanal')}
                className={`px-4 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${chartPeriod === 'semanal' ? 'bg-white text-dark shadow-sm' : 'text-gray-400 hover:text-gray-600'}`}
              >
                {t.contador_view.sections.weekly}
              </button>
            </div>
          </div>
          <div className="p-6 h-[300px]">
            <ResponsiveContainer width="100%" height="100%" minWidth={1} minHeight={1}>
              <BarChart data={currentChartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 10, fontWeight: 900, fill: '#94a3b8'}} />
                <YAxis axisLine={false} tickLine={false} tick={{fontSize: 10, fontWeight: 900, fill: '#94a3b8'}} tickFormatter={(v) => `$${v/1000}k`} />
                <Tooltip 
                  cursor={{fill: '#f8fafc'}}
                  contentStyle={{borderRadius: '1.5rem', border: 'none', boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1)', fontSize: '10px', fontWeight: '900'}}
                />
                <Bar dataKey="real" fill="#10B981" radius={[6, 6, 0, 0]} barSize={32} />
                <Bar dataKey="espera" fill="#F59E0B" radius={[6, 6, 0, 0]} barSize={32} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* MARKETPLACE BENTO BOX */}
        <div className="bg-white rounded-[2.5rem] shadow-sm border border-gray-100 overflow-hidden flex flex-col">
          <div className="p-6 border-b border-gray-100 bg-gray-50/50 flex items-center gap-3">
             <div className="bg-primary/10 p-2 rounded-xl text-primary"><TrendingUp className="w-4 h-4"/></div>
             <h3 className="font-black text-dark text-xs uppercase tracking-widest">{t.contador_view.sections.marketplace}</h3>
          </div>
          
          <div className="p-6 flex-1 relative">
            <AnimatePresence mode="wait">
              {acceptedClient ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  key="accepted"
                  className="bg-dark text-white p-6 rounded-[2rem] h-full flex flex-col justify-between"
                >
                  <div className="flex justify-between items-start">
                    <img src={acceptedClient.img} className="w-16 h-16 rounded-2xl bg-white/10" alt="Avatar" />
                    <button onClick={() => setAcceptedClient(null)} className="text-white/30 hover:text-white"><XCircle className="w-5 h-5"/></button>
                  </div>
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-widest text-primary mb-1">Nuevo Cliente Agregado</p>
                    <h4 className="text-xl font-black mb-4">{acceptedClient.name}</h4>
                    <div className="space-y-2 bg-white/5 p-4 rounded-2xl border border-white/10">
                      <div className="flex justify-between text-xs">
                        <span className="opacity-50">RFC</span>
                        <span className="font-bold">{acceptedClient.details?.rfc || 'SALA950101HJK'}</span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span className="opacity-50">Estado Inicial</span>
                        <span className="font-bold text-secondary">{acceptedClient.details?.status || 'Activo'}</span>
                      </div>
                      <div className="flex justify-between text-xs pt-2 border-t border-white/5">
                        <span className="opacity-50">Balance</span>
                        <span className="font-bold">{acceptedClient.details.balance}</span>
                      </div>
                    </div>
                  </div>
                  <button 
                    onClick={() => setCurrentView('clientes')}
                    className="w-full mt-4 py-3 bg-white text-dark rounded-xl font-black text-xs hover:bg-gray-100 transition-colors"
                  >
                    {t.contador_view.actions.view_all_clients}
                  </button>
                </motion.div>
              ) : requests.length > 0 ? (
                  <div className="space-y-4">
                    {requests.map((sol, i) => (
                      <motion.div 
                        key={sol.id} 
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.1 }}
                        onClick={() => setSelectedRequest(sol)}
                        className="group flex flex-col gap-3 p-4 border border-gray-50 rounded-2xl bg-white hover:shadow-lg transition-all cursor-pointer"
                      >
                        <div className="flex gap-4">
                          <img src={sol.img} className="w-12 h-12 rounded-xl bg-gray-50 object-cover" alt={sol.name} />
                          <div className="flex-1 min-w-0">
                            <h4 className="font-black text-dark text-sm truncate">{sol.name}</h4>
                            <p className="text-[9px] text-gray-400 font-bold uppercase tracking-wider">{sol.type}</p>
                            <p className="text-[10px] text-primary font-black mt-1 leading-none">{sol.offer}</p>
                          </div>
                          <div className="flex gap-2 self-start">
                            <button 
                              onClick={() => handleReject(sol.id)}
                              className="p-2 bg-red-50 text-red-500 hover:bg-red-500 hover:text-white rounded-xl transition-all"
                            >
                              <XCircle className="w-4 h-4" />
                            </button>
                            <button 
                              onClick={() => handleAccept(sol)}
                              className="p-2 bg-primary/5 text-primary hover:bg-primary hover:text-white rounded-xl transition-all"
                            >
                              <UserCheck className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                        <div className="bg-gray-50 p-3 rounded-xl">
                          <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest mb-1">Motivo de consulta</p>
                          <p className="text-[10px] font-bold text-gray-600 line-clamp-2 leading-tight italic">"{sol.reason}"</p>
                        </div>
                      </motion.div>
                    ))}
                    <div className="pt-4 text-center">
                      <p className="text-[10px] text-gray-400 font-black uppercase tracking-[0.15em] mb-4 flex items-center justify-center gap-2">
                        <span className="relative flex h-2 w-2">
                          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                          <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
                        </span>
                        {t.contador_view.messages.prospects_searching || 'Clientes buscando tu perfil ahora'}
                      </p>
                      <button 
                        onClick={() => setActiveOverlay('marketplace')}
                        className="text-primary font-black text-[10px] uppercase tracking-widest hover:underline"
                      >
                        {t.contador_view.sections.see_more_marketplace}
                      </button>
                    </div>
                  </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-full text-center p-4">
                   <div className="bg-gray-50 p-4 rounded-full mb-3"><Bell className="w-8 h-8 text-gray-300" /></div>
                   <p className="font-black text-gray-400 text-xs uppercase tracking-widest">{t.contador_view.messages.no_pending_requests || 'Sin solicitudes pendientes'}</p>
                </div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>

      {/* MODAL DETALLE DE PROSPECTO (MARKETPLACE) */}
      <AnimatePresence>
        {selectedRequest && (
          <div className="fixed inset-0 bg-dark/60 backdrop-blur-xl z-[60] flex items-center justify-center p-4 overflow-y-auto" onClick={() => setSelectedRequest(null)}>
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 30 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 30 }}
              className="bg-white rounded-[3rem] w-full max-w-lg shadow-3xl overflow-hidden relative mt-auto mb-auto"
              onClick={e => e.stopPropagation()}
            >
              <div className="relative h-32 bg-gray-900 overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-tertiary/20 animate-pulse" />
                <button 
                  onClick={() => setSelectedRequest(null)}
                  className="absolute top-6 right-6 p-3 bg-white/20 hover:bg-white/40 text-white rounded-full backdrop-blur-md transition-all z-10"
                >
                  <XCircle className="w-5 h-5" />
                </button>
              </div>

              <div className="px-8 pb-8 -mt-16 relative z-1">
                <div className="flex flex-col items-center text-center">
                  <div className="p-1.5 bg-white rounded-[2rem] shadow-2xl mb-4">
                    <img src={selectedRequest.img} className="w-32 h-32 rounded-[1.8rem] bg-gray-50 object-cover" alt="" />
                  </div>
                  <div className="mb-6">
                    <div className="flex justify-center gap-2 mb-2">
                       <span className="bg-primary/10 text-primary px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest">
                          {selectedRequest.type}
                       </span>
                    </div>
                    <h3 className="text-3xl font-black text-dark tracking-tighter leading-none">{selectedRequest.name}</h3>
                    <p className="text-sm font-bold text-primary mt-2">Oferta Propuesta: {selectedRequest.offer}</p>
                  </div>
                </div>

                <div className="bg-gray-50 p-6 rounded-[2rem] border border-gray-100 mb-8">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="bg-amber-400/20 p-2 rounded-xl text-amber-500"><Info className="w-4 h-4"/></div>
                    <h4 className="font-black text-xs uppercase tracking-widest text-dark">{t.contador_view.sections.consultation_proposal || 'Propuesta de Consulta'}</h4>
                  </div>
                  <p className="text-sm font-bold text-gray-600 leading-relaxed italic">
                    "{selectedRequest.reason}"
                  </p>
                </div>

                <div className="flex gap-4">
                  <button 
                    onClick={() => { handleReject(selectedRequest.id); setSelectedRequest(null); }}
                    className="flex-1 py-4 bg-red-50 text-red-500 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-red-500 hover:text-white transition-all"
                  >
                    {t.common.delete || 'Rechazar'}
                  </button>
                  <button 
                    onClick={() => { handleAccept(selectedRequest); setSelectedRequest(null); }}
                    className="flex-[2] py-4 bg-primary text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-primary-dark transition-all flex items-center justify-center gap-2 shadow-xl shadow-primary/30"
                  >
                    <UserCheck className="w-4 h-4" /> {t.contador_view.sections.accept_proposal || 'Aceptar Propuesta'}
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* OVERLAYS FOR STATS */}
      <AnimatePresence>
        {activeOverlay && (
          <div className="fixed inset-0 bg-dark/40 backdrop-blur-md z-50 flex items-center justify-center p-4" onClick={() => setActiveOverlay(null)}>
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className={`bg-white rounded-[2.5rem] w-full shadow-3xl overflow-hidden ${activeOverlay === 'marketplace' ? 'max-w-4xl' : 'max-w-lg'}`}
              onClick={e => e.stopPropagation()}
            >
              <div className="p-8">
                <div className="flex justify-between items-center mb-8">
                  <div>
                    <h3 className="text-2xl font-black text-dark tracking-tight">
                      {activeOverlay === 'clientes' && t.contador_view.overlays.portfolio_summary}
                      {activeOverlay === 'ingresos' && t.contador_view.overlays.income_dist}
                      {activeOverlay === 'cobros' && t.contador_view.overlays.accounts_receivable}
                      {activeOverlay === 'marketplace' && t.contador_view.overlays.prospect_marketplace}
                      {activeOverlay === 'alerts' && t.contador_view.overlays.critical_alerts}
                    </h3>
                    <p className="text-xs text-gray-400 font-bold uppercase tracking-widest mt-1">{t.contador_view.overlays.interactive_detail}</p>
                  </div>
                  <button onClick={() => setActiveOverlay(null)} className="p-2 hover:bg-gray-100 rounded-full transition-colors"><XCircle className="w-6 h-6 text-gray-300" /></button>
                </div>

                {activeOverlay === 'loyalty' && (
                  <div className="space-y-6">
                    <div className="bg-primary/5 p-6 rounded-[2rem] border border-primary/10">
                      <div className="flex items-center gap-4 mb-4">
                        <div className="p-3 bg-white rounded-2xl shadow-sm text-primary">
                          <Percent className="w-6 h-6" />
                        </div>
                        <div>
                          <h4 className="font-black text-dark tracking-tight">{t.contador_view.overlays.loyalty.title}</h4>
                          <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest leading-none">{t.contador_view.overlays.loyalty.subtitle}</p>
                        </div>
                      </div>
                      <p className="text-xs text-gray-600 font-medium leading-relaxed">
                        {t.contador_view.overlays.loyalty.desc}
                      </p>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-2 block">{t.contador_view.overlays.loyalty.client_benefit}</label>
                        <select 
                          value={loyaltyConfig.discount}
                          onChange={(e) => setLoyaltyConfig({...loyaltyConfig, discount: e.target.value})}
                          className="w-full bg-gray-50 border border-gray-100 rounded-xl p-3 text-xs font-bold outline-none focus:border-primary transition-all"
                        >
                          <option value="10%">10% {t.contador_view.overlays.loyalty.next_month_discount}</option>
                          <option value="15%">15% {t.contador_view.overlays.loyalty.next_month_discount}</option>
                          <option value="20%">20% {t.contador_view.overlays.loyalty.next_month_discount}</option>
                          <option value="Gift Card">Gift Card de $200 MXN</option>
                        </select>
                      </div>
                      <div>
                        <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-2 block">{t.contador_view.overlays.loyalty.validity}</label>
                        <div className="grid grid-cols-3 gap-2">
                          {[`15 ${t.pf_view.days_remaining}`, `30 ${t.pf_view.days_remaining}`, `60 ${t.pf_view.days_remaining}`].map(v => (
                            <button 
                              key={v}
                              onClick={() => setLoyaltyConfig({...loyaltyConfig, validity: v})}
                              className={`py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${loyaltyConfig.validity === v ? 'bg-primary text-white shadow-lg shadow-primary/20' : 'bg-gray-50 text-gray-400 hover:bg-gray-100'}`}
                            >
                              {v}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="p-4 bg-tertiary/5 rounded-2xl flex gap-3 border border-tertiary/10">
                      <div className="text-tertiary"><Info className="w-4 h-4" /></div>
                      <p className="text-[10px] text-gray-500 font-medium leading-tight">
                        {t.contador_view?.loyalty?.info || 'This program increases organic prospecting by '} <span className="text-tertiary font-black">24%</span> {t.contador_view?.loyalty?.info_suffix || ' in accounting firms similar to yours.'}
                      </p>
                    </div>

                    <button 
                      onClick={() => {
                        showToast(`🚀 ¡Campaña de ${loyaltyConfig.discount} activada con éxito!`);
                        setIsLoyaltyActive(true);
                        setActiveOverlay(null);
                      }}
                      className="w-full py-4 bg-primary text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-primary/30 hover:bg-primary-dark transition-all"
                    >
                      {t.contador_view?.loyalty?.activate || 'Activate Campaign Now'}
                    </button>
                  </div>
                )}

                {activeOverlay === 'marketplace' && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-h-[60vh] overflow-y-auto pr-2">
                    {[
                      ...requests,
                      { id: 3, name: 'Sofía Valdés', type: 'Asesoría Extranjera', offer: '$3,200', date: 'Hace 5 horas', img: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&h=150&fit=crop', reason: 'Tengo ingresos del extranjero y no sé cómo declarar el IVA transfronterizo.' },
                      { id: 4, name: 'Marcos Herrera', type: 'Declaración Mensual', offer: '$1,200', date: 'Ayer', img: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&h=150&fit=crop', reason: 'Busco a alguien que lleve mi contabilidad mensual de forma sencilla.' },
                    ].map((req: any) => (
                      <div key={req.id} className="bg-gray-50 p-6 rounded-3xl border border-gray-100 hover:border-primary transition-all group">
                        <div className="flex gap-4 mb-4">
                          <img src={req.img} className="w-16 h-16 rounded-2xl object-cover" alt="" />
                          <div>
                            <h4 className="font-black text-dark tracking-tight">{req.name}</h4>
                            <p className="text-[10px] font-black text-primary uppercase tracking-widest">{req.type}</p>
                            <p className="text-lg font-black text-dark mt-1">{req.offer}</p>
                          </div>
                        </div>
                        <p className="text-xs text-gray-500 font-medium italic mb-6">"{req.reason}"</p>
                        <div className="flex gap-2">
                          <button 
                            onClick={() => { handleReject(req.id); if(requests.length === 0) setActiveOverlay(null); }}
                            className="flex-1 py-3 bg-white border border-red-100 text-red-500 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-red-500 hover:text-white transition-all shadow-sm"
                          >
                            {t.common?.reject || 'Reject'}
                          </button>
                          <button 
                            onClick={() => { handleAccept(req); setActiveOverlay(null); }}
                            className="flex-[2] py-3 bg-primary text-white rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-primary-dark transition-all shadow-lg shadow-primary/20"
                          >
                            {t.common?.accept || 'Accept Client'}
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {activeOverlay === 'alerts' && (
                  <div className="space-y-4">
                    {[
                      { icon: AlertCircle, color: 'text-red-500', bg: 'bg-red-50', client: 'Tech Solutions SA', alert: 'Declaración provisional de IVA pendiente de presentar. Vence mañana.' },
                      { icon: ShieldCheck, color: 'text-amber-500', bg: 'bg-amber-50', client: 'Jorge Ruiz', alert: 'Discrepancia detectada entre CFDI de ingresos y depósitos bancarios.' },
                      { icon: Activity, color: 'text-blue-500', bg: 'bg-blue-50', client: 'Boutique Elena', alert: 'Nuevo aviso en buzón tributario sobre actualización de actividades.' },
                    ].map((alert, i) => (
                      <div key={i} className={`p-4 rounded-2xl border border-gray-100 flex gap-4 ${alert.bg}`}>
                        <div className={`p-3 rounded-xl bg-white h-fit shadow-sm ${alert.color}`}><alert.icon className="w-5 h-5"/></div>
                        <div>
                          <h4 className="font-black text-dark text-sm">{alert.client}</h4>
                          <p className="text-xs font-medium text-gray-600 mt-1">{alert.alert}</p>
                          <button 
                            onClick={() => {
                              showToast(`Atendiendo alerta de ${alert.client}...`);
                              setActiveOverlay(null);
                            }}
                            className="text-[10px] font-black text-primary uppercase tracking-widest mt-3 hover:underline"
                          >
                            Atender ahora
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {activeOverlay === 'ingresos' && (
                  <div className="space-y-8">
                    <div className="h-48 relative">
                      <ResponsiveContainer width="100%" height="100%" minWidth={1} minHeight={1}>
                        <PieChart>
                          <Pie
                            data={[
                              { name: 'Igualas Mensuales', value: 12000 },
                              { name: 'Consultas Únicas', value: 4500 },
                              { name: 'Declaraciones Anuales', value: 1900 },
                            ]}
                            innerRadius={60}
                            outerRadius={80}
                            paddingAngle={5}
                            dataKey="value"
                          >
                            <Cell fill="#10B981" />
                            <Cell fill="#3B82F6" />
                            <Cell fill="#F59E0B" />
                          </Pie>
                        </PieChart>
                      </ResponsiveContainer>
                      <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                        <span className="text-xl font-black text-dark">$18,400</span>
                        <span className="text-[8px] font-black text-gray-400 uppercase tracking-widest">Total Neto</span>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 gap-3">
                      {[
                        { label: 'Igualas Mensuales', value: '$12,000', color: 'bg-secondary' },
                        { label: 'Consultas Únicas', value: '$4,500', color: 'bg-tertiary' },
                        { label: 'Declaraciones Anuales', value: '$1,900', color: 'bg-amber-400' }
                      ].map((item, i) => (
                        <div key={i} className="flex justify-between items-center p-3 bg-gray-50 rounded-xl">
                          <div className="flex items-center gap-3">
                            <div className={`w-3 h-3 rounded-full ${item.color}`} />
                            <span className="text-[10px] font-black uppercase tracking-wider text-gray-600">{item.label}</span>
                          </div>
                          <span className="font-black text-dark text-sm">{item.value}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                    {activeOverlay === 'cobros' && (
                  <div className="space-y-4">
                    {[
                      { name: 'Constructora Atlas', debt: '$2,400', due: t.common.times.overdue_n_days.replace('{n}', '3'), img: 'https://api.dicebear.com/7.x/initials/svg?seed=CA' },
                      { name: 'Dr. Fernando L.', debt: '$1,800', due: t.common.times.due_today, img: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop' },
                      { name: 'Estética Glam', debt: '$1,000', due: t.common.times.due_in_n_days.replace('{n}', '2'), img: 'https://api.dicebear.com/7.x/initials/svg?seed=EG' },
                    ].map((cobro, i) => (
                      <div key={i} className="flex items-center gap-4 p-4 border border-gray-100 rounded-2xl">
                        <img src={cobro.img} className="w-10 h-10 rounded-xl bg-gray-50 object-cover" alt="" />
                        <div className="flex-1">
                          <h4 className="font-black text-dark text-sm">{cobro.name}</h4>
                          <p className="text-[10px] font-bold text-red-500 uppercase">{cobro.due}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-black text-dark">{cobro.debt}</p>
                          <button 
                            onClick={() => showToast(`${t.common.reminders_sent || 'Recordatorio enviado a'} ${cobro.name}`)}
                            className="text-[10px] font-black text-primary uppercase tracking-widest hover:underline"
                          >
                            {t.common.collect || 'Cobrar'}
                          </button>
                        </div>
                      </div>
                    ))}
                    <button 
                      onClick={handleSendReminders}
                      disabled={sendingReminders}
                      className="w-full py-4 mt-4 bg-dark text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-black transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                    >
                      {sendingReminders ? (
                        <>
                          <Activity className="w-4 h-4 animate-spin" /> {t.common.sending || 'Enviando...'}
                        </>
                      ) : (
                        t.contador_view.actions?.send_bulk_reminders || 'Enviar Recordatorios Masivos'
                      )}
                    </button>
                  </div>
                )}

                {activeOverlay === 'clientes' && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4 mb-4">
                       <div className="bg-gray-50 p-4 rounded-2xl text-center">
                          <p className="text-2xl font-black text-dark">9</p>
                          <p className="text-[8px] font-black text-gray-400 uppercase tracking-widest">Pers. Físicas</p>
                       </div>
                       <div className="bg-gray-50 p-4 rounded-2xl text-center">
                          <p className="text-2xl font-black text-dark">5</p>
                          <p className="text-[8px] font-black text-gray-400 uppercase tracking-widest">PyMEs/Corp</p>
                       </div>
                    </div>
                    <button 
                      onClick={() => { setActiveOverlay(null); setCurrentView('clientes'); }}
                      className="w-full py-5 bg-primary text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-primary/30 hover:bg-primary-dark transition-all"
                    >
                      {t.contador_view.actions?.manage_full_portfolio || 'Ir a Gestionar Cartera Completa'}
                    </button>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* DASH BOARD BOTTOM GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white rounded-[2.5rem] shadow-sm border border-gray-100 p-8 flex flex-col md:flex-row items-center gap-8 group">
            <div className="relative w-40 h-40">
              <ResponsiveContainer width="100%" height="100%" minWidth={1} minHeight={1}>
                <PieChart>
                  <Pie
                    data={[
                      { name: 'PF', value: 9, color: '#10B981' },
                      { name: 'PYME', value: 5, color: '#3B82F6' },
                    ]}
                    innerRadius={45}
                    outerRadius={65}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    <Cell fill="#10B981" />
                    <Cell fill="#3B82F6" />
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                <span className="text-2xl font-black text-dark group-hover:scale-110 transition-transform">14</span>
                <span className="text-[8px] font-black text-gray-400 uppercase tracking-widest">{t.contador_view.stats?.clients_label || 'Clientes'}</span>
              </div>
            </div>
            <div className="flex-1 space-y-4">
               <div>
                  <h3 className="font-black text-sm text-dark uppercase tracking-widest mb-1">{t.contador_view.sections.portfolio_composition}</h3>
                  <p className="text-xs text-gray-400 font-medium">{t.contador_view.sections?.portfolio_balance_desc || 'Balance entre personas físicas y PyMEs corporativas.'}</p>
               </div>
               <div className="space-y-2">
                 <div className="flex justify-between items-center text-xs">
                    <div className="flex items-center gap-2"><div className="w-2.5 h-2.5 rounded-full bg-secondary" /> <span className="font-black text-gray-500 uppercase tracking-widest">{t.pf || 'Persona Física'}</span></div>
                    <span className="font-black">64%</span>
                 </div>
                 <div className="flex justify-between items-center text-xs">
                    <div className="flex items-center gap-2"><div className="w-2.5 h-2.5 rounded-full bg-tertiary" /> <span className="font-black text-gray-500 uppercase tracking-widest">{t.pyme || 'Persona Moral'}</span></div>
                    <span className="font-black">36%</span>
                 </div>
               </div>
            </div>
          </div>

          <div className={`${isLoyaltyActive ? 'bg-secondary' : 'bg-primary'} hover:brightness-110 transition-all rounded-[2.5rem] p-8 text-white shadow-2xl shadow-primary/30 flex flex-col justify-between group overflow-hidden relative`}>
            <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:scale-110 transition-transform"><BriefcaseBusiness className="w-40 h-40"/></div>
            <div className="flex justify-between items-start">
              <div>
                <div className="flex items-center gap-2 mb-2">
                   <p className="text-[10px] font-black uppercase tracking-[0.2em] opacity-60">{t.contador_view.loyalty?.badge || 'Siguiente Paso Pro'}</p>
                   <span className="bg-white/20 text-[8px] font-black px-2 py-0.5 rounded-full animate-pulse">
                     {isLoyaltyActive ? (t.common.statuses?.in_progress || 'EN CURSO') : (t.common.statuses?.new || 'NUEVO')}
                   </span>
                </div>
                <h3 className="text-3xl font-black leading-tight max-w-[250px]">{t.contador_view.loyalty?.title || 'Lanza tu Campaña de Fidelidad'}</h3>
                
                {isLoyaltyActive ? (
                  <div className="mt-4 inline-flex flex-col gap-2 bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/20">
                    <p className="text-[10px] font-black uppercase tracking-widest opacity-70">{t.contador_view.loyalty?.active_plan_label || 'Plan Activo:'}</p>
                    <div className="flex items-center gap-3">
                       <div className="bg-white text-secondary p-1.5 rounded-lg">
                          <Percent className="w-4 h-4" />
                       </div>
                       <p className="text-sm font-black">{loyaltyConfig.discount} {t.contador_view.overlays.loyalty.next_month_discount} · {loyaltyConfig.validity}</p>
                    </div>
                  </div>
                ) : (
                  <p className="text-sm font-medium mt-4 opacity-80 max-w-[300px]">{t.contador_view.loyalty?.desc || 'Crea cupones de descuento para tus clientes actuales que te recomienden nuevos prospectos.'}</p>
                )}
              </div>
            </div>
            <button 
              onClick={() => setActiveOverlay('loyalty')}
              className="flex items-center gap-3 bg-white text-dark w-fit px-6 py-3 rounded-2xl font-black text-xs mt-8 shadow-xl hover:scale-105 active:scale-95 transition-all"
            >
              {isLoyaltyActive ? (t.contador_view.actions?.manage_campaign || 'Gestionar Campaña') : (t.contador_view.actions?.setup_campaign || 'Configurar Campaña')} <ArrowUpRight className="w-4 h-4" />
            </button>
          </div>
      </div>
    </div>
  );
}

function ContadorClientes({ clientes }: { clientes: any[] }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedClient, setSelectedClient] = useState<any | null>(null);
  const [activeOverlay, setActiveOverlay] = useState<'alerts' | null>(null);
  const [emailingClient, setEmailingClient] = useState<any | null>(null);
  const { setCurrentView, showToast, t } = useAppContext();

  const filteredClientes = clientes.filter(c => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    c.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <AnimatePresence>
        {emailingClient && (
          <div className="fixed inset-0 bg-dark/60 backdrop-blur-xl z-[70] flex items-center justify-center p-4" onClick={() => setEmailingClient(null)}>
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 30 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 30 }}
              className="bg-white rounded-[3rem] w-full max-w-xl shadow-3xl overflow-hidden"
              onClick={e => e.stopPropagation()}
            >
              <div className="p-8">
                <div className="flex justify-between items-start mb-8">
                  <div className="flex items-center gap-4">
                    <div className="p-3 bg-secondary/10 text-secondary rounded-2xl">
                      <Sparkles className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="text-2xl font-black text-dark tracking-tight">{t.contador_view.actions?.ai_drafting || 'Redacción IA'}</h4>
                      <p className="text-xs text-secondary font-bold uppercase tracking-widest leading-none">{t.common.loading || 'Generando mensaje personalizado...'}</p>
                    </div>
                  </div>
                  <button onClick={() => setEmailingClient(null)} className="p-2 hover:bg-gray-100 rounded-full transition-colors"><XCircle className="w-6 h-6 text-gray-300" /></button>
                </div>

                <div className="space-y-6">
                   <div className="bg-gray-50 p-6 rounded-2xl border border-gray-100 italic text-sm text-gray-600 leading-relaxed">
                      <p className="font-bold text-dark not-italic mb-2">Asunto: {emailingClient.status === 'Pagado' ? 'Seguimiento de tu Estrategia Fiscal' : 'Recordatorio: Pendiente de Pago - ' + emailingClient.name}</p>
                      {emailingClient.status === 'Pagado' ? 
                        `Estimado(a) ${emailingClient.name.split(' ')[0]}, espero que este correo te encuentre muy bien. Te escribo para comentarte que hemos finalizado la conciliación de este mes exitosamente...` :
                        `Hola ${emailingClient.name.split(' ')[0]}, notamos que el pago de tu servicio ${emailingClient.service} está próximo a vencer o se encuentra demorado. Quedo a la espera del comprobante para regularizar tu estatus...`
                      }
                   </div>
                   
                   <div className="flex items-center gap-3 bg-indigo-50 p-4 rounded-xl border border-indigo-100">
                      <Zap className="w-4 h-4 text-indigo-500" />
                      <p className="text-[10px] text-indigo-600 font-bold uppercase tracking-widest">{t.contador_view.messages?.optimized_conversion || 'Optimizado para mejorar tasa de respuesta en un 40%'}</p>
                   </div>

                   <div className="flex gap-4">
                      <button 
                        onClick={() => {
                          showToast(t.contador_view.messages?.email_sent || "📧 Correo enviado con éxito");
                          setEmailingClient(null);
                        }}
                        className="flex-1 py-4 bg-dark text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-black/20 hover:bg-black transition-all"
                      >
                        {t.common.send || 'Enviar Ahora'}
                      </button>
                      <button 
                         onClick={() => showToast(t.common.loading || "Regenerando borradores con IA...")}
                         className="p-4 bg-gray-100 text-dark rounded-2xl hover:bg-gray-200"
                      >
                        <RefreshCw className="w-5 h-5" />
                      </button>
                   </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-black text-dark tracking-tight leading-none mb-1">Cartera Activa</h2>
          <p className="text-xs text-gray-400 font-bold uppercase tracking-widest">Gestión estratégica de tus {clientes.length} cuentas</p>
        </div>
        <div className="flex w-full md:w-auto gap-3">
          <div className="relative flex-1 md:w-64">
             <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
             <input 
               type="text" 
               placeholder={t.common.search_placeholder || 'Buscar cliente...'} 
               value={searchTerm}
               onChange={e => setSearchTerm(e.target.value)}
               className="w-full pl-10 pr-4 py-2 bg-white border border-gray-100 rounded-xl text-sm outline-none focus:border-primary transition-colors font-medium"
             />
          </div>
          <button className="p-2.5 bg-white border border-gray-100 rounded-xl hover:bg-gray-50 transition-colors"><Filter className="w-5 h-5 text-gray-400" /></button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
         <div className="md:col-span-2 bg-white rounded-[2.5rem] shadow-sm border border-gray-100 overflow-hidden">
            <div className="p-6 border-b border-gray-100 bg-gray-50/50">
              <h3 className="font-black text-dark text-xs uppercase tracking-widest">Actividad de Clientes (Últimos 30 días)</h3>
            </div>
            <div className="p-6 h-48">
               <ResponsiveContainer width="100%" height="100%" minWidth={1} minHeight={1}>
                 <AreaChart data={[
                   { name: 'Sem 1', val: 3400 }, { name: 'Sem 2', val: 5600 }, { name: 'Sem 3', val: 4200 }, { name: 'Sem 4', val: 8900 }
                 ]}>
                    <defs>
                      <linearGradient id="colorVal" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#8B5CF6" stopOpacity={0.1}/>
                        <stop offset="95%" stopColor="#8B5CF6" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <Area type="monotone" dataKey="val" stroke="#8B5CF6" fillOpacity={1} fill="url(#colorVal)" strokeWidth={3} />
                 </AreaChart>
               </ResponsiveContainer>
            </div>
         </div>
         <div className="bg-dark text-white rounded-[2.5rem] p-8 flex flex-col justify-between">
            <div>
               <p className="text-[10px] font-black uppercase tracking-widest opacity-50 mb-2">Salud de Cartera</p>
               <h4 className="text-3xl font-black tracking-tight mb-4">92%</h4>
               <p className="text-xs font-medium text-white/70 leading-relaxed">Casi todo tu equipo está al día con sus obligaciones fiscales. Solo se detectó 1 declaración pendiente.</p>
            </div>
            <button 
              onClick={() => setActiveOverlay('alerts')}
              className="w-full py-3 bg-white text-dark rounded-xl font-black text-xs uppercase tracking-widest mt-6 hover:bg-gray-100 transition-colors"
            >
              Ver Alertas
            </button>
         </div>
      </div>

      {/* MODAL DETALLE CLIENTE */}
      <AnimatePresence>
        {activeOverlay === 'alerts' && (
          <div className="fixed inset-0 bg-dark/40 backdrop-blur-md z-[60] flex items-center justify-center p-4" onClick={() => setActiveOverlay(null)}>
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="bg-white rounded-[2.5rem] w-full max-w-lg shadow-3xl overflow-hidden"
              onClick={e => e.stopPropagation()}
            >
              <div className="p-8">
                <div className="flex justify-between items-start mb-8">
                  <div>
                    <h4 className="text-2xl font-black text-dark tracking-tight">{t.contador_view.overlays.critical_alerts}</h4>
                    <p className="text-xs text-gray-400 font-bold uppercase tracking-widest mt-1">{t.contador_view.overlays.interactive_detail}</p>
                  </div>
                  <button onClick={() => setActiveOverlay(null)} className="p-2 hover:bg-gray-100 rounded-full transition-colors"><XCircle className="w-6 h-6 text-gray-300" /></button>
                </div>
                <div className="space-y-4">
                  {[
                    { icon: AlertCircle, color: 'text-red-500', bg: 'bg-red-50', client: 'Tech Solutions SA', alert: 'Declaración provisional de IVA pendiente de presentar. Vence mañana.' },
                    { icon: ShieldCheck, color: 'text-amber-500', bg: 'bg-amber-50', client: 'Jorge Ruiz', alert: 'Discrepancia detectada entre CFDI de ingresos y depósitos bancarios.' },
                  ].map((alert, i) => (
                    <div key={i} className={`p-4 rounded-2xl border border-gray-100 flex gap-4 ${alert.bg}`}>
                      <div className={`p-3 rounded-xl bg-white h-fit shadow-sm ${alert.color}`}><alert.icon className="w-5 h-5"/></div>
                      <div>
                        <h4 className="font-black text-dark text-sm">{alert.client}</h4>
                        <p className="text-xs font-medium text-gray-600 mt-1">{alert.alert}</p>
                        <button 
                          onClick={() => {
                            showToast(`${t.common.loading || 'Atendiendo alerta de'} ${alert.client}...`);
                            setActiveOverlay(null);
                          }}
                          className="text-[10px] font-black text-primary uppercase tracking-widest mt-3 hover:underline"
                        >
                          {t.pyme_view.actions.resolve_now}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {selectedClient && (
          <div className="fixed inset-0 bg-dark/60 backdrop-blur-xl z-50 flex items-center justify-center p-4 overflow-y-auto" onClick={() => setSelectedClient(null)}>
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 30 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 30 }}
              className="bg-white rounded-[3rem] w-full max-w-2xl shadow-3xl overflow-hidden relative mt-auto mb-auto"
              onClick={e => e.stopPropagation()}
            >
              <div className="relative h-40 bg-gradient-to-r from-primary to-tertiary">
                <button 
                  onClick={() => setSelectedClient(null)}
                  className="absolute top-6 right-6 p-3 bg-white/20 hover:bg-white/40 text-white rounded-full backdrop-blur-md transition-all z-10"
                >
                  <XCircle className="w-6 h-6" />
                </button>
              </div>

              <div className="px-8 pb-8 -mt-20 relative z-1">
                <div className="flex flex-col md:flex-row gap-6 items-end mb-8">
                  <div className="p-2 bg-white rounded-[2.5rem] shadow-2xl">
                    <img src={selectedClient.img} className="w-40 h-40 rounded-[2rem] bg-gray-50 object-cover" alt="" />
                  </div>
                  <div className="flex-1 mb-4">
                    <div className="flex items-center gap-2 mb-2">
                       <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${selectedClient.profileType === 'PF' ? 'bg-secondary/10 text-secondary' : 'bg-tertiary/10 text-tertiary'}`}>
                          {selectedClient.profileType === 'PF' ? (t.pf || 'Persona Física') : (t.pyme || 'Persona Moral')}
                       </span>
                       <span className="bg-gray-100 px-3 py-1 rounded-full text-[10px] font-black text-gray-400 uppercase tracking-widest">
                          {selectedClient.taxRegime}
                       </span>
                    </div>
                    <h3 className="text-4xl font-black text-dark tracking-tighter leading-none">{selectedClient.name}</h3>
                    <p className="text-sm font-bold text-gray-500 mt-2">{selectedClient.email} · RFC: {selectedClient.rfc}</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-gray-50 p-6 rounded-[2rem] border border-gray-100">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="bg-primary/20 p-2 rounded-xl text-primary"><Search className="w-4 h-4"/></div>
                      <h4 className="font-black text-xs uppercase tracking-widest text-dark">{t.contador_view.sections.current_service || 'Servicio Actual'}</h4>
                    </div>
                    <p className="text-xl font-black text-dark leading-none">{selectedClient.service}</p>
                    <p className="text-xs font-bold text-gray-400 mt-2">{t.common.amount || 'Costo'}: {selectedClient.amount}</p>
                    <div className="mt-4 pt-4 border-t border-gray-200">
                      <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">{t.common.status_label || 'Estatus del Mes'}</p>
                      <div className="flex justify-between items-center">
                        <span className="font-black text-secondary text-sm">{selectedClient.statusKey === 'paid' ? (t.common.statuses.paid || 'Paid') : (t.common.statuses.pending || 'Pending')}</span>
                        <CheckCircle2 className="w-4 h-4 text-secondary" />
                      </div>
                    </div>
                  </div>

                  <div className="bg-dark text-white p-6 rounded-[2rem] shadow-xl">
                    <div className="flex items-center gap-3 mb-4 text-primary">
                      <DollarSign className="w-5 h-5"/>
                      <h4 className="font-black text-xs uppercase tracking-widest">{t.contador_view.sections.financial_summary || 'Resumen Financiero'}</h4>
                    </div>
                    <div>
                      <p className="text-[10px] font-black uppercase tracking-widest opacity-50 mb-1 leading-none">Ingresos Declarados</p>
                      <p className="text-3xl font-black tracking-tight">{selectedClient.monthlyIncome}</p>
                      <div className="mt-6 flex justify-between items-end border-t border-white/5 pt-4">
                        <div>
                          <p className="text-[10px] font-black uppercase tracking-widest opacity-30 mb-1">Última Auditoría</p>
                          <p className="text-xs font-bold">{selectedClient.lastAudit}</p>
                        </div>
                        <div className="bg-white/10 p-2 rounded-lg"><TrendingUp className="w-4 h-4" /></div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-6 bg-white p-6 rounded-[2rem] border-2 border-gray-50 shadow-inner">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="bg-amber-400/20 p-2 rounded-xl text-amber-500"><Info className="w-4 h-4"/></div>
                    <h4 className="font-black text-xs uppercase tracking-widest text-dark">Contexto de Ayuda / Necesidades</h4>
                  </div>
                  <p className="text-sm font-bold text-gray-600 leading-relaxed italic">
                    "{selectedClient.helpNeeded}"
                  </p>
                </div>

                <div className="mt-8 flex flex-col sm:flex-row gap-4 px-2">
                  <button 
                    onClick={() => showToast(`${t.common?.loading || 'Descargando'}...`)}
                    className="flex-1 py-4 bg-primary text-white rounded-2xl font-black text-[11px] uppercase tracking-widest hover:bg-primary-dark transition-all flex items-center justify-center gap-2 shadow-xl shadow-primary/20 active:scale-95"
                  >
                    <Download className="w-5 h-5" /> {t.common?.download || 'Descargar'}
                  </button>
                  <button 
                    onClick={() => showToast(`${t.common?.loading || 'Abriendo chat'}...`)}
                    className="p-4 bg-gray-100 text-dark rounded-2xl hover:bg-gray-200 transition-all flex items-center justify-center shadow-sm"
                  >
                    <Mail className="w-6 h-6" />
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <div className="bg-white rounded-[3rem] shadow-2xl shadow-gray-200/50 border border-gray-100 overflow-hidden mb-12">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-gray-100 text-[10px] text-gray-400 font-black uppercase tracking-[0.2em] bg-gray-50/30">
                <th className="px-8 py-6">{t.contador_view.table?.identity || 'Identidad'}</th>
                <th className="px-8 py-6 text-center">{t.contador_view.table?.service || 'Servicio / Contrato'}</th>
                <th className="px-8 py-6 text-center">{t.contador_view.table?.activity || 'Actividad'}</th>
                <th className="px-8 py-6 text-center">{t.contador_view.table?.payment_status || 'Estatus Pago'}</th>
                <th className="px-8 py-6 text-right">{t.common.actions || 'Acciones'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {filteredClientes.map((client) => (
                <tr 
                  key={client.id} 
                  onClick={() => setSelectedClient(client)}
                  className="hover:bg-gray-50/80 transition-all group cursor-pointer relative"
                >
                  <td className="px-8 py-8">
                    <div className="flex items-center gap-5">
                       <div className="relative">
                          <img src={client.img} className="w-16 h-16 rounded-[1.5rem] bg-gray-50 shadow-lg border-2 border-white transition-transform group-hover:scale-105 group-hover:rotate-3" alt="" />
                          <div className={`absolute -bottom-1 -right-1 w-5 h-5 rounded-full border-2 border-white ${client.statusKey === 'paid' ? 'bg-secondary' : 'bg-amber-400'} shadow-md`} />
                       </div>
                       <div>
                          <h4 className="font-black text-dark text-base tracking-tight leading-none mb-1.5">{client.name}</h4>
                          <div className="flex items-center gap-2">
                             <span className="text-[10px] text-gray-400 font-black uppercase tracking-widest">
                                {client.profileType === 'PF' ? (t.pf || 'Persona Física') : (t.pyme || 'Persona Moral')}
                             </span>
                             <span className="w-1 h-1 bg-gray-200 rounded-full" />
                             <span className="text-[10px] text-primary font-black uppercase tracking-widest">{client.type}</span>
                          </div>
                          <p className="text-[10px] text-gray-400 font-medium mt-1.5 opacity-60 group-hover:opacity-100 transition-opacity">{client.email}</p>
                       </div>
                    </div>
                  </td>
                  <td className="px-8 py-8">
                    <div className="text-center">
                      <h5 className="font-black text-gray-300 text-[9px] mb-2 uppercase tracking-[0.2em] group-hover:text-dark transition-colors">{client.service}</h5>
                      <p className="text-xl font-black text-dark tracking-tighter leading-none group-hover:scale-110 transition-transform">{client.amount}</p>
                    </div>
                  </td>
                  <td className="px-8 py-8">
                    <div className="flex items-end justify-center gap-1.5 h-10">
                       {client.performance.map((h, idx) => (
                         <motion.div 
                           key={idx} 
                           initial={{ height: 0 }}
                           animate={{ height: `${h}%` }}
                           className={`w-2.5 rounded-full transition-all duration-500 ${client.statusKey === 'paid' ? 'bg-secondary/20 group-hover:bg-secondary/60' : 'bg-amber-400/20 group-hover:bg-amber-400/60'}`} 
                         />
                       ))}
                    </div>
                  </td>
                  <td className="px-8 py-8 text-center">
                    <span className={`inline-flex px-5 py-2 rounded-2xl text-[10px] font-black uppercase tracking-[0.15em] transition-all ${client.statusKey === 'paid' ? 'bg-emerald-50 text-emerald-600 border border-emerald-100 group-hover:bg-emerald-600 group-hover:text-white' : 'bg-amber-50 text-amber-600 border border-amber-100 group-hover:bg-amber-600 group-hover:text-white'}`}>
                      {client.statusKey === 'paid' ? (t.common.statuses.paid || 'Paid') : (t.common.statuses.pending || 'Pending')}
                    </span>
                  </td>
                  <td className="px-8 py-8 text-right">
                    <div className="flex justify-end gap-3 opacity-0 group-hover:opacity-100 transition-all translate-x-4 group-hover:translate-x-0" onClick={e => e.stopPropagation()}>
                       <button 
                         onClick={() => setEmailingClient(client)}
                         className="p-3 bg-dark text-white rounded-2xl hover:bg-secondary hover:shadow-lg hover:shadow-secondary/30 transition-all active:scale-95"
                         title="Enviar Email IA"
                       >
                         <Mail className="w-5 h-5" />
                       </button>
                       <button 
                          className="p-3 bg-white border border-gray-100 text-gray-400 rounded-2xl hover:bg-gray-50 hover:text-dark transition-all"
                       >
                         <MoreVertical className="w-5 h-5" />
                       </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function ContadorComisiones() {
  const { showToast, t } = useAppContext();
  const [showPlans, setShowPlans] = useState(false);
  const [selectedStat, setSelectedStat] = useState<string | null>(null);
  const [paymentConfig, setPaymentConfig] = useState<{isOpen: boolean, plan: string, price: string} | null>(null);

  const statsDetails = {
    [t.contador_view.comisiones.stats.acc_income]: {
      title: t.contador_view.comisiones.details.acc_income.title,
      desc: t.contador_view.comisiones.details.acc_income.desc,
      breakdown: [
        { label: 'Servicios Anuales', value: '$12,500', p: '68%' },
        { label: 'Asesorías Express', value: '$3,400', p: '18%' },
        { label: 'Gestión de Nóminas', value: '$2,500', p: '14%' }
      ]
    },
    [t.contador_view.comisiones.stats.avg_commission]: {
      title: t.contador_view.comisiones.details.avg_commission.title,
      desc: t.contador_view.comisiones.details.avg_commission.desc,
      breakdown: [
        { label: 'Plan Actual', value: '15%', p: 'Base' },
        { label: 'Ahorro Potencial', value: '5%', p: 'Con Plan Pro' }
      ]
    },
    [t.contador_view.comisiones.stats.net_transfer]: {
      title: t.contador_view.comisiones.details.net_transfer.title,
      desc: t.contador_view.comisiones.details.net_transfer.desc,
      breakdown: [
        { label: 'Disponible', value: '$8,400', p: 'Inmediato' },
        { label: 'En Tránsito', value: '$7,240', p: '48h hábiles' }
      ]
    }
  };

  const data = [
    { name: 'Ene', ingresos: 4500, comision: 675 },
    { name: 'Feb', ingresos: 5200, comision: 780 },
    { name: 'Mar', ingresos: 4800, comision: 720 },
    { name: 'Abr', ingresos: 6100, comision: 915 },
    { name: 'May', ingresos: 5800, comision: 870 },
    { name: 'Jun', ingresos: 7200, comision: 1080 },
  ];

  const historial = [
    { id: 1, operacion: 'Servicio Anual - Juan P.', fecha: '12 May, 2024', monto: 2500, comision: 375, status: 'Completado' },
    { id: 2, operacion: 'PYME Mensual - Tech S.', fecha: '10 May, 2024', monto: 1800, comision: 270, status: 'Completado' },
    { id: 3, operacion: 'Asesoría - Maria L.', fecha: '05 May, 2024', monto: 1200, comision: 180, status: 'Pendiente' },
    { id: 4, operacion: 'Nómina - Distribuidora X', fecha: '28 Abr, 2024', monto: 3500, comision: 525, status: 'Completado' },
  ];

  return (
    <div className="space-y-8 pb-20">
      {/* OPTIMIZATION BANNER */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-r from-[#6366f1] to-[#4338ca] p-10 rounded-[3rem] text-white shadow-2xl shadow-indigo-500/20 flex flex-col md:flex-row items-center justify-between gap-8"
      >
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <span className="bg-white/20 backdrop-blur-md px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest flex items-center gap-1.5">
              <TrendingUp className="w-3 h-3" /> {t.contador_view.comisiones.optimization_title}
            </span>
          </div>
          <h3 className="text-4xl font-black tracking-tight leading-none">{t.contador_view.comisiones.optimization_main}</h3>
          <p className="text-white/80 font-medium max-w-md text-lg">{t.contador_view.comisiones.optimization_desc.replace('{amount}', '$920 MXN')}</p>
        </div>
        <button 
          onClick={() => setShowPlans(true)}
          className="bg-white text-[#4338ca] px-10 py-5 rounded-[1.8rem] font-black text-xs uppercase tracking-widest hover:scale-105 transition-transform shadow-xl shadow-black/10 active:scale-95"
        >
          {t.contador_view.comisiones.upgrade_btn}
        </button>
      </motion.div>

      {/* STATS CARDS */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {[
          { label: t.contador_view.comisiones.stats.acc_income, value: '$18,400', color: 'text-dark', icon: <DollarSign className="w-6 h-6"/>, bg: 'bg-indigo-50', iconColor: 'text-indigo-500' },
          { label: t.contador_view.comisiones.stats.avg_commission, value: '15%', color: 'text-primary', icon: <Percent className="w-6 h-6"/>, bg: 'bg-orange-50', iconColor: 'text-orange-500' },
          { label: t.contador_view.comisiones.stats.net_transfer, value: '$15,640', color: 'text-green-500', icon: <Wallet className="w-6 h-6"/>, bg: 'bg-green-50', iconColor: 'text-green-500' }
        ].map((stat, i) => (
          <motion.div 
            key={i}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: i * 0.1 }}
            onClick={() => setSelectedStat(stat.label)}
            className="bg-white p-10 rounded-[3.5rem] border border-gray-100 shadow-sm hover:shadow-xl hover:shadow-gray-200/50 transition-all group cursor-pointer active:scale-95"
          >
            <div className="flex justify-between items-start mb-6">
              <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{stat.label}</span>
              <div className={`${stat.bg} ${stat.iconColor} p-4 rounded-2xl group-hover:scale-110 transition-transform`}>{stat.icon}</div>
            </div>
            <p className={`text-4xl font-black tracking-tight ${stat.color}`}>{stat.value}</p>
          </motion.div>
        ))}
      </div>

      <AnimatePresence>
        {selectedStat && statsDetails[selectedStat] && (
          <div className="fixed inset-0 bg-dark/60 backdrop-blur-xl z-[110] flex items-center justify-center p-4" onClick={() => setSelectedStat(null)}>
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="bg-white rounded-[3.5rem] w-full max-w-lg p-10 shadow-3xl overflow-hidden relative"
              onClick={e => e.stopPropagation()}
            >
              <div className="absolute top-0 right-0 p-8">
                 <button onClick={() => setSelectedStat(null)} className="p-3 bg-gray-50 text-gray-400 rounded-2xl hover:text-dark transition-colors">
                    <XCircle className="w-6 h-6" />
                 </button>
              </div>

              <div className="flex items-center gap-4 mb-8">
                <div className="w-16 h-16 bg-primary/10 text-primary rounded-3xl flex items-center justify-center">
                  {selectedStat === t.contador_view.comisiones.stats.acc_income ? <DollarSign className="w-8 h-8"/> : selectedStat === t.contador_view.comisiones.stats.avg_commission ? <Percent className="w-8 h-8"/> : <Wallet className="w-8 h-8"/>}
                </div>
                <div>
                   <h2 className="text-2xl font-black text-dark tracking-tight">{statsDetails[selectedStat].title}</h2>
                   <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{selectedStat}</p>
                </div>
              </div>

              <p className="text-gray-500 font-medium mb-10 leading-relaxed">{statsDetails[selectedStat].desc}</p>

              <div className="space-y-4">
                 {statsDetails[selectedStat].breakdown.map((item, idx) => (
                   <motion.div 
                     initial={{ x: -20, opacity: 0 }}
                     animate={{ x: 0, opacity: 1 }}
                     transition={{ delay: idx * 0.1 }}
                     key={idx} 
                     className="bg-gray-50 p-6 rounded-3xl flex items-center justify-between border border-transparent hover:border-gray-200 transition-all group"
                   >
                     <div className="flex items-center gap-4">
                        <div className="w-2 h-2 rounded-full bg-primary" />
                        <div>
                          <p className="text-sm font-black text-dark">{item.label}</p>
                          <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{item.p}</p>
                        </div>
                     </div>
                     <p className="text-lg font-black text-dark group-hover:scale-110 transition-transform tabular-nums">{item.value}</p>
                   </motion.div>
                 ))}
              </div>

              <button 
                onClick={() => setSelectedStat(null)}
                className="w-full mt-10 py-5 bg-dark text-white rounded-[2rem] font-black text-xs uppercase tracking-widest hover:bg-black transition-all shadow-xl shadow-black/20"
              >
                {t.contador_view.comisiones.details.close_detail}
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        {/* CHART SECTION */}
        <div className="lg:col-span-2 bg-white p-10 rounded-[3.5rem] border border-gray-100 shadow-sm">
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4 mb-10">
            <div>
              <h3 className="text-2xl font-black text-dark tracking-tight">{t.contador_view.comisiones.chart.title}</h3>
              <p className="text-xs text-gray-400 font-bold uppercase tracking-widest mt-1">{t.contador_view.comisiones.chart.subtitle}</p>
            </div>
            <div className="flex gap-4">
              <span className="flex items-center gap-2 text-[10px] font-black text-gray-400 uppercase tracking-widest">
                <div className="w-3 h-3 rounded-full bg-primary" /> {t.contador_view.comisiones.chart.income}
              </span>
              <span className="flex items-center gap-2 text-[10px] font-black text-gray-400 uppercase tracking-widest">
                <div className="w-3 h-3 rounded-full bg-gray-200" /> {t.contador_view.comisiones.chart.commission}
              </span>
            </div>
          </div>
          <div className="h-[350px] w-full">
            <ResponsiveContainer width="100%" height="100%" minWidth={1} minHeight={1}>
              <BarChart data={data}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 11, fontWeight: 900, fill: '#64748b' }}
                  dy={15}
                />
                <Tooltip 
                  cursor={{ fill: '#f8fafc' }}
                  contentStyle={{ borderRadius: '24px', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)', padding: '20px' }}
                />
                <Bar dataKey="ingresos" fill="#6366f1" radius={[12, 12, 0, 0]} barSize={25} />
                <Bar dataKey="comision" fill="#e2e8f0" radius={[12, 12, 0, 0]} barSize={25} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* RECENT ACTIVITY / DESGLOSES */}
        <div className="bg-white p-10 rounded-[3.5rem] border border-gray-100 shadow-sm flex flex-col">
          <div className="flex justify-between items-center mb-10 border-b border-gray-50 pb-6">
            <div>
              <h3 className="text-2xl font-black text-dark tracking-tight leading-none">{t.contador_view.comisiones.breakdowns.title}</h3>
              <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-2">{t.contador_view.comisiones.breakdowns.subtitle}</p>
            </div>
            <div className="relative group/menu">
              <button 
                onClick={() => showToast("Opciones de exportación avanzadas")}
                className="p-3 hover:bg-gray-50 rounded-2xl transition-colors text-gray-400 hover:text-dark border border-transparent hover:border-gray-100"
              >
                <MoreVertical className="w-5 h-5" />
              </button>
              <div className="absolute right-0 top-full mt-2 w-48 bg-white rounded-2xl shadow-xl border border-gray-100 py-2 opacity-0 invisible group-hover/menu:opacity-100 group-hover/menu:visible transition-all z-10">
                <button onClick={() => showToast("Exportando a Excel...")} className="w-full px-4 py-2 text-left text-[10px] font-black uppercase tracking-widest text-gray-500 hover:bg-gray-50 hover:text-primary flex items-center gap-2">
                  <Download className="w-3.5 h-3.5" /> {t.contador_view.comisiones.breakdowns.export_excel}
                </button>
                <button onClick={() => showToast("Filtrando por mes...")} className="w-full px-4 py-2 text-left text-[10px] font-black uppercase tracking-widest text-gray-500 hover:bg-gray-50 hover:text-primary flex items-center gap-2">
                  <Filter className="w-3.5 h-3.5" /> {t.contador_view.comisiones.breakdowns.filter_month}
                </button>
              </div>
            </div>
          </div>
          
          <div className="space-y-6 flex-1 pr-2 overflow-y-auto custom-scrollbar">
            {historial.map((h, i) => (
              <motion.div 
                key={h.id} 
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.1 }}
                onClick={() => showToast(`Detalles de: ${h.operacion}`)}
                className="flex items-center gap-4 group cursor-pointer p-3 hover:bg-gray-50 rounded-3xl transition-all"
              >
                <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 transition-all group-hover:scale-110 ${h.status === 'Completado' ? 'bg-green-50 text-green-500' : 'bg-orange-50 text-orange-500'}`}>
                  <CreditCard className="w-7 h-7" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-start gap-2">
                    <h4 className="text-sm font-black text-dark tracking-tight truncate">{h.operacion}</h4>
                    <p className="text-sm font-black text-dark tabular-nums">${h.monto}</p>
                  </div>
                  <div className="flex justify-between items-center mt-1">
                    <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">{h.fecha}</p>
                    <p className="text-[10px] text-red-500 font-black">-{h.comision}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
          
          <button 
            onClick={() => showToast("Descargando reporte consolidado del mes...")}
            className="w-full mt-10 py-5 bg-gray-900 text-white rounded-[2rem] font-black text-[11px] uppercase tracking-widest hover:bg-black transition-all flex items-center justify-center gap-3 shadow-xl shadow-black/10 active:scale-95"
          >
            <Download className="w-5 h-5" /> {t.contador_view.comisiones.breakdowns.download_all}
          </button>
        </div>
      </div>

      {showPlans && (
        <div className="fixed inset-0 bg-dark/60 backdrop-blur-xl flex items-center justify-center z-[100] p-4" onClick={() => setShowPlans(false)}>
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-white rounded-[4rem] p-12 w-full max-w-5xl shadow-3xl overflow-y-auto max-h-[90vh]" 
            onClick={e => e.stopPropagation()}
          >
            <div className="text-center mb-12">
               <h2 className="text-4xl font-black mb-2 text-dark tracking-tighter leading-none">{t.contador_view.perfil.plans_modal.title}</h2>
               <p className="text-gray-400 font-medium text-lg">{t.contador_view.perfil.plans_modal.subtitle}</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                { n: t.contador_view.perfil.plans_modal.basic, p: '$499', d: 'Ideal para iniciar', f: ['Comisión del 15%', 'Hasta 10 clientes', 'Visibilidad normal'] },
                { n: t.contador_view.perfil.plans_modal.pro, p: '$999', d: 'El más popular', f: ['Comisión del 10%', 'Clientes ilimitados', 'Perfil destacado en búsquedas'], rec: true },
                { n: t.contador_view.perfil.plans_modal.despacho, p: '$2,499', d: 'Para equipos grandes', f: ['Comisión del 8%', 'Hasta 5 contadores', 'Panel de gestión avanzado'] },
              ].map((pl, i) => (
                <div key={i} className={`p-10 rounded-[3rem] border-2 transition-all flex flex-col ${pl.rec ? 'border-primary shadow-2xl md:scale-105 bg-white z-10' : 'border-gray-50 hover:border-gray-100 bg-white'}`}>
                  {pl.rec && <div className="text-center bg-primary text-white text-[10px] uppercase font-black py-2 mb-6 rounded-full tracking-widest shadow-lg shadow-primary/30">{t.contador_view.perfil.plans_modal.preferred}</div>}
                  <div className="mb-8">
                    <h3 className="text-xl font-black text-dark mb-1">{pl.n}</h3>
                    <p className="text-xs text-gray-400 font-bold uppercase tracking-widest">{pl.d}</p>
                  </div>
                  <p className="text-5xl font-black text-dark mb-8 tabular-nums">{pl.p}<span className="text-sm font-bold text-gray-300 uppercase ml-2">{t.contador_view.perfil.plans_modal.monthly}</span></p>
                  <ul className="space-y-4 mb-10 flex-1">
                    {pl.f.map((feat, j) => (
                      <li key={j} className="flex gap-3 text-sm text-gray-500 font-bold"><CheckCircle2 className="w-5 h-5 text-primary shrink-0"/> {feat}</li>
                    ))}
                  </ul>
                  <button 
                    onClick={() => { setShowPlans(false); setPaymentConfig({ isOpen: true, plan: pl.n, price: pl.p }); }} 
                    className={`w-full py-5 rounded-2xl text-xs font-black uppercase tracking-widest transition-all ${pl.rec ? 'bg-primary text-white hover:bg-primary-dark shadow-xl shadow-primary/20' : 'bg-gray-100 text-dark hover:bg-gray-200'}`}
                  >
                    {t.contador_view.perfil.plans_modal.select}
                  </button>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      )}

      {paymentConfig && (
        <DemoPaymentModal 
          isOpen={paymentConfig.isOpen} 
          onClose={() => setPaymentConfig(null)}
          planName={paymentConfig.plan}
          price={paymentConfig.price}
          colorScheme="primary"
          onSuccess={() => {
            setPaymentConfig(null);
            showToast(`¡Felicidades! Ahora estás en el ${paymentConfig.plan}`);
          }}
        />
      )}
    </div>
  );
}

function ContadorPerfil() {
  const { showToast, t } = useAppContext();
  const [showPlans, setShowPlans] = useState(false);
  const [showEdit, setShowEdit] = useState(false);
  const [paymentConfig, setPaymentConfig] = useState<{isOpen: boolean, plan: string, price: string} | null>(null);
  
  const [currentPlan, setCurrentPlan] = useState({
    name: t.contador_view.perfil.plans_modal.basic,
    commission: '15%',
    limit: '10 clientes',
    nextBill: 'N/A (Gratis)',
    price: '$499'
  });

  const plansData: Record<string, any> = {
    [t.contador_view.perfil.plans_modal.basic]: { commission: '15%', limit: '10 clientes', nextBill: 'N/A (Gratis)', price: '$499' },
    [t.contador_view.perfil.plans_modal.pro]: { commission: '10%', limit: 'Ilimitados', nextBill: 'Próximo mes', price: '$999' },
    [t.contador_view.perfil.plans_modal.despacho]: { commission: '8%', limit: 'Ilimitados (5 contadores)', nextBill: 'Próximo mes', price: '$2,499' }
  };

  // Profile State
  const [profileData, setProfileData] = useState({
    name: 'C.P. Ana Soto',
    bio: 'Contadora Pública con más de 8 años de experiencia en estrategias fiscales para sector tecnológico e inversiones.',
    specialties: ['Fiscal', 'PYME/Startup'],
    state: 'Nuevo León',
    municipality: 'Monterrey',
    photo: null as string | null
  });

  const [editForm, setEditForm] = useState({ ...profileData });

  const handlePhotoUpload = async (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const localUrl = URL.createObjectURL(file);
      // Instant UI update
      setEditForm({...editForm, photo: localUrl});

      // Background compression
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      const img = new Image();
      img.onload = () => {
        const MAX_WIDTH = 500;
        const MAX_HEIGHT = 500;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
        }
        canvas.width = width;
        canvas.height = height;
        ctx?.drawImage(img, 0, 0, width, height);
        
        const base64String = canvas.toDataURL('image/jpeg', 0.8);
        try {
          localStorage.setItem('contadorProfilePhoto', base64String);
        } catch (e) {
          console.warn("Could not save to localStorage", e);
        }
      };
      img.src = localUrl;
    }
  };

  useEffect(() => {
    const savedPhoto = localStorage.getItem('contadorProfilePhoto');
    if (savedPhoto && !profileData.photo) {
      setProfileData(prev => ({...prev, photo: savedPhoto}));
      setEditForm(prev => ({...prev, photo: savedPhoto}));
    }
  }, []);

  const handleSave = () => {
    if (!editForm.photo) {
      alert(t.contador_view.perfil.edit_modal.photo_required);
      return;
    }
    setProfileData(editForm);
    setShowEdit(false);
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <div className="flex flex-col md:flex-row gap-6">
        <div className="flex-1 bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
          <div className="flex items-center gap-4 mb-6 relative">
            <div className="w-16 h-16 bg-gray-100 rounded-2xl overflow-hidden flex items-center justify-center text-gray-400">
              {profileData.photo ? <img src={profileData.photo} className="w-full h-full object-cover" alt="Perfil" /> : <BriefcaseBusiness className="w-8 h-8" />}
            </div>
            <div>
              <h2 className="text-xl font-bold text-dark">{profileData.name}</h2>
              <p className="text-sm font-medium text-gray-500">{t.contador_view.perfil.license}: 1928374</p>
            </div>
            <div className="ml-auto flex items-center gap-1 font-bold text-lg"><Star className="w-5 h-5 fill-amber-400 text-amber-400"/> 4.9</div>
          </div>
          <div className="space-y-4 text-sm">
             <div>
               <p className="text-xs text-gray-400 font-bold uppercase tracking-wide mb-1">{t.contador_view.perfil.specialties}</p>
               <div className="flex gap-2">
                 {profileData.specialties.map((spec, i) => (
                   <span key={i} className="bg-gray-100 px-3 py-1 rounded-md font-medium text-gray-700">{spec}</span>
                 ))}
               </div>
             </div>
             <div>
               <p className="text-xs text-gray-400 font-bold uppercase tracking-wide mb-1">{t.contador_view.perfil.bio_services}</p>
               <p className="text-gray-600 leading-relaxed whitespace-pre-wrap">{profileData.bio}</p>
             </div>
             <div>
               <p className="text-xs text-gray-400 font-bold uppercase tracking-wide mb-1">{t.contador_view.perfil.location_attention}</p>
               <p className="text-gray-600 leading-relaxed">{profileData.municipality}, {profileData.state}</p>
             </div>
             <button
               onClick={() => { setEditForm({...profileData}); setShowEdit(true); }}
               className="mt-4 w-full md:w-auto px-4 py-2 border border-gray-200 text-dark hover:bg-gray-50 rounded-xl font-bold transition-colors"
             >
               {t.contador_view.perfil.edit_profile}
             </button>
          </div>
        </div>

        <div className="w-full md:w-80 bg-white border border-gray-200 text-dark p-6 rounded-2xl shadow-sm relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 opacity-10 text-primary"><Star className="w-24 h-24"/></div>
          <h3 className="font-bold text-lg mb-2 z-10 relative">{t.contador_view.perfil.subscription_plan}</h3>
          <p className="text-primary font-bold text-2xl z-10 relative">{currentPlan.name}</p>
          <div className="mt-6 space-y-2 text-sm text-gray-500 z-10 relative">
            <p>• Comisión del {currentPlan.commission}</p>
            <p>• Máximo {currentPlan.limit}</p>
            <p>• Próximo cobro: {currentPlan.nextBill}</p>
          </div>
          <button 
            onClick={() => setShowPlans(true)}
            className="w-full mt-6 py-2.5 border border-gray-200 text-dark hover:bg-gray-50 rounded-xl font-bold transition-colors z-10 relative"
          >
            {t.contador_view.perfil.change_plan}
          </button>
        </div>
      </div>

      {showEdit && (
        <div className="fixed inset-0 bg-dark/60 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={() => setShowEdit(false)}>
          <div className="bg-white rounded-2xl p-6 w-full max-w-lg shadow-2xl overflow-y-auto max-h-[90vh]" onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold text-dark">{t.contador_view.perfil.edit_modal.title}</h2>
              <button onClick={() => setShowEdit(false)} className="text-gray-400 hover:text-gray-600"><XCircle className="w-6 h-6"/></button>
            </div>
            
            <p className="text-gray-500 text-sm mb-6">
              <span className="font-medium text-primary block">{t.contador_view.perfil.edit_modal.photo_note}</span>
            </p>

            <div className="space-y-4">
              <div className="flex flex-col items-center mb-4">
                <div className="relative group cursor-pointer">
                  <div className="w-24 h-24 rounded-full bg-gray-100 border-4 border-white shadow-md overflow-hidden flex items-center justify-center relative">
                    {editForm.photo ? (
                      <img src={editForm.photo} alt="Perfil" className="w-full h-full object-cover" />
                    ) : (
                      <Camera className="w-8 h-8 text-gray-300" />
                    )}
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <UploadCloud className="w-6 h-6 text-white" />
                    </div>
                    <input 
                      type="file" 
                      accept="image/*" 
                      className="absolute inset-0 opacity-0 cursor-pointer" 
                      onChange={handlePhotoUpload}
                    />
                  </div>
                </div>
                {!editForm.photo && <p className="text-[10px] text-red-500 font-bold mt-2 uppercase">{t.contador_view.perfil.edit_modal.photo_required}</p>}
              </div>

              <div>
                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">{t.contador_view.perfil.edit_modal.public_name}</label>
                <input 
                  type="text" 
                  value={editForm.name} 
                  onChange={e => setEditForm({...editForm, name: e.target.value})}
                  className="w-full border border-gray-200 rounded-xl p-2.5 outline-none focus:border-primary text-sm bg-gray-50 focus:bg-white transition-colors"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">{t.contador_view.perfil.bio_services}</label>
                <textarea 
                  rows={4}
                  value={editForm.bio} 
                  onChange={e => setEditForm({...editForm, bio: e.target.value})}
                  className="w-full border border-gray-200 rounded-xl p-2.5 outline-none focus:border-primary text-sm bg-gray-50 focus:bg-white transition-colors resize-none"
                  placeholder={t.contador_view.perfil.edit_modal.bio_placeholder}
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">{t.contador_view.perfil.edit_modal.state}</label>
                <select 
                  value={editForm.state} 
                  onChange={e => { setEditForm({...editForm, state: e.target.value, municipality: ''}); }}
                  className="w-full border border-gray-200 rounded-xl p-2.5 outline-none focus:border-primary text-sm bg-gray-50 focus:bg-white transition-colors"
                >
                  <option value="">{t.contador_view.perfil.edit_modal.select_state}</option>
                  {Object.keys(MEXICO_LOCATIONS).map(st => <option key={st} value={st}>{st}</option>)}
                </select>
              </div>

              {editForm.state && MEXICO_LOCATIONS[editForm.state] && (
                <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }}>
                  <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">{t.contador_view.perfil.edit_modal.municipality}</label>
                  <select 
                    value={editForm.municipality} 
                    onChange={e => setEditForm({...editForm, municipality: e.target.value})}
                    className="w-full border border-gray-200 rounded-xl p-2.5 outline-none focus:border-primary text-sm bg-gray-50 focus:bg-white transition-colors"
                  >
                    <option value="">{t.contador_view.perfil.edit_modal.select_municipality}</option>
                    {MEXICO_LOCATIONS[editForm.state].map(mun => <option key={mun} value={mun}>{mun}</option>)}
                  </select>
                </motion.div>
              )}

              <button 
                disabled={!editForm.state || !editForm.municipality || !editForm.name || !editForm.bio}
                onClick={handleSave} 
                className="w-full bg-primary disabled:bg-gray-200 disabled:text-gray-400 disabled:cursor-not-allowed hover:bg-primary-dark text-white py-3 mt-4 rounded-xl font-bold shadow-sm transition-all"
              >
                {t.contador_view.perfil.edit_modal.save_changes}
              </button>
            </div>
          </div>
        </div>
      )}

      {showPlans && (
        <div className="fixed inset-0 bg-dark/60 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={() => setShowPlans(false)}>
          <div className="bg-white rounded-3xl p-8 w-full max-w-4xl shadow-2xl overflow-y-auto max-h-[90vh]" onClick={e => e.stopPropagation()}>
            <h2 className="text-xl md:text-2xl font-bold mb-6 text-center text-dark">{t.contador_view.perfil.plans_modal.title}</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[
                { n: t.contador_view.perfil.plans_modal.basic, p: '$499', f: ['Comisión del 15%', 'Hasta 10 clientes', 'Visibilidad normal'] },
                { n: t.contador_view.perfil.plans_modal.pro, p: '$999', f: ['Comisión del 10%', 'Clientes ilimitados', 'Perfil destacado en búsquedas'], rec: true },
                { n: t.contador_view.perfil.plans_modal.despacho, p: '$2,499', f: ['Comisión del 8%', 'Hasta 5 contadores', 'Panel de gestión avanzado'] },
              ].map((pl, i) => (
                <div key={i} className={`p-6 rounded-2xl border-2 transition-all ${pl.rec ? 'border-primary shadow-lg md:scale-105 bg-white z-10' : 'border-gray-100 hover:border-gray-200 bg-white'}`}>
                  {pl.rec && <div className="text-center bg-primary text-white text-[10px] uppercase font-bold py-1 mb-4 rounded-full tracking-widest">{t.contador_view.perfil.plans_modal.recommended}</div>}
                  <h3 className="text-lg font-bold text-dark mb-1">{pl.n}</h3>
                  <p className="text-3xl font-bold font-serif mb-6">{pl.p}<span className="text-sm font-sans text-gray-400 font-medium">{t.contador_view.perfil.plans_modal.monthly}</span></p>
                  <ul className="space-y-3 mb-8">
                    {pl.f.map((feat, j) => (
                      <li key={j} className="flex gap-2 text-sm text-gray-600 font-medium"><CheckCircle2 className="w-4 h-4 text-primary shrink-0"/> {feat}</li>
                    ))}
                  </ul>
                  <button onClick={() => { setShowPlans(false); setPaymentConfig({ isOpen: true, plan: pl.n, price: pl.p }); }} className={`w-full py-2.5 rounded-xl text-sm font-bold transition-colors ${pl.rec ? 'bg-primary text-white hover:bg-primary-dark' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}>
                    {t.contador_view.perfil.plans_modal.contract}
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {paymentConfig && (
        <DemoPaymentModal 
          isOpen={paymentConfig.isOpen} 
          onClose={() => setPaymentConfig(null)}
          planName={paymentConfig.plan}
          price={paymentConfig.price}
          colorScheme="primary"
          onSuccess={() => {
            const newPlanDetails = plansData[paymentConfig.plan];
            if (newPlanDetails) {
              setCurrentPlan({
                name: paymentConfig.plan,
                ...newPlanDetails
              });
            }
            showToast(`¡Felicidades! Ahora estás en el ${paymentConfig.plan}`);
          }}
        />
      )}

      <div className="mt-8">
        <AppearanceSettings />
      </div>
    </div>
  );
}

const MEXICO_LOCATIONS: Record<string, string[]> = {
  'Aguascalientes': ['Aguascalientes', 'Asientos', 'Calvillo', 'Cosío', 'Jesús María', 'Pabellón de Arteaga', 'Rincón de Romos', 'San José de Gracia', 'Tepezalá', 'El Llano', 'San Francisco de los Romo'],
  'Baja California': ['Ensenada', 'Mexicali', 'Tecate', 'Tijuana', 'Playas de Rosarito', 'San Quintín', 'San Felipe'],
  'Baja California Sur': ['Comondú', 'Mulegé', 'La Paz', 'Los Cabos', 'Loreto'],
  'Campeche': ['Campeche', 'Carmen', 'Champotón', 'Hecelchakán', 'Hopelchén', 'Palizada', 'Tenabo', 'Escárcega', 'Calakmul', 'Candelaria', 'Seybaplaya', 'Dzitbalché'],
  'Chiapas': ['Tuxtla Gutiérrez', 'San Cristóbal de las Casas', 'Tapachula', 'Palenque', 'Comitán de Domínguez', 'Chiapa de Corzo', 'Arriaga', 'Tonalá', 'Villaflores'],
  'Chihuahua': ['Chihuahua', 'Juárez', 'Cuauhtémoc', 'Delicias', 'Parral', 'Nuevo Casas Grandes', 'Camargo', 'Jiménez', 'Ojinaga', 'Aldama'],
  'Ciudad de México': ['Álvaro Obregón', 'Azcapotzalco', 'Benito Juárez', 'Coyoacán', 'Cuajimalpa de Morelos', 'Cuauhtémoc', 'Gustavo A. Madero', 'Iztacalco', 'Iztapalapa', 'La Magdalena Contreras', 'Miguel Hidalgo', 'Milpa Alta', 'Tláhuac', 'Tlalpan', 'Venustiano Carranza', 'Xochimilco'],
  'Coahuila': ['Saltillo', 'Torreón', 'Monclova', 'Piedras Negras', 'Acuña', 'Matamoros', 'San Pedro', 'Múzquiz', 'Sabinas', 'Ramos Arizpe'],
  'Colima': ['Colima', 'Manzanillo', 'Tecomán', 'Villa de Álvarez', 'Armería', 'Comala', 'Coquimatlán', 'Cuauhtémoc', 'Ixtlahuacán', 'Minatitlán'],
  'Durango': ['Durango', 'Gómez Palacio', 'Lerdo', 'Pueblo Nuevo', 'Santiago Papasquiaro', 'Guadalupe Victoria', 'Cuencamé', 'Vicente Guerrero'],
  'Estado de México': ['Toluca', 'Ecatepec', 'Naucalpan', 'Tlalnepantla', 'Huixquilucan', 'Metepec', 'Nezahualcóyotl', 'Chimalhuacán', 'Cuautitlán Izcalli', 'Atizapán de Zaragoza', 'Tultitlán', 'Ixtapaluca', 'Tecámac', 'Valle de Chalco'],
  'Guanajuato': ['León', 'Irapuato', 'Celaya', 'Guanajuato', 'San Miguel de Allende', 'Salamanca', 'Silao', 'Valle de Santiago', 'Dolores Hidalgo', 'Pénjamo', 'Acámbaro'],
  'Guerrero': ['Acapulco', 'Chilpancingo', 'Iguala', 'Zihuatanejo', 'Taxco de Alarcón', 'Chilapa de Álvarez', 'Tlapa de Comonfort', 'Ometepec'],
  'Hidalgo': ['Pachuca', 'Tulancingo', 'Tula', 'Mineral de la Reforma', 'Huejutla de Reyes', 'Ixmiquilpan', 'Tepeji del Río', 'Actopan', 'Tizayuca'],
  'Jalisco': ['Guadalajara', 'Zapopan', 'Tlaquepaque', 'Tonalá', 'Puerto Vallarta', 'Tlajomulco de Zúñiga', 'Lagos de Moreno', 'Tepatitlán de Morelos', 'Zapotlán el Grande'],
  'Michoacán': ['Morelia', 'Uruapan', 'Zamora', 'Lázaro Cárdenas', 'Zitácuaro', 'La Piedad', 'Apatzingán', 'Hidalgo', 'Pátzcuaro'],
  'Morelos': ['Cuernavaca', 'Jiutepec', 'Cuautla', 'Temixco', 'Yautepec', 'Emiliano Zapata', 'Xochitepec', 'Jojutla'],
  'Nayarit': ['Tepic', 'Bahía de Banderas', 'Compostela', 'Santiago Ixcuintla', 'Xalisco', 'San Blas', 'Tuxpan', 'Ixtlán del Río'],
  'Nuevo León': ['Monterrey', 'San Pedro Garza García', 'Apodaca', 'San Nicolás', 'Santa Catarina', 'Guadalupe', 'Escobedo', 'Juárez', 'García', 'Cadereyta Jiménez', 'Linares'],
  'Oaxaca': ['Oaxaca de Juárez', 'Salina Cruz', 'San Juan Bautista Tuxtepec', 'Juchitán', 'Santa Cruz Xoxocotlán', 'Huajuapan de León', 'San Pedro Mixtepec', 'Puerto Escondido'],
  'Puebla': ['Puebla', 'Tehuacán', 'San Andrés Cholula', 'San Pedro Cholula', 'Atlixco', 'Amozoc', 'San Martín Texmelucan', 'Huauchinango', 'Teziutlán'],
  'Querétaro': ['Querétaro', 'Corregidora', 'El Marqués', 'San Juan del Río', 'Huimilpan', 'Tequisquiapan', 'Cadereyta de Montes', 'Pedro Escobedo'],
  'Quintana Roo': ['Cancún', 'Playa del Carmen', 'Chetumal', 'Cozumel', 'Tulum', 'Isla Mujeres', 'Puerto Morelos', 'Bacalar', 'Felipe Carrillo Puerto'],
  'San Luis Potosí': ['San Luis Potosí', 'Soledad de Graciano Sánchez', 'Ciudad Valles', 'Matehuala', 'Rioverde', 'Tamazunchale', 'Xilitla'],
  'Sinaloa': ['Culiacán', 'Mazatlán', 'Ahome (Los Mochis)', 'Guasave', 'Navolato', 'Salvador Alvarado (Guamúchil)', 'El Fuerte'],
  'Sonora': ['Hermosillo', 'Cajeme (Ciudad Obregón)', 'Nogales', 'Guaymas', 'Navojoa', 'San Luis Río Colorado', 'Puerto Peñasco', 'Agua Prieta'],
  'Tabasco': ['Centro (Villahermosa)', 'Cárdenas', 'Comalcalco', 'Macuspana', 'Huimanguillo', 'Paraíso', 'Tenosique', 'Teapa'],
  'Tamaulipas': ['Reynosa', 'Matamoros', 'Nuevo Laredo', 'Tampico', 'Ciudad Victoria', 'Ciudad Madero', 'Altamira', 'El Mante', 'Río Bravo'],
  'Tlaxcala': ['Tlaxcala', 'Apizaco', 'Huamantla', 'Chiautempan', 'Zacatelco', 'Calpulalpan', 'Contla de Juan Cuamatzi', 'San Pablo del Monte'],
  'Veracruz': ['Veracruz', 'Xalapa', 'Coatzacoalcos', 'Boca del Río', 'Córdoba', 'Orizaba', 'Poza Rica', 'Minatitlán', 'Tuxpan', 'Martínez de la Torre'],
  'Yucatán': ['Mérida', 'Kanasín', 'Valladolid', 'Progreso', 'Tizimín', 'Umán', 'Tekax', 'Motul', 'Ticul'],
  'Zacatecas': ['Zacatecas', 'Fresnillo', 'Guadalupe', 'Jerez', 'Sombrerete', 'Rio Grande', 'Loreto', 'Calera']
};

function ContadorDirectorio() {
  const { showToast, t } = useAppContext();
  const [searchTerm, setSearchTerm] = useState('');
  const [locationSearch, setLocationSearch] = useState('CDMX');
  const [selectedPro, setSelectedPro] = useState<any | null>(null);
  const [showBooking, setShowBooking] = useState(false);
  const [showMessage, setShowMessage] = useState(false);
  const [showLocationPicker, setShowLocationPicker] = useState(false);
  const [selectedStateForPicker, setSelectedStateForPicker] = useState<string | null>(null);
  const [locationSearchInput, setLocationSearchInput] = useState('');
  const [bookingStep, setBookingStep] = useState(1);
  const [selectedDay, setSelectedDay] = useState<number | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [messageSent, setMessageSent] = useState(false);
  const [messageText, setMessageText] = useState('');

  const pros = [
    { 
      id: 1, 
      name: 'C.P. Carlos Mendoza', 
      title: 'FISCAL / PERSONAS FÍSICAS', 
      specialty: 'Personas Físicas', 
      rating: 4.9, 
      reviews: 120, 
      img: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400&h=400&fit=crop', 
      bio: 'Estratega fiscal con 10 años de experiencia ayudando a contribuyentes individuales a optimizar su SAT.',
      location: '0.5 km',
      fullLocation: 'Polanco, CDMX',
      price: '$1,200',
      services: ['Estrategia Fiscal', 'Declaraciones', 'RESICO']
    },
    { 
      id: 2, 
      name: 'Mtra. Elena Pozos', 
      title: 'ASESORÍA INTEGRAL', 
      specialty: 'Integral', 
      rating: 4.7, 
      reviews: 120, 
      img: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop', 
      bio: 'Consultoría completa para emprendedores y empresas en crecimiento. Visión 360 de tu negocio.',
      location: '1.2 km',
      fullLocation: 'Santa Fe, CDMX',
      price: '$1,500',
      services: ['Contabilidad General', 'Nómina', 'Impuestos']
    },
    { 
      id: 3, 
      name: 'C.P.C. Laura Vega', 
      title: 'AUDITORÍA / PYMES', 
      specialty: 'Auditoría', 
      rating: 4.8, 
      reviews: 120, 
      img: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400&h=400&fit=crop', 
      bio: 'Certificada en procesos de auditoría y revisión de cumplimiento para pequeñas y medianas empresas.',
      location: '2.1 km',
      fullLocation: 'Roma Norte, CDMX',
      price: '$2,500',
      services: ['Auditoría Externa', 'Dictámenes', 'Gestión PyME']
    },
    { 
      id: 4, 
      name: 'Lic. Pedro Salazar', 
      title: 'DEFENSA SAT', 
      specialty: 'Legal', 
      rating: 4.6, 
      reviews: 120, 
      img: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop', 
      bio: 'Representación legal y defensa ante actos de autoridad. Experto en resoluciones administrativas.',
      location: '3.5 km',
      fullLocation: 'Del Valle, CDMX',
      price: 'Bajo Cotización',
      services: ['Defensa Fiscal', 'Recursos de Revocación', 'Amparos']
    },
    { 
      id: 5, 
      name: 'Mtro. Roberto Ruiz', 
      title: 'ESTRATEGIA FISCAL LUXURY', 
      specialty: 'Patrimonial', 
      rating: 5.0, 
      reviews: 80, 
      img: 'https://images.unsplash.com/photo-1542909168-82c3e7fdca5c?w=400&h=400&fit=crop', 
      bio: 'Especialista en gestión de grandes fortunas y blindaje patrimonial internacional.',
      location: '4.2 km',
      fullLocation: 'Lomas de Chapultepec, CDMX',
      price: '$5,000',
      services: ['Gestión de Patrimonio', 'Inversiones', 'Fiscal Internacional']
    },
    { 
      id: 6, 
      name: 'C.P. Ana Beltrán', 
      title: 'DECLARACIONES EXTRANJEROS', 
      specialty: 'Internacional', 
      rating: 4.9, 
      reviews: 150, 
      img: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&h=400&fit=crop', 
      bio: 'Experta en tratados para evitar la doble tributación y declaraciones complejas para residentes en el extranjero.',
      location: '5.1 km',
      fullLocation: 'Juárez, CDMX',
      price: '$2,000',
      services: ['Tratados Internacionales', 'IVA Transfronterizo', 'Expats']
    }
  ];

  const filteredPros = pros.filter(p => 
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    p.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleBook = () => {
    setBookingStep(3);
    setTimeout(() => { showToast(t.contador_view.directorio?.booking?.success_title || '¡Cita solicitada!'); }, 500);
  };

  const handleSendMessage = () => {
    setMessageSent(true);
    setTimeout(() => { showToast(t.contador_view.directorio?.message_modal?.success_title || 'Mensaje enviado'); }, 500);
  };

  const closeModals = () => {
    setSelectedPro(null);
    setShowBooking(false);
    setShowMessage(false);
    setShowLocationPicker(false);
    setSelectedStateForPicker(null);
    setLocationSearchInput('');
    setBookingStep(1);
    setSelectedDay(null);
    setSelectedTime(null);
    setMessageSent(false);
    setMessageText('');
  };

  return (
    <div className="space-y-6 pb-20">
      {/* ALERT BAR */}
      <div className="flex justify-end">
        <div className="bg-amber-50 border border-amber-100 px-6 py-3 rounded-full flex items-center gap-3 shadow-sm">
          <Calendar className="w-5 h-5 text-amber-600" />
          <p className="text-xs font-bold text-amber-800">
            {t.contador_view.directorio?.alert || '📅 Día 25 - ¿Tienes cita médica programada este mes?'}
          </p>
        </div>
      </div>

      {/* LOCATION BANNER */}
      <div className="bg-white p-8 rounded-[2.5rem] border border-gray-50 flex flex-col md:flex-row items-center justify-between gap-6 shadow-sm">
        <div className="flex items-center gap-6 text-center md:text-left">
          <div className="bg-[#ecfdf5] p-5 rounded-3xl text-[#10b981]">
            <MapPin className="w-8 h-8" />
          </div>
          <div>
            <h3 className="text-2xl font-black text-[#111827] tracking-tight">{t.contador_view.directorio?.title ? t.contador_view.directorio.title.replace('{location}', locationSearch) : `Contadores en ${locationSearch}`}</h3>
            <p className="text-gray-400 font-medium">{t.contador_view.directorio?.subtitle || 'Encuentra al experto ideal para tu situación fiscal'}</p>
          </div>
        </div>
        <button 
          onClick={() => setShowLocationPicker(true)}
          className="px-8 py-4 bg-[#10b981] text-white rounded-[1.3rem] font-black text-xs uppercase tracking-widest flex items-center gap-3 hover:bg-[#059669] transition-all shadow-lg shadow-emerald-500/20"
        >
          {t.contador_view.directorio?.change_location || '📍 Cambiar Ubicación'}
        </button>
      </div>

      {/* PRO CARDS GRID (HORIZONTAL) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredPros.map((pro, i) => (
          <motion.div 
            key={pro.id}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="group bg-white rounded-[2.5rem] border border-gray-100 p-6 flex flex-col sm:flex-row gap-6 hover:shadow-2xl hover:shadow-gray-200/50 transition-all cursor-default"
          >
            {/* Foto con Estado */}
            <div className="relative flex-shrink-0">
               <img src={pro.img} className="w-32 h-32 rounded-3xl object-cover" alt="" />
               <div className="absolute bottom-1 right-1 w-5 h-5 bg-green-500 border-4 border-white rounded-full shadow-sm" />
            </div>

            {/* Info Principal */}
            <div className="flex-1 space-y-3">
               <div>
                 <h4 className="text-xl font-black text-dark tracking-tight leading-none">{pro.name}</h4>
                 <p className="text-[10px] font-black text-primary uppercase tracking-widest mt-2">{pro.title}</p>
               </div>
               
               <div className="flex flex-wrap items-center gap-4 text-[11px] font-black text-gray-400">
                  <div className="flex items-center gap-1">
                    <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" /> {pro.rating}
                  </div>
                  <div className="flex items-center gap-1 uppercase tracking-widest text-gray-300">
                    <UserCheck className="w-3.5 h-3.5" /> {pro.reviews}+ {t.common?.clients || 'Clientes'}
                  </div>
               </div>

               <div className="flex items-center gap-2 pt-1">
                  <div className="bg-gray-100 p-1.5 rounded-full"><Compass className="w-3 h-3 text-gray-400" /></div>
                  <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{pro.location}</span>
               </div>
            </div>

            {/* Botones de Acción */}
            <div className="flex flex-row sm:flex-col gap-2 justify-center pt-2 sm:pt-0 sm:min-w-[140px] border-t sm:border-t-0 sm:border-l border-gray-50 sm:pl-6">
                <button 
                  onClick={() => { setSelectedPro(pro); setShowBooking(true); }}
                  className="flex-1 py-4 bg-[#10b981] text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-[#059669] transition-all shadow-lg shadow-emerald-500/20"
                >
                  {t.contador_view.directorio?.hire || 'Contratar'}
                </button>
                <button 
                  onClick={() => setSelectedPro(pro)}
                  className="flex-1 py-4 bg-gray-50 text-dark rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-gray-100 transition-all"
                >
                  {t.contador_view.directorio?.profile || 'Perfil'}
                </button>
            </div>
          </motion.div>
        ))}
      </div>

      {/* MODALS REUTILIZADOS */}
      <AnimatePresence>
        {/* LOCATION PICKER MODAL */}
        {showLocationPicker && (
          <div className="fixed inset-0 bg-dark/60 backdrop-blur-xl z-[90] flex items-center justify-center p-4" onClick={closeModals}>
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="bg-white rounded-[3rem] w-full max-w-xl p-10 shadow-3xl max-h-[85vh] overflow-hidden flex flex-col"
              onClick={e => e.stopPropagation()}
            >
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-3xl font-black text-dark">
                  {selectedStateForPicker ? (t.contador_view.directorio?.location_modal?.municipality_title || 'Seleccionar Municipio') : (t.contador_view.directorio?.location_modal?.state_title || 'Seleccionar Estado')}
                </h3>
                {selectedStateForPicker && (
                  <button 
                    onClick={() => setSelectedStateForPicker(null)}
                    className="flex items-center gap-2 text-primary font-black text-xs uppercase tracking-widest bg-primary/10 px-4 py-2 rounded-xl"
                  >
                    <ArrowLeft className="w-4 h-4" /> {t.contador_view.directorio?.location_modal?.back_states || 'Volver a Estados'}
                  </button>
                )}
              </div>

              <div className="relative mb-6">
                <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input 
                  type="text"
                  placeholder={selectedStateForPicker ? `${t.contador_view.directorio?.location_modal?.search_municipality?.split(' ')[0] || 'Buscar en'} ${selectedStateForPicker}...` : (t.contador_view.directorio?.location_modal?.search_state || 'Buscar estado...')}
                  value={locationSearchInput}
                  onChange={(e) => setLocationSearchInput(e.target.value)}
                  className="w-full bg-gray-50 border-none rounded-[1.5rem] py-5 pl-14 pr-6 text-sm font-bold focus:ring-2 focus:ring-primary/20 outline-none transition-all shadow-inner"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 overflow-y-auto pr-2 custom-scrollbar flex-1 pb-4">
                {!selectedStateForPicker ? (
                  // STATE SELECTION
                  Object.keys(MEXICO_LOCATIONS)
                    .filter(st => st.toLowerCase().includes(locationSearchInput.toLowerCase()))
                    .map((state) => (
                      <button 
                        key={state}
                        onClick={() => {
                          setSelectedStateForPicker(state);
                          setLocationSearchInput('');
                        }}
                        className={`p-5 rounded-2xl font-black text-sm uppercase tracking-widest flex items-center justify-between transition-all group ${locationSearch.split(',').pop()?.trim() === state ? 'bg-primary text-white shadow-lg shadow-primary/20' : 'bg-gray-50 text-dark/70 hover:bg-gray-100 hover:text-dark'}`}
                      >
                        <span className="truncate">{state}</span>
                        <ChevronRight className={`w-5 h-5 transition-transform group-hover:translate-x-1 ${locationSearch.split(',').pop()?.trim() === state ? 'text-white' : 'text-gray-300'}`} />
                      </button>
                    ))
                ) : (
                  // MUNICIPALITY SELECTION
                  MEXICO_LOCATIONS[selectedStateForPicker]
                    .filter(mun => mun.toLowerCase().includes(locationSearchInput.toLowerCase()))
                    .map((mun) => (
                      <button 
                        key={mun}
                        onClick={() => { 
                          setLocationSearch(`${mun}, ${selectedStateForPicker}`); 
                          closeModals(); 
                        }}
                        className={`p-5 rounded-2xl font-black text-sm uppercase tracking-widest flex items-center justify-between transition-all ${locationSearch === `${mun}, ${selectedStateForPicker}` ? 'bg-primary text-white shadow-lg shadow-primary/20' : 'bg-gray-50 text-dark/70 hover:bg-gray-100 hover:text-dark'}`}
                      >
                        <span className="truncate">{mun}</span>
                        {locationSearch === `${mun}, ${selectedStateForPicker}` && <ShieldCheck className="w-5 h-5 text-white" />}
                      </button>
                    ))
                )}
              </div>
            </motion.div>
          </div>
        )}

        {selectedPro && !showBooking && !showMessage && (
          <div className="fixed inset-0 bg-dark/60 backdrop-blur-xl z-[70] flex items-center justify-center p-4 overflow-y-auto" onClick={closeModals}>
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 30 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 30 }}
              className="bg-white rounded-[4rem] w-full max-w-4xl shadow-3xl overflow-hidden relative"
              onClick={e => e.stopPropagation()}
            >
              <div className="flex flex-col md:flex-row h-full">
                <div className="md:w-5/12 h-64 md:h-auto relative">
                   <img src={selectedPro.img} className="w-full h-full object-cover" alt="" />
                   <button onClick={closeModals} className="absolute top-6 left-6 p-2.5 bg-white/20 backdrop-blur-md text-white rounded-full md:hidden">
                    <XCircle className="w-6 h-6" />
                   </button>
                </div>
                <div className="md:w-7/12 p-8 md:p-12 relative overflow-y-auto">
                                       <div className="mb-8">
                     <div className="flex items-center gap-3 mb-3">
                       <span className="bg-primary/10 text-primary px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest">{selectedPro.specialty}</span>
                       <div className="flex items-center gap-1 font-black text-xs">
                        <Star className="w-4 h-4 fill-amber-400 text-amber-400" /> {selectedPro.rating} <span className="text-gray-300 ml-1">{t.contador_view.directorio?.pro_modal?.reviews ? t.contador_view.directorio.pro_modal.reviews.replace('{count}', selectedPro.reviews.toString()) : `(${selectedPro.reviews} opiniones)`}</span>
                       </div>
                     </div>
                     <h3 className="text-5xl font-black text-dark tracking-tighter leading-tight mb-2">{selectedPro.name}</h3>
                     <p className="text-lg font-bold text-gray-400">{selectedPro.title}</p>
                   </div>

                   <p className="text-gray-500 font-medium text-lg leading-relaxed mb-8 italic">
                     "{selectedPro.bio}"
                   </p>

                   <div className="space-y-6 mb-10">
                      <div>
                        <h4 className="text-[10px] font-black text-dark uppercase tracking-widest mb-4">{t.contador_view.directorio?.pro_modal?.services_title || 'Especialidades'}</h4>
                        <div className="flex flex-wrap gap-2">
                           {selectedPro.services.map((s: string) => (
                             <span key={s} className="bg-gray-50 border border-gray-100 px-4 py-2 rounded-xl text-[10px] font-black text-gray-600 uppercase tracking-widest">{s}</span>
                           ))}
                        </div>
                      </div>
                      <div className="flex justify-between items-center bg-gray-50 p-6 rounded-[2rem] border border-gray-100">
                         <div>
                            <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">{t.contador_view.directorio?.pro_modal?.fees_label || 'Honorarios Aprox.'}</p>
                            <p className="text-2xl font-black text-dark">{t.contador_view.directorio?.pro_modal?.from || 'Desde'} {selectedPro.price}</p>
                         </div>
                         <div className="bg-white p-3 rounded-2xl shadow-sm text-primary"><DollarSign className="w-6 h-6"/></div>
                      </div>
                   </div>

                   <div className="flex gap-4">
                     <button 
                        onClick={() => setShowBooking(true)}
                        className="flex-1 py-5 bg-dark text-white rounded-[2rem] font-black text-xs uppercase tracking-widest hover:bg-black transition-all flex items-center justify-center gap-3 shadow-xl"
                     >
                       <Calendar className="w-5 h-5" /> {t.contador_view.directorio?.pro_modal?.book_appointment || 'Agendar Cita'}
                     </button>
                     <button 
                        onClick={() => setShowMessage(true)}
                        className="px-8 py-5 bg-gray-100 text-dark rounded-[2rem] font-black text-xs uppercase tracking-widest hover:bg-gray-200 transition-all text-ellipsis overflow-hidden whitespace-nowrap"
                       >
                        {t.contador_view.directorio?.pro_modal?.message || 'Mensaje'}
                     </button>
                   </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}

        {/* BOOKING MODAL */}
        {showBooking && selectedPro && (
          <div className="fixed inset-0 bg-dark/60 backdrop-blur-xl z-[80] flex items-center justify-center p-4" onClick={() => setShowBooking(false)}>
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white rounded-[3rem] w-full max-w-md p-8 shadow-3xl"
              onClick={e => e.stopPropagation()}
            >
               {bookingStep < 3 ? (
                 <>
                   <div className="text-center mb-8">
                      <div className="bg-dark text-white w-14 h-14 rounded-2xl flex items-center justify-center mx-auto mb-4">
                        <Calendar className="w-7 h-7" />
                      </div>
                      <h3 className="text-2xl font-black text-dark">{t.contador_view.directorio?.booking?.title ? t.contador_view.directorio.booking.title.replace('{name}', selectedPro.name.split(' ')[1]) : `Agendar con ${selectedPro.name.split(' ')[1]}`}</h3>
                      <p className="text-xs text-gray-400 font-bold uppercase tracking-widest mt-1">{t.contador_view.directorio?.booking?.step ? t.contador_view.directorio.booking.step.replace('{current}', String(bookingStep)).replace('{total}', '2') : `Paso ${bookingStep} de 2`}</p>
                   </div>

                   {bookingStep === 1 ? (
                     <div className="space-y-6">
                        <div>
                          <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-4">{t.contador_view.directorio?.booking?.select_day || 'Selecciona un día'}</p>
                          <div className="grid grid-cols-4 gap-2">
                            {[15, 16, 17, 18, 19, 20, 21, 22].map(day => (
                              <button 
                                key={day} 
                                onClick={() => setSelectedDay(day)}
                                className={`py-4 rounded-2xl text-xs font-black transition-all border ${selectedDay === day ? 'bg-primary text-white border-primary shadow-lg shadow-primary/20' : 'bg-gray-50 text-dark border-gray-100 hover:bg-gray-100'}`}
                              >
                                 {day} {t.common.months?.may || 'May'}
                              </button>
                            ))}
                          </div>
                        </div>
                        <button 
                          onClick={() => setBookingStep(2)}
                          disabled={!selectedDay}
                          className="w-full py-5 bg-primary text-white rounded-[1.5rem] font-black text-xs uppercase tracking-widest hover:bg-primary-dark transition-all shadow-xl shadow-primary/20 disabled:opacity-50"
                        >
                          {t.common.continue}
                        </button>
                     </div>
                   ) : (
                     <div className="space-y-6">
                        <div>
                          <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-4">{t.contador_view.directorio?.booking?.select_time || 'Selecciona horario (CDMX)'}</p>
                          <div className="grid grid-cols-2 gap-3">
                            {['09:00 AM', '10:30 AM', '12:00 PM', '04:30 PM'].map(time => (
                              <button 
                                key={time} 
                                onClick={() => setSelectedTime(time)}
                                className={`py-4 rounded-2xl text-xs font-black transition-all border ${selectedTime === time ? 'bg-dark text-white border-dark shadow-lg shadow-dark/20' : 'bg-gray-50 text-dark border-gray-100 hover:bg-gray-100'}`}
                              >
                                 {time}
                              </button>
                            ))}
                          </div>
                        </div>
                        <div className="flex gap-3 pt-2">
                          <button onClick={() => setBookingStep(1)} className="flex-1 py-4 bg-gray-100 text-dark rounded-2xl font-black text-xs uppercase tracking-widest">{t.common.back}</button>
                          <button 
                             onClick={handleBook} 
                             disabled={!selectedTime}
                             className="flex-[2] py-4 bg-dark text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-black shadow-xl disabled:opacity-50"
                          >
                            {t.contador_view.directorio?.booking?.confirm || 'Confirmar Cita'}
                          </button>
                        </div>
                     </div>
                   )}
                 </>
               ) : (
                 <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="text-center py-8">
                    <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6 shadow-2xl shadow-green-500/30">
                       <ShieldCheck className="w-10 h-10 text-white" />
                    </div>
                    <h3 className="text-3xl font-black text-dark mb-2">{t.contador_view.directorio?.booking?.success_title || '¡Solicitud Enviada!'}</h3>
                    <p className="text-gray-500 font-medium mb-8">{t.contador_view.directorio?.booking?.success_desc ? t.contador_view.directorio.booking.success_desc.replace('{name}', selectedPro.name) : `Hemos enviado tu propuesta de cita a ${selectedPro.name}. Te notificaremos en cuanto confirme.`}</p>
                    <button onClick={closeModals} className="w-full py-4 bg-gray-900 text-white rounded-2xl font-black text-xs uppercase tracking-widest">{t.common.understood}</button>
                 </motion.div>
               )}
            </motion.div>
          </div>
        )}

        {/* MESSAGE MODAL */}
        {showMessage && selectedPro && (
          <div className="fixed inset-0 bg-dark/60 backdrop-blur-xl z-[80] flex items-center justify-center p-4" onClick={closeModals}>
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-[3.5rem] w-full max-md overflow-hidden shadow-3xl"
              onClick={e => e.stopPropagation()}
            >
               {!messageSent ? (
                 <>
                   <div className="bg-primary p-10 text-white relative">
                      <div className="flex items-center gap-5">
                         <img src={selectedPro.img} className="w-16 h-16 rounded-2xl object-cover ring-4 ring-white/20" alt="" />
                         <div>
                            <h4 className="text-xl font-black leading-none mb-1">{selectedPro.name}</h4>
                            <div className="flex items-center gap-1.5 text-[10px] font-bold opacity-80 uppercase tracking-widest">
                               <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" /> {t.contador_view.directorio?.message_modal?.active_now || 'Activo ahora'}
                            </div>
                         </div>
                      </div>
                   </div>
                   <div className="p-10 space-y-6">
                      <textarea 
                        placeholder={t.contador_view.directorio?.message_modal?.placeholder || 'Hola, tengo una duda sobre...'}
                        value={messageText}
                        onChange={(e) => setMessageText(e.target.value)}
                        className="w-full h-44 p-5 bg-gray-50 rounded-3xl text-sm font-bold border-none outline-none focus:bg-white focus:ring-4 ring-primary/5 transition-all resize-none shadow-inner"
                      />
                      <div className="flex gap-4">
                        <button onClick={closeModals} className="flex-1 py-5 bg-gray-100 text-dark rounded-[1.5rem] font-black text-xs uppercase tracking-widest">{t.common.close}</button>
                        <button 
                          onClick={handleSendMessage}
                          disabled={!messageText.trim()}
                          className="flex-[2] py-5 bg-primary text-white rounded-[1.5rem] font-black text-xs uppercase tracking-widest hover:bg-primary-dark shadow-xl shadow-primary/20 transition-all disabled:opacity-50"
                        >
                          {t.contador_view.directorio?.message_modal?.send || 'Enviar Consulta'}
                        </button>
                      </div>
                   </div>
                 </>
               ) : (
                 <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="p-12 text-center">
                    <div className="w-20 h-20 bg-primary/10 text-primary rounded-full flex items-center justify-center mx-auto mb-8">
                       <Mail className="w-10 h-10" />
                    </div>
                    <h3 className="text-3xl font-black text-dark mb-2">{t.contador_view.directorio?.message_modal?.success_title || 'Mensaje Enviado'}</h3>
                    <p className="text-gray-500 font-medium mb-10 leading-relaxed">{t.contador_view.directorio?.message_modal?.success_desc ? t.contador_view.directorio.message_modal.success_desc.replace('{name}', selectedPro.name.split(' ')[1]) : `Tu mensaje fue entregado. ${selectedPro.name.split(' ')[1]} suele responder en menos de 2 horas.`}</p>
                    <button onClick={closeModals} className="w-full py-5 bg-primary text-white rounded-[1.5rem] font-black text-xs uppercase tracking-widest shadow-xl shadow-primary/30">{t.contador_view.directorio?.message_modal?.continue_browsing || 'Seguir Explorando'}</button>
                 </motion.div>
               )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

