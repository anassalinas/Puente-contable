export type ProfileType = 'PF' | 'PYME' | 'CONTADOR' | 'ADMIN' | null;

export interface Médico {
  id?: string;
  nombre: string;
  especialidad: string;
  correo: string;
  telefono: string;
  encargado: string;
  whatsapp: string;
  correoFacturacion: string;
  plazoRecordatorio: string;
  img?: string;
}

export interface Factura {
  id?: string;
  folio: string;
  emisor: string;
  date: string;
  monto: string;
  uso: string;
  status: string;
  metodoPago?: string;
}

export interface Proveedor {
  id?: string;
  nombre: string;
  rfc: string;
  giro: string;
  contacto: string;
  telefono: string;
  correo: string;
}
