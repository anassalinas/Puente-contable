import { motion } from 'motion/react';
import { X, Download, FileText, CheckCircle2 } from 'lucide-react';
import { useAppContext } from '../App';

interface CFDIViewerProps {
  onClose: () => void;
  data: {
    folio: string;
    emisor: string;
    rfcEmisor?: string;
    receptor: string;
    rfcReceptor?: string;
    date: string;
    monto: string;
    uso: string;
  };
}

export default function CFDIViewer({ onClose, data }: CFDIViewerProps) {
  const { showToast, t } = useAppContext();

  const handleDownload = (type: 'XML' | 'PDF') => {
    showToast(t.cfdi_viewer.download_success.replace('{type}', type));
  };

  return (
    <div className="fixed inset-0 bg-dark/60 backdrop-blur-sm z-[150] flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white document-viewer w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
      >
        <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
          <div className="flex items-center gap-3">
             <div className="bg-secondary p-2 rounded-xl text-white">
                <FileText className="w-5 h-5" />
             </div>
             <div>
                <h3 className="font-bold text-dark">{t.cfdi_viewer.title}</h3>
                <p className="text-[10px] font-mono text-gray-400">UUID: {data.folio}-{(Math.random() * 100000).toFixed(0)}-4C31-8E92</p>
             </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
            <X className="w-6 h-6 text-gray-400" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-8 space-y-8 font-sans">
          {/* Header CFDI */}
          <div className="flex justify-between items-start border-b border-gray-100 pb-6">
             <div className="space-y-1">
                <h4 className="text-secondary font-bold uppercase tracking-widest text-xs">{t.cfdi_viewer.issuer}</h4>
                <p className="font-bold text-dark">{data.emisor}</p>
                <p className="text-xs text-gray-500 font-mono">RFC: {data.rfcEmisor || 'E-RFC-991024-AA1'}</p>
                <p className="text-xs text-gray-500">601 General de Ley Personas Morales</p>
             </div>
             <div className="text-right space-y-1">
                <h4 className="text-secondary font-bold uppercase tracking-widest text-xs">{t.cfdi_viewer.receiver}</h4>
                <p className="font-bold text-dark">{data.receptor}</p>
                <p className="text-xs text-gray-500 font-mono">RFC: {data.rfcReceptor || 'XAXX010101000'}</p>
                <p className="text-xs text-gray-500">C.P. 76100 · {t.cfdi_viewer.receiver}: {data.uso}</p>
             </div>
          </div>

          {/* Conceptos */}
          <div className="space-y-4">
             <h4 className="text-secondary font-bold uppercase tracking-widest text-xs border-b border-gray-50 pb-2">{t.cfdi_viewer.concepts}</h4>
             <table className="w-full text-sm">
                <thead className="text-gray-400 text-xs uppercase italic font-medium">
                   <tr>
                      <th className="pb-3 text-left">{t.cfdi_viewer.quantity}</th>
                      <th className="pb-3 text-left">{t.cfdi_viewer.description}</th>
                      <th className="pb-3 text-right">{t.cfdi_viewer.unit_price}</th>
                      <th className="pb-3 text-right">{t.cfdi_viewer.amount}</th>
                   </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                   <tr>
                      <td className="py-3">1</td>
                      <td className="py-3 font-medium">{t.cfdi_viewer.medical_fees}</td>
                      <td className="py-3 text-right">{data.monto}</td>
                      <td className="py-3 text-right font-bold">{data.monto}</td>
                   </tr>
                </tbody>
             </table>
          </div>

          {/* Totals */}
          <div className="flex justify-end pt-4 border-t border-gray-100">
             <div className="w-full max-w-[200px] space-y-2">
                <div className="flex justify-between text-sm">
                   <span className="text-gray-500">{t.cfdi_viewer.subtotal}</span>
                   <span className="font-bold text-dark">{data.monto}</span>
                </div>
                <div className="flex justify-between text-sm">
                   <span className="text-gray-500">{t.cfdi_viewer.tax}</span>
                   <span className="font-bold text-dark">$0.00</span>
                </div>
                <div className="flex justify-between text-lg pt-2 border-t border-gray-100">
                   <span className="font-bold text-dark">{t.cfdi_viewer.total}</span>
                   <span className="font-bold text-secondary">{data.monto}</span>
                </div>
             </div>
          </div>

          {/* Sello Digital */}
          <div className="space-y-2 pt-6">
             <h4 className="text-secondary font-bold uppercase tracking-widest text-xs">{t.cfdi_viewer.sat_seal}</h4>
             <p className="text-[9px] font-mono text-gray-400 leading-tight bg-gray-50 p-3 rounded-xl break-all">
                MIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCpX+z+Y/7+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+8+=
             </p>
          </div>
        </div>

        <div className="p-6 bg-gray-50 border-t border-gray-100 flex gap-4">
          <button 
            onClick={() => handleDownload('XML')}
            className="flex-1 flex items-center justify-center gap-2 py-3 bg-white border border-gray-200 rounded-2xl text-sm font-bold text-gray-600 hover:bg-gray-100 transition-colors"
          >
            <Download className="w-4 h-4" /> {t.cfdi_viewer.download_xml}
          </button>
          <button 
            onClick={() => handleDownload('PDF')}
            className="flex-1 flex items-center justify-center gap-2 py-3 bg-secondary text-white rounded-2xl text-sm font-bold shadow-lg shadow-secondary/20 hover:bg-secondary-dark transition-colors"
          >
            <Download className="w-4 h-4" /> {t.cfdi_viewer.download_pdf}
          </button>
        </div>
      </motion.div>
    </div>
  );
}
