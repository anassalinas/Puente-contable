import { motion } from 'motion/react';
import { X, Mail, Phone, MessageSquare, Clock, FileText, CheckCircle2, AlertCircle, Calendar } from 'lucide-react';
import { Médico, Factura } from '../types';
import { useAppContext } from '../App';

interface DoctorProfileProps {
  doctor: Médico;
  history: Factura[];
  onClose: () => void;
  onViewInvoice: (f: Factura) => void;
}

export default function DoctorProfile({ doctor, history, onClose, onViewInvoice }: DoctorProfileProps) {
  const { showToast, t } = useAppContext();

  const totalAccumulated = history.reduce((acc, f) => {
    const val = parseFloat(f.monto.replace(/[$,MXN ]/g, '')) || 0;
    return acc + val;
  }, 0);

  const handleAction = (type: 'Llamar' | 'WhatsApp' | 'Correo') => {
    if (type === 'Llamar') {
      showToast(t.doctor_profile.call_finished.replace('{doctor}', doctor.nombre));
    } else {
      showToast(t.doctor_profile.notification_sent);
    }
  };

  return (
    <div className="fixed inset-0 bg-dark/60 backdrop-blur-sm z-[150] flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white w-full max-w-4xl rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
      >
        <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
          <h3 className="font-bold text-dark text-lg">{t.doctor_profile.title}</h3>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
            <X className="w-6 h-6 text-gray-400" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto overflow-x-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-12">
            {/* Info Section */}
            <div className="lg:col-span-4 p-8 bg-gray-50/50 border-r border-gray-100 space-y-8">
               <div className="text-center">
                  <div className="w-24 h-24 bg-white rounded-3xl border border-gray-100 shadow-sm flex items-center justify-center text-secondary mx-auto mb-4">
                    <CheckCircle2 className="w-12 h-12" />
                  </div>
                  <h4 className="text-xl font-bold text-dark">{doctor.nombre}</h4>
                  <p className="text-sm text-secondary font-bold uppercase tracking-widest mt-1">{doctor.especialidad}</p>
               </div>

               <div className="space-y-4">
                  <div className="flex items-center gap-3 text-sm text-gray-600">
                     <Mail className="w-4 h-4 text-gray-400" />
                     {doctor.correo}
                  </div>
                  <div className="flex items-center gap-3 text-sm text-gray-600">
                     <Phone className="w-4 h-4 text-gray-400" />
                     {doctor.telefono}
                  </div>
               </div>

               <div className="pt-6 border-t border-gray-100">
                  <h5 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-4">{t.doctor_profile.billing_manager}</h5>
                  <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm space-y-3">
                     <p className="font-bold text-sm text-dark">{doctor.encargado}</p>
                     <div className="flex gap-2">
                        <button onClick={() => handleAction('WhatsApp')} className="p-2 bg-green-50 text-green-600 rounded-lg hover:bg-green-100 transition-colors"><MessageSquare className="w-4 h-4" /></button>
                        <button onClick={() => handleAction('Correo')} className="p-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors"><Mail className="w-4 h-4" /></button>
                        <button onClick={() => handleAction('Llamar')} className="p-2 bg-secondary-light text-secondary rounded-lg hover:bg-secondary transition-colors"><Phone className="w-4 h-4" /></button>
                     </div>
                  </div>
               </div>

               <div className="bg-secondary p-4 rounded-2xl text-white shadow-lg shadow-secondary/20">
                  <p className="text-[10px] font-bold text-secondary-light uppercase tracking-widest mb-1 leading-none">{t.doctor_profile.reminder_set}</p>
                  <p className="text-sm font-bold flex items-center gap-2 italic">
                    <Clock className="w-4 h-4" /> {doctor.plazoRecordatorio}
                  </p>
               </div>
            </div>

            {/* History Section */}
            <div className="lg:col-span-8 p-8 space-y-6">
               <div className="flex justify-between items-center">
                  <h4 className="font-bold text-dark flex items-center gap-2">
                     <FileText className="w-5 h-5 text-secondary" /> {t.doctor_profile.invoice_history}
                  </h4>
                  <div className="text-right">
                     <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{t.doctor_profile.yearly_total}</p>
                     <p className="text-xl font-bold text-secondary font-serif">${totalAccumulated.toLocaleString()} MXN</p>
                  </div>
               </div>

               <div className="space-y-3">
                  {history.map((f, i) => (
                    <div key={i} className="p-4 bg-white border border-gray-100 rounded-2xl flex items-center justify-between hover:border-secondary/30 hover:bg-secondary-light/20 transition-all group">
                       <div className="flex items-center gap-4">
                          <div className="w-10 h-10 bg-gray-50 rounded-xl flex items-center justify-center text-gray-400 group-hover:text-secondary transition-colors">
                             <Calendar className="w-5 h-5" />
                          </div>
                          <div>
                             <p className="font-bold text-dark text-sm">{f.date}</p>
                             <p className="text-xs text-gray-400 font-medium">Folio: {f.folio}</p>
                          </div>
                       </div>
                       <div className="flex items-center gap-6">
                          <p className="font-bold text-dark">{f.monto}</p>
                          <div className="flex items-center gap-4">
                             {f.status === 'OK' ? (
                               <span className="p-1 px-2.5 rounded-lg bg-green-50 text-green-600">
                                 <CheckCircle2 className="w-4 h-4" /> 
                               </span>
                             ) : (
                               <span className="p-1 px-2.5 rounded-lg bg-amber-50 text-amber-600">
                                 <Clock className="w-4 h-4" />
                               </span>
                             )}
                             <button 
                               onClick={() => onViewInvoice(f)}
                               className="p-2 text-gray-400 hover:text-secondary hover:bg-secondary-light rounded-xl transition-all"
                             >
                               <MessageSquare className="w-4 h-4" />
                             </button>
                          </div>
                       </div>
                    </div>
                  ))}
               </div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
