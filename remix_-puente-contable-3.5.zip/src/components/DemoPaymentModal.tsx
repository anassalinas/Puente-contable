import { useState } from 'react';
import { motion } from 'motion/react';
import { CreditCard, Lock, CheckCircle2, XCircle, ShieldCheck, Loader2 } from 'lucide-react';
import { useAppContext } from '../App';

interface DemoPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  planName: string;
  price: string;
  colorScheme?: 'primary' | 'secondary' | 'tertiary';
  onSuccess: () => void;
}

export default function DemoPaymentModal({ isOpen, onClose, planName, price, colorScheme = 'primary', onSuccess }: DemoPaymentModalProps) {
  const { t } = useAppContext();
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const colors = {
    primary: 'bg-primary hover:bg-primary-dark text-white',
    secondary: 'bg-secondary hover:bg-secondary-dark text-white',
    tertiary: 'bg-tertiary hover:bg-tertiary-dark text-white',
  };

  const textColors = {
    primary: 'text-primary',
    secondary: 'text-secondary',
    tertiary: 'text-tertiary',
  };

  const handlePay = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setSuccess(true);
      setTimeout(() => {
        setSuccess(false);
        onSuccess();
        onClose();
      }, 2000);
    }, 1500);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-dark/60 backdrop-blur-sm flex items-center justify-center z-[100] p-4" onClick={!loading ? onClose : undefined}>
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white rounded-3xl p-6 md:p-8 w-full max-w-md shadow-2xl relative" 
        onClick={e => e.stopPropagation()}
      >
        {!loading && !success && (
          <button onClick={onClose} className="absolute top-6 right-6 text-gray-400 hover:text-gray-600">
            <XCircle className="w-6 h-6"/>
          </button>
        )}

        <div className="mb-6 text-center">
          <div className={`w-16 h-16 rounded-full mx-auto flex items-center justify-center mb-4 ${colorScheme === 'primary' ? 'bg-primary/10' : colorScheme === 'secondary' ? 'bg-secondary/10' : 'bg-tertiary/10'}`}>
            <CreditCard className={`w-8 h-8 ${textColors[colorScheme]}`} />
          </div>
          <h2 className="text-2xl font-bold text-dark">{t.payment.title}</h2>
          <p className="text-gray-500 text-sm mt-1">{t.payment.subtitle}</p>
        </div>

        {success ? (
          <div className="py-8 text-center flex flex-col items-center justify-center space-y-4">
            <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} className={`w-20 h-20 rounded-full flex items-center justify-center ${colorScheme === 'primary' ? 'bg-primary/20 text-primary' : colorScheme === 'secondary' ? 'bg-secondary/20 text-secondary' : 'bg-tertiary/20 text-tertiary'}`}>
              <CheckCircle2 className="w-10 h-10" />
            </motion.div>
            <h3 className="text-xl font-bold text-dark">{t.payment.success_title}</h3>
            <p className="text-gray-500">{t.payment.success_desc}</p>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="bg-gray-50 p-4 rounded-xl border border-gray-100 flex justify-between items-center">
              <div>
                <p className="text-sm text-gray-500 font-medium">{t.payment.concept}</p>
                <p className="font-bold text-dark">{planName}</p>
              </div>
              <div className="text-right">
                <p className="text-sm text-gray-500 font-medium">{t.payment.total}</p>
                <p className={`font-bold text-xl font-[Helvetica] tracking-wide ${textColors[colorScheme]}`}>{price}</p>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">{t.payment.card_number}</label>
                <div className="relative">
                  <input type="text" value="**** **** **** 4242" readOnly className="w-full border border-gray-200 rounded-xl p-3 pr-10 outline-none bg-gray-50 text-gray-600 font-[Helvetica] tracking-widest text-sm cursor-not-allowed" />
                  <CreditCard className="w-5 h-5 text-gray-400 absolute right-3 top-3" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">{t.payment.expiry}</label>
                  <input type="text" value="12/28" readOnly className="w-full border border-gray-200 rounded-xl p-3 outline-none bg-gray-50 text-gray-600 font-[Helvetica] tracking-widest text-sm cursor-not-allowed" />
                </div>
                <div>
                  <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">{t.payment.cvc}</label>
                  <input type="text" value="***" readOnly className="w-full border border-gray-200 rounded-xl p-3 outline-none bg-gray-50 text-gray-600 font-[Helvetica] tracking-widest text-sm cursor-not-allowed" />
                </div>
              </div>
              <div>
                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">{t.payment.card_holder}</label>
                <input type="text" value={t.payment.demo_user} readOnly className="w-full border border-gray-200 rounded-xl p-3 outline-none bg-gray-50 text-gray-600 text-sm cursor-not-allowed" />
              </div>
            </div>

            <button 
              onClick={handlePay}
              disabled={loading}
              className={`w-full py-4 rounded-xl font-bold transition-all shadow-sm flex items-center justify-center gap-2 ${colors[colorScheme]} disabled:opacity-80 disabled:cursor-wait`}
            >
              {loading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" /> {t.payment.processing}
                </>
              ) : (
                <>
                  <Lock className="w-4 h-4" /> {t.payment.pay} <span className="font-[Helvetica] tracking-wide">{price}</span>
                </>
              )}
            </button>
            <p className="text-center text-xs text-gray-400 flex items-center justify-center gap-1.5 focus:outline-none">
              <ShieldCheck className="w-4 h-4" /> {t.payment.secure_footer}
            </p>
          </div>
        )}
      </motion.div>
    </div>
  );
}
