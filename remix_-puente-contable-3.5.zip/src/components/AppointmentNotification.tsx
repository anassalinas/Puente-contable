import { motion } from 'motion/react';
import { X, Calendar, MessageSquare, Mail, CheckCircle2 } from 'lucide-react';
import { useAppContext } from '../App';

interface AppointmentNotificationProps {
  onClose: () => void;
  data: {
    doctor: string;
    date: string;
    time?: string;
  };
}

export default function AppointmentNotification({ onClose, data }: AppointmentNotificationProps) {
  const { showToast, t } = useAppContext();

  const handleAction = (type: string) => {
    if (type === 'calendar') {
      showToast(t.common.success);
    } else {
      showToast(t.common.success);
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-dark/60 backdrop-blur-sm z-[200] flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white w-full max-w-sm rounded-[2.5rem] p-8 shadow-2xl flex flex-col items-center text-center relative overflow-hidden"
      >
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-secondary to-blue-500"></div>
        <div className="w-16 h-16 bg-secondary-light rounded-full flex items-center justify-center text-secondary mb-4">
          <Calendar className="w-8 h-8" />
        </div>
        <h3 className="text-xl font-bold text-dark mb-2 tracking-tight">{t.common.apt_reminder}</h3>
        <p className="text-gray-500 text-sm mb-8 leading-relaxed">
          {t.common.apt_scheduled.replace('{doctor}', data.doctor).replace('{date}', data.date)}
        </p>

        <div className="space-y-3 w-full">
           <button 
             onClick={() => handleAction('calendar')}
             className="w-full flex items-center justify-center gap-3 py-3 bg-blue-50 hover:bg-blue-100 text-blue-600 rounded-2xl font-bold transition-all border border-blue-100"
           >
             <Calendar className="w-5 h-5" /> {t.common.add_to_calendar}
           </button>
           
           <button 
             onClick={() => handleAction('whatsapp')}
             className="w-full flex items-center justify-center gap-3 py-3 bg-green-50 hover:bg-green-100 text-green-600 rounded-2xl font-bold transition-all border border-green-100"
           >
             <MessageSquare className="w-5 h-5" /> {t.common.send_whatsapp}
           </button>

           <button 
             onClick={() => handleAction('email')}
             className="w-full flex items-center justify-center gap-3 py-3 bg-gray-50 hover:bg-gray-100 text-gray-600 rounded-2xl font-bold transition-all border border-gray-100"
           >
             <Mail className="w-5 h-5" /> {t.common.send_email}
           </button>
        </div>
        
        <button onClick={onClose} className="mt-6 text-sm text-gray-400 hover:text-gray-600 font-medium">{t.common.skip}</button>
      </motion.div>
    </div>
  );
}
