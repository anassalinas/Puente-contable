import { Globe, Sun, Moon, Check } from 'lucide-react';
import { useAppContext } from '../App';

export default function AppearanceSettings() {
  const { language, setLanguage, theme, toggleTheme, showToast, t } = useAppContext();

  return (
    <div className="bg-white rounded-[2rem] border border-gray-100 p-8 shadow-sm">
      <h3 className="text-xl font-black text-dark mb-2 tracking-tight">{t.common?.appearance_title || 'Apariencia e idioma'}</h3>
      <p className="text-sm text-gray-500 mb-8 font-medium">{t.common?.appearance_desc || 'Personaliza tu experiencia'}</p>

      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-bold text-dark">{t.common?.dark_mode_title || 'Modo oscuro'}</p>
            <p className="text-xs text-gray-400 mt-1">{theme === 'light' ? (t.common?.dark_mode_off || 'Desactivado') : (t.common?.dark_mode_on || 'Activado')}</p>
          </div>
          <button 
            onClick={toggleTheme}
            className={`w-14 h-8 rounded-full flex items-center p-1 transition-colors ${theme === 'dark' ? 'bg-secondary' : 'bg-gray-200'}`}
          >
            <div className={`w-6 h-6 rounded-full flex items-center justify-center bg-white shadow-sm transition-transform ${theme === 'dark' ? 'translate-x-6' : 'translate-x-0'}`}>
              {theme === 'dark' ? <Moon className="w-3.5 h-3.5 text-secondary" /> : <Sun className="w-3.5 h-3.5 text-gray-400" />}
            </div>
          </button>
        </div>

        <div className="pt-6 border-t border-gray-50">
          <p className="text-sm font-bold text-dark mb-4">{t.common?.language_title || 'Idioma de la interfaz'}</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {[
              { code: 'es', label: 'Español', flag: '🇲🇽' },
              { code: 'en', label: 'English', flag: '🇺🇸' },
              { code: 'fr', label: 'Français', flag: '🇫🇷' },
              { code: 'pt', label: 'Português', flag: '🇧🇷' },
              { code: 'zh', label: '中文', flag: '🇨🇳' },
            ].map((lang) => (
              <button
                key={lang.code}
                onClick={() => {
                  setLanguage(lang.code);
                  showToast(`${t.common?.success || '✓'} ${lang.label}`);
                }}
                className={`flex items-center gap-3 p-4 rounded-xl border transition-all ${
                  language === lang.code 
                    ? 'border-secondary bg-secondary/5 text-secondary' 
                    : 'border-gray-100 hover:border-gray-200 text-dark'
                }`}
              >
                <span className="text-2xl">{lang.flag}</span>
                <span className="font-bold text-sm">{lang.label}</span>
                {language === lang.code && <Check className="w-4 h-4 ml-auto" />}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
