import { useState, useEffect, createContext, useContext, ReactNode } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Star, LogOut, CalendarDays, ChevronRight, User, Building2, BriefcaseBusiness, ShieldCheck, Menu, X, ArrowLeft, Check, Bell, Info, AlertCircle, Clock, TrendingUp, Sun, Moon, ChevronDown } from 'lucide-react';

import { Globe } from 'lucide-react';
import { translations } from './lib/translations';
import PersonaFisicaView from './views/PersonaFisicaView';
import PYMEView from './views/PYMEView';
import ContadorView from './views/ContadorView';
import AdminView from './views/AdminView';

export type ProfileType = 'PF' | 'PYME' | 'CONTADOR' | 'ADMIN' | null;

export type ThemeType = 'light' | 'dark';

interface AppContextType {
  profile: ProfileType;
  setProfile: (p: ProfileType) => void;
  currentView: string;
  setCurrentView: (v: string) => void;
  viewHistory: string[];
  goBack: () => void;
  showToast: (msg: string) => void;
  language: string;
  setLanguage: (lang: string) => void;
  languageSelected: boolean;
  setLanguageSelected: (v: boolean) => void;
  theme: ThemeType;
  setTheme: (t: ThemeType) => void;
  toggleTheme: () => void;
  isAdminMode: boolean;
  setIsAdminMode: (v: boolean) => void;
  showNotifications: boolean;
  setShowNotifications: (v: boolean) => void;
  notifications: any[];
  setNotifications: (v: any[]) => void;
  unreadCount: number;
  markAsRead: () => void;
  t: any;
}

export const AppContext = createContext<AppContextType | null>(null);

export const useAppContext = () => {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("Missing provider");
  return ctx;
};

function Login({ onLogin }: { onLogin: () => void }) {
  const { language } = useAppContext();
  const t = translations[language] || translations.es;
  
  return (
    <div className="relative min-h-screen flex flex-col justify-end items-center bg-black text-white p-8 pb-20 overflow-hidden">
      <div className="absolute inset-0 z-0 flex items-center justify-center bg-black">
        <video
          autoPlay
          loop
          muted
          playsInline
          className="w-full h-full object-contain md:object-cover"
          onError={(e) => console.error("Error cargando video:", e)}
        >
          <source src="https://firebasestorage.googleapis.com/v0/b/gen-lang-client-0284893332.firebasestorage.app/o/descarga.mp4?alt=media&token=efcb9031-e4f2-4895-a86d-5456e59502e4" type="video/mp4" />
        </video>
      </div>
      <div className="absolute inset-0 bg-black/10 z-0" />
      
      {/* Bottom Login Button */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative z-10 w-full max-w-xs mx-auto mb-8"
      >
          <button
            onClick={onLogin}
            className="w-full flex items-center justify-center gap-3 bg-white/10 hover:bg-white/20 text-white py-4 px-6 rounded-3xl font-bold transition-all shadow-2xl text-lg backdrop-blur-2xl border border-white/20 tracking-wide"
          >
            <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" alt="Google" className="w-6 h-6 bg-white rounded-full p-1 shadow-sm" />
            {t.continue_google || 'Continuar con Google'}
          </button>
      </motion.div>
    </div>
  );
}


function ProfileSelector() {
  const { setProfile, showToast, language, setLanguage, languageSelected, setLanguageSelected, theme, toggleTheme } = useAppContext();
  const t = translations[language] || translations.es;

  const languages = [
    { code: 'es', label: 'Español', flag: '🇲🇽' },
    { code: 'en', label: 'English', flag: '🇺🇸' },
    { code: 'pt', label: 'Português', flag: '🇧🇷' },
    { code: 'fr', label: 'Français', flag: '🇫🇷' },
    { code: 'it', label: 'Italiano', flag: '🇮🇹' },
    { code: 'zh', label: '中文', flag: '🇨🇳' },
  ];

  return (
    <div className="relative min-h-screen flex flex-col items-center justify-center p-4 overflow-hidden bg-black">
      <div className="absolute inset-0 z-0 flex items-center justify-center">
        <video
          autoPlay
          loop
          muted
          playsInline
          className="w-full h-full object-contain md:object-cover opacity-60"
          onError={(e) => console.error("Error cargando video:", e)}
        >
          <source src="https://firebasestorage.googleapis.com/v0/b/gen-lang-client-0284893332.firebasestorage.app/o/descarga.mp4?alt=media&token=efcb9031-e4f2-4895-a86d-5456e59502e4" type="video/mp4" />
        </video>
      </div>
      <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/40 z-0" />

      <AnimatePresence mode="wait">
        {!languageSelected ? (
          <motion.div
            key="lang-step"
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 1.1, y: -20 }}
            className="relative z-10 w-full max-w-2xl px-6"
          >
            <div className="text-center mb-12 flex flex-col items-center">
              <div className="flex items-center justify-center gap-4 mb-6">
                <button
                  onClick={toggleTheme}
                  className="bg-white/10 backdrop-blur-xl p-3 rounded-full border border-white/20 hover:bg-white/20 transition-all text-white"
                >
                  {theme === 'light' ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
                </button>
                <div className="w-px h-8 bg-white/20" />
                <motion.div 
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  className="bg-white/10 backdrop-blur-xl px-4 py-2 rounded-full border border-white/20"
                >
                  <div className="flex items-center gap-2">
                    <Globe className="w-4 h-4 text-secondary animate-pulse" />
                    <span className="text-[10px] font-black uppercase tracking-[0.3em] text-white/80">{t.lang_setup_title || 'SELECCIONAR IDIOMA'}</span>
                  </div>
                </motion.div>
              </div>
              <h2 className="text-4xl md:text-5xl font-black text-white mb-4 tracking-tight">{t.lang_step_title || 'FacturApp'}</h2>
              <p className="text-white/40 text-lg font-medium">{t.lang_step_subtitle || 'Elige tu idioma'}</p>
            </div>

            <div className="bg-white/5 backdrop-blur-3xl p-6 md:p-8 rounded-[3rem] border border-white/10 shadow-[0_30px_100px_rgba(0,0,0,0.5)] grid grid-cols-2 md:grid-cols-3 gap-4">
              {languages.map((lang, index) => (
                <motion.button
                  key={lang.code}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 * index }}
                  onClick={() => {
                    setLanguage(lang.code);
                    setLanguageSelected(true);
                    showToast(`${t.common?.success || '✓'} Language changed to ${lang.label}`);
                  }}
                  className="flex flex-col items-center gap-3 p-6 rounded-[2rem] hover:bg-white text-white hover:text-black transition-all duration-500 group active:scale-95 shadow-lg border border-white/5 hover:border-white"
                >
                  <span className="text-4xl group-hover:scale-125 transition-transform duration-500">{lang.flag}</span>
                  <span className="font-bold text-sm tracking-wide">{lang.label}</span>
                </motion.button>
              ))}
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="profile-step"
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            className="relative z-10 w-full max-w-md"
          >
            <div className="bg-white/10 backdrop-blur-3xl text-white rounded-[2.5rem] shadow-2xl border border-white/20 p-8 md:p-10 mb-6">
              <div className="flex items-center justify-center gap-4 mb-6">
                <button
                  onClick={toggleTheme}
                  className="bg-white/10 backdrop-blur-xl p-3 rounded-full border border-white/20 hover:bg-white/20 transition-all text-white"
                >
                  {theme === 'light' ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
                </button>
                <div className="w-px h-8 bg-white/20" />
                <button 
                  onClick={() => setLanguageSelected(false)}
                  className="bg-white/10 backdrop-blur-xl px-4 py-2 border border-white/20 hover:bg-white/20 transition-all text-white uppercase font-black text-[10px] tracking-widest rounded-full flex items-center gap-2"
                >
                  <Globe className="w-4 h-4" /> {language}
                </button>
              </div>

              <div className="text-center mb-8 shrink-0">
                <h2 className="text-3xl font-black mb-3 tracking-tight">{t.title}</h2>
                <p className="text-white/60 text-sm md:text-base leading-relaxed font-medium">{t.subtitle}</p>
              </div>

              <div className="relative group/scroll">
                <div 
                  className="max-h-[320px] overflow-y-auto pr-2 custom-scrollbar space-y-4"
                  onScroll={(e) => {
                    const target = e.currentTarget;
                    const isBottom = target.scrollHeight - target.scrollTop <= target.clientHeight + 10;
                    const indicator = document.getElementById('scroll-indicator');
                    if (indicator) {
                      indicator.style.opacity = isBottom ? '0' : '1';
                      indicator.style.pointerEvents = isBottom ? 'none' : 'auto';
                    }
                  }}
                >
                  <button 
                    onClick={() => setProfile('PF')} 
                    className="w-full flex items-center gap-5 p-5 bg-white/5 border border-white/10 rounded-2xl hover:bg-white/10 hover:border-white/30 transition-all text-left group active:scale-95"
                  >
                    <div className="bg-white/10 p-3 rounded-xl text-white group-hover:scale-110 transition-transform shadow-lg"><User className="w-6 h-6"/></div>
                    <div>
                      <h3 className="font-bold text-lg">{t.pf}</h3>
                      <p className="text-xs text-white/50">{t.pf_sub}</p>
                    </div>
                  </button>
                  
                  <button 
                    onClick={() => setProfile('PYME')} 
                    className="w-full flex items-center gap-5 p-5 bg-white/5 border border-white/10 rounded-2xl hover:bg-white/10 hover:border-white/30 transition-all text-left group active:scale-95"
                  >
                    <div className="bg-white/10 p-3 rounded-xl text-white group-hover:scale-110 transition-transform shadow-lg"><Building2 className="w-6 h-6"/></div>
                    <div>
                      <h3 className="font-bold text-lg">{t.pyme}</h3>
                      <p className="text-xs text-white/50">{t.pyme_sub}</p>
                    </div>
                  </button>
                  
                  <button 
                    onClick={() => setProfile('CONTADOR')} 
                    className="w-full flex items-center gap-5 p-5 bg-white/5 border border-white/10 rounded-2xl hover:bg-white/10 hover:border-white/30 transition-all text-left group active:scale-95"
                  >
                    <div className="bg-white/10 p-3 rounded-xl text-white group-hover:scale-110 transition-transform shadow-lg"><BriefcaseBusiness className="w-6 h-6"/></div>
                    <div>
                      <h3 className="font-bold text-lg">{t.contador}</h3>
                      <p className="text-xs text-white/50">{t.contador_sub}</p>
                    </div>
                  </button>

                  <button 
                    onClick={() => setProfile('ADMIN')} 
                    className="w-full flex items-center gap-5 p-5 bg-white/5 border border-white/10 rounded-2xl hover:bg-white/10 hover:border-white/30 transition-all text-left group active:scale-95"
                  >
                    <div className="bg-white/10 p-3 rounded-xl text-white group-hover:scale-110 transition-transform shadow-lg"><ShieldCheck className="w-6 h-6"/></div>
                    <div>
                      <h3 className="font-bold text-lg">Admin View</h3>
                      <p className="text-xs text-white/50">Panel de control administrativo</p>
                    </div>
                  </button>
                </div>

                {/* Bouncing Scroll Indicator */}
                <motion.div 
                  id="scroll-indicator"
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="absolute -bottom-2 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1 transition-opacity duration-300 z-20"
                >
                  <span className="text-[9px] font-black uppercase tracking-[0.2em] text-secondary bg-black/80 px-3 py-1 rounded-full backdrop-blur-md border border-white/10 shadow-2xl">
                    {t.scroll_hint || 'Desliza para más'}
                  </span>
                  <motion.div
                    animate={{ y: [0, 5, 0] }}
                    transition={{ repeat: Infinity, duration: 1.5 }}
                  >
                    <ChevronDown className="w-5 h-5 text-secondary" />
                  </motion.div>
                </motion.div>
              </div>
              
              <button 
                onClick={() => setLanguageSelected(false)}
                className="w-full mt-6 flex items-center justify-center gap-2 text-white/40 hover:text-white transition-colors text-xs font-bold uppercase tracking-widest"
              >
                <ArrowLeft className="w-3 h-3" /> {t.lang_label || 'Cambiar Idioma'}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

const NAV_ITEMS = {
  PF: [
    { id: 'dashboard', label: 'Dashboard PF' },
    { id: 'medicos', label: 'Mis médicos' },
    { id: 'facturas', label: 'Facturas (CFDI)' },
    { id: 'asesor', label: 'Asesor IA' },
    { id: 'directorio', label: 'Directorio contadores' },
    { id: 'perfil', label: 'Mi perfil' },
  ],
  PYME: [
    { id: 'dashboard', label: 'Dashboard PYME' },
    { id: 'proveedores', label: 'Proveedores' },
    { id: 'emitir', label: 'Emitir CFDI' },
    { id: 'nomina', label: 'Nómina' },
    { id: 'validación', label: 'Validación CFDI' },
    { id: 'conciliacion', label: 'Conciliación' },
    { id: 'calendario', label: 'Calendario Fiscal' },
    { id: 'descargas', label: 'Descargas Masivas' },
    { id: 'alertas', label: 'Alertas Fiscales' },
    { id: 'asesor', label: 'Asesor IA' },
    { id: 'perfil', label: 'Perfil' },
  ],
  CONTADOR: [
    { id: 'dashboard', label: 'Dashboard Contador' },
    { id: 'clientes', label: 'Mis clientes' },
    { id: 'comisiones', label: 'Comisiones' },
    { id: 'perfil', label: 'Mi perfil' },
    { id: 'directorio', label: 'Ver directorio' },
  ],
  ADMIN: [
    { id: 'dashboard', label: 'Dashboard Admin' },
  ]
};

function Layout({ children, onLogout }: { children: ReactNode, onLogout: () => void }) {
  const { 
    profile, setProfile, currentView, setCurrentView, goBack, showToast, 
    isAdminMode, setIsAdminMode, showNotifications, setShowNotifications, 
    notifications, unreadCount, markAsRead, language, setLanguage, theme, toggleTheme
  } = useAppContext();

  const t = translations[language] || translations.es;

  const NAV_ITEMS_TRANSLATED = {
    PF: [
      { id: 'dashboard', label: t.nav.dashboard },
      { id: 'medicos', label: t.nav.doctors },
      { id: 'facturas', label: t.nav.invoices },
      { id: 'asesor', label: t.nav.advisor },
      { id: 'directorio', label: t.nav.directory },
      { id: 'perfil', label: t.nav.profile },
    ],
    PYME: [
      { id: 'dashboard', label: t.nav.dashboard },
      { id: 'proveedores', label: t.nav.providers },
      { id: 'emitir', label: t.nav.issue },
      { id: 'nomina', label: t.nav.payroll },
      { id: 'validación', label: t.nav.validation },
      { id: 'conciliacion', label: t.nav.reconciliation },
      { id: 'calendario', label: t.nav.calendar },
      { id: 'descargas', label: t.nav.downloads },
      { id: 'alertas', label: t.nav.alerts },
      { id: 'asesor', label: t.nav.advisor },
      { id: 'perfil', label: t.nav.profile },
    ],
    CONTADOR: [
      { id: 'dashboard', label: t.nav.dashboard },
      { id: 'clientes', label: t.nav.clients },
      { id: 'comisiones', label: t.nav.commissions },
      { id: 'perfil', label: t.nav.profile },
      { id: 'directorio', label: t.nav.directory },
    ],
    ADMIN: [
      { id: 'dashboard', label: t.nav.dashboard },
    ]
  };

  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const navItems = NAV_ITEMS_TRANSLATED[profile || 'PF'];

  const themeConfig = {
    PF: {
      bg: 'bg-secondary',
      bgHover: 'hover:bg-secondary-dark',
      text: 'text-secondary',
      textHover: 'hover:text-secondary',
      shadow: 'shadow-secondary/20',
      light: 'bg-secondary-light',
      fill: 'fill-secondary'
    },
    PYME: {
      bg: 'bg-tertiary',
      bgHover: 'hover:bg-tertiary-dark',
      text: 'text-tertiary',
      textHover: 'hover:text-tertiary',
      shadow: 'shadow-tertiary/20',
      light: 'bg-tertiary-light',
      fill: 'fill-tertiary'
    },
    CONTADOR: {
      bg: 'bg-primary',
      bgHover: 'hover:bg-primary-dark',
      text: 'text-primary',
      textHover: 'hover:text-primary',
      shadow: 'shadow-primary/20',
      light: 'bg-primary-light',
      fill: 'fill-primary'
    },
    ADMIN: {
      bg: 'bg-dark',
      bgHover: 'hover:bg-black',
      text: 'text-dark',
      textHover: 'hover:text-black',
      shadow: 'shadow-dark/20',
      light: 'bg-gray-100',
      fill: 'fill-dark'
    }
  };

  const layoutTheme = themeConfig[profile || 'PF'];

  return (
    <div className="flex h-screen bg-light">
      {/* Sidebar Overlay (Mobile & Tablet) */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/40 z-30 md:hidden backdrop-blur-sm transition-opacity"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={`
        fixed inset-y-0 left-0 z-40 w-[280px] bg-white text-dark border-r border-gray-200 flex flex-col items-stretch shadow-2xl 
        transition-all duration-300 ease-in-out
        ${isSidebarOpen ? 'translate-x-0 opacity-100' : '-translate-x-full opacity-0 pointer-events-none'}
        md:pointer-events-auto md:shadow-sm
      `}>
        <div className="p-6 flex items-center justify-between mb-2">
          <div className="flex items-center gap-3">
            <Star className={`${layoutTheme.text} ${layoutTheme.fill} w-7 h-7`} />
            <span className="font-serif font-bold text-2xl tracking-wide"></span>
          </div>
          <button 
            className="p-2 text-gray-400 hover:text-dark transition-colors rounded-lg hover:bg-gray-100"
            onClick={() => setIsSidebarOpen(false)}
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="px-4 mb-6">
          <div className="bg-gray-50 border border-gray-200 rounded-xl p-3 flex flex-col gap-2.5">
            <div className="flex items-center gap-3">
              <div className="bg-white/20 rounded-full p-2">
                {profile === 'PYME' ? <Building2 className="w-4 h-4 text-white"/> : profile === 'CONTADOR' ? <BriefcaseBusiness className="w-4 h-4 text-white"/> : <User className="w-4 h-4 text-white"/>}
              </div>
              <div className="text-sm font-medium leading-tight text-dark">
                {profile === 'PF' && t.user_name_pf}
                {profile === 'PYME' && t.user_name_pyme}
                {profile === 'CONTADOR' && t.user_name_contador}
              </div>
            </div>
          </div>
        </div>

        <nav className="flex-1 px-3 space-y-1.5 overflow-y-auto">
          {navItems.map(item => (
            <button
              key={item.id}
              onClick={() => {
                setCurrentView(item.id);
                setIsSidebarOpen(false);
              }}
              className={`w-full text-left px-4 py-2.5 rounded-lg transition-colors text-sm font-medium ${
                currentView === item.id ? `${layoutTheme.bg} text-white shadow-md ${layoutTheme.shadow}` : `text-gray-600 ${layoutTheme.textHover} hover:bg-gray-50`
              }`}
            >
              {item.label}
            </button>
          ))}
        </nav>

        <div className="p-5 border-t border-gray-100 flex flex-col gap-3">
          <button
            onClick={() => setProfile(null)}
            className={`w-full flex items-center justify-center gap-2 text-sm font-bold ${layoutTheme.bg} ${layoutTheme.bgHover} text-white py-2.5 rounded-xl transition-colors shadow-sm`}
          >
            <User className="w-4 h-4" />
            {t.profiles_menu}
          </button>
          
          <button
            onClick={onLogout}
            className="w-full flex items-center justify-center gap-2 text-sm font-medium text-gray-500 hover:text-red-500 hover:bg-red-50 py-2 rounded-xl transition-colors"
          >
            <LogOut className="w-4 h-4" />
            {t.logout}
          </button>
        </div>
      </aside>

      <main className={`flex-1 flex flex-col min-w-0 overflow-hidden relative transition-all duration-300 ${isSidebarOpen ? 'md:ml-0' : 'ml-0'}`}>
        <header className="h-[72px] bg-white border-b border-gray-200 flex items-center justify-between px-4 md:px-8 shrink-0 z-10 shadow-sm relative">
          <div className="flex items-center gap-4">
            <div className="hidden md:flex items-center gap-2 mr-4">
               <button 
                 onClick={() => setProfile(null)}
                 className={`group flex items-center gap-2 py-2 px-4 rounded-full border border-gray-200 bg-white hover:border-${layoutTheme.text.split('-')[1]} transition-all shadow-sm`}
               >
                 <div className={`${layoutTheme.bg} p-1.5 rounded-full text-white group-hover:scale-110 transition-transform`}>
                   <User className="w-3.5 h-3.5" />
                 </div>
                 <span className="text-xs font-bold text-dark">{t.profiles_menu}</span>
               </button>
            </div>

            {currentView !== 'dashboard' ? (
              <button 
                onClick={goBack}
                className="p-2 bg-gray-50 text-secondary border border-gray-100 rounded-full hover:bg-secondary-light transition-all shadow-sm"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
            ) : (
              !isSidebarOpen && (
                <button 
                  className="p-2 -ml-2 text-gray-500 hover:text-dark transition-colors bg-gray-50 rounded-xl border border-gray-100"
                  onClick={() => setIsSidebarOpen(true)}
                >
                  <Menu className="w-6 h-6" />
                </button>
              )
            )}
            <h2 className="text-lg md:text-xl font-semibold text-dark truncate">
              {navItems.find(i => i.id === currentView)?.label}
            </h2>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <button
                onClick={toggleTheme}
                className="p-2 border border-gray-200 text-dark rounded-full hover:bg-gray-100 transition-colors bg-white shadow-sm"
                title={theme === 'light' ? 'Modo oscuro' : 'Modo claro'}
              >
                {theme === 'light' ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
              </button>

              <div className="relative group">
                <button className="flex items-center gap-1.5 py-2 px-3 rounded-full border border-gray-200 bg-white hover:bg-gray-50 transition-all shadow-sm">
                  <Globe className="w-4 h-4 text-green-700" />
                  <span className="text-xs font-bold text-green-800 uppercase">{language}</span>
                </button>
                <div className="absolute right-0 top-full mt-2 w-48 bg-white rounded-2xl shadow-xl border border-gray-100 py-2 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-50">
                  <div className="px-4 py-2 border-b border-gray-50 mb-1">
                    <p className="text-[10px] font-black uppercase text-gray-400 tracking-widest">{t.common?.lang_label || 'Cambiar idioma'}</p>
                  </div>
                  {[
                    { code: 'es', label: 'Español (México)', flag: '🇲🇽' },
                    { code: 'en', label: 'English', flag: '🇺🇸' },
                    { code: 'fr', label: 'Français', flag: '🇫🇷' },
                    { code: 'pt', label: 'Português (Brasil)', flag: '🇧🇷' },
                    { code: 'it', label: 'Italiano (Italia)', flag: '🇮🇹' },
                    { code: 'zh', label: '中文 (简体)', flag: '🇨🇳' },
                  ].map(lang => (
                    <button
                      key={lang.code}
                      onClick={() => {
                        setLanguage(lang.code);
                        showToast(`${t.common?.success || '✓'} ${lang.label}`);
                      }}
                      className={`w-full flex items-center justify-between px-4 py-2 text-sm hover:bg-gray-50 transition-colors ${language === lang.code ? 'text-green-700 font-bold bg-green-50/50' : 'text-dark font-medium'}`}
                    >
                      <div className="flex items-center gap-2">
                        <span>{lang.flag}</span>
                        <span>{lang.label}</span>
                      </div>
                      {language === lang.code && <Check className="w-4 h-4" />}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="hidden sm:flex">
              {profile === 'PF' && (
                <div className="flex items-center gap-2.5 bg-amber-50 text-amber-700 px-4 md:px-5 py-2 rounded-full text-xs md:text-sm font-bold border border-amber-200/60 shadow-sm">
                  <CalendarDays className="w-4 h-4 md:w-4.5 md:h-4.5" />
                  <span className="hidden lg:inline">{t.pf_view.promo_title}</span>
                  <span className="lg:hidden">{t.pf_view.promo_title.split('·')[0]}</span>
                </div>
              )}
            </div>

            {profile === 'PYME' && (
              <div className="relative">
                <button 
                  onClick={() => {
                    setShowNotifications(!showNotifications);
                    if (!showNotifications) markAsRead();
                  }}
                  className="p-2.5 bg-gray-50 hover:bg-gray-100 rounded-2xl relative transition-all group"
                >
                  <Bell className="w-5 h-5 text-gray-500 group-hover:text-dark" />
                  {unreadCount > 0 && (
                    <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-[10px] font-black flex items-center justify-center rounded-full border-2 border-white">
                      {unreadCount}
                    </span>
                  )}
                </button>

                <AnimatePresence>
                  {showNotifications && (
                    <>
                      <div className="fixed inset-0 z-[190]" onClick={() => setShowNotifications(false)} />
                      <motion.div 
                        initial={{ opacity: 0, y: 10, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 10, scale: 0.95 }}
                        className="absolute right-0 mt-4 w-80 bg-white rounded-[2rem] shadow-2xl border border-gray-100 z-[200] overflow-hidden"
                      >
                        <div className="p-5 border-b border-gray-50 flex justify-between items-center">
                          <h4 className="text-sm font-black text-dark uppercase tracking-widest">{t.notifications_title}</h4>
                          <span className="text-[10px] font-bold text-gray-400 capitalize">{unreadCount} {t.notifications_pending}</span>
                        </div>
                        <div className="max-h-[400px] overflow-y-auto">
                          {notifications.map((n) => (
                            <div key={n.id} className={`p-4 border-b border-gray-50 flex gap-4 hover:bg-gray-50 transition-colors cursor-pointer ${!n.read ? 'bg-blue-50/20' : ''}`}>
                              <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                                n.type === 'urgent' ? 'bg-red-100 text-red-600' : 
                                n.type === 'attention' ? 'bg-amber-100 text-amber-600' : 'bg-blue-100 text-blue-600'
                              }`}>
                                {n.type === 'urgent' ? <AlertCircle className="w-5 h-5" /> : 
                                 n.type === 'attention' ? <Info className="w-5 h-5" /> : <Check className="w-5 h-5" />}
                              </div>
                              <div>
                                <p className="text-xs font-bold text-dark leading-tight mb-1">{t.notifications_list?.[n.id]?.text || 'Notificación'}</p>
                                <div className="flex items-center gap-1.5 text-[10px] text-gray-400 font-bold uppercase">
                                  <Clock className="w-3 h-3" />
                                  <span>{t.notifications_list?.[n.id]?.time || 'hace poco'}</span>
                                </div>
                                <button 
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    const text = t.notifications_list?.[n.id]?.text || '';
                                    setCurrentView(n.type === 'urgent' ? 'alertas' : text.includes('Concilia') || text.includes('Reconcili') ? 'conciliacion' : 'validación');
                                    setShowNotifications(false);
                                  }}
                                  className="text-[9px] font-black text-secondary mt-2 uppercase tracking-widest hover:underline"
                                >
                                  {t.notifications_detail}
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </motion.div>
                    </>
                  )}
                </AnimatePresence>
              </div>
            )}
          </div>
        </header>

        <div className="flex-1 overflow-auto bg-light p-4 md:p-6">
          {children}
        </div>
      </main>
    </div>
  );
}

// Helper for deep merging translations
function isObject(item: any) {
  return (item && typeof item === 'object' && !Array.isArray(item));
}

function deepMerge(target: any, source: any) {
  let output = Object.assign({}, target);
  if (isObject(target) && isObject(source)) {
    Object.keys(source).forEach(key => {
      if (isObject(source[key])) {
        if (!(key in target))
          Object.assign(output, { [key]: source[key] });
        else
          output[key] = deepMerge(target[key], source[key]);
      } else {
        Object.assign(output, { [key]: source[key] });
      }
    });
  }
  return output;
}

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [profile, setProfile] = useState<ProfileType>(null);
  const [currentView, setCurrentView] = useState('dashboard');
  const [viewHistory, setViewHistory] = useState<string[]>(['dashboard']);
  const [toast, setToast] = useState<string | null>(null);
  const [isAdminMode, setIsAdminMode] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [notifications, setNotifications] = useState([
    { id: 1, type: 'urgent', textKey: 'notifications_list.n1', read: false },
    { id: 2, type: 'attention', textKey: 'notifications_list.n2', read: false },
    { id: 3, type: 'attention', textKey: 'notifications_list.n3', read: true },
    { id: 4, type: 'info', textKey: 'notifications_list.n4', read: true },
  ]);

  const [language, setLanguage] = useState(() => {
    const saved = localStorage.getItem('app_lang');
    const selected = localStorage.getItem('app_lang_selected') === 'true';
    // SI NO SE HA SELECCIONADO IDIOMA, FORZAR ESPAÑOL
    if (!selected) return 'es';
    if (saved && translations[saved]) return saved;
    return 'es';
  });
  const [languageSelected, setLanguageSelected] = useState(() => localStorage.getItem('app_lang_selected') === 'true');
  const [dynamicTranslations, setDynamicTranslations] = useState<any>({});

  const [theme, setTheme] = useState<ThemeType>(() => {
    const saved = localStorage.getItem('facturapp_theme') as ThemeType;
    if (saved) return saved;
    return typeof window !== 'undefined' && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  });

  useEffect(() => {
    localStorage.setItem('facturapp_theme', theme);
    if (theme === 'dark') {
      document.documentElement.setAttribute('data-theme', 'dark');
    } else {
      document.documentElement.setAttribute('data-theme', 'light');
    }
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prev => {
      const next = prev === 'light' ? 'dark' : 'light';
      const tLayer = { ...translations[language], ...dynamicTranslations };
      showToast(`${tLayer.common?.success || '✓'} ${next === 'dark' ? (tLayer.common?.dark_mode || 'Modo oscuro activado') : (tLayer.common?.light_mode || 'Modo claro activado')}`);
      return next;
    });
  };

  // Fetch dynamic translations from Firestore for the selected language
  useEffect(() => {
    const fetchTranslations = async () => {
      try {
        const { doc, getDoc, setDoc } = await import('firebase/firestore');
        const { db } = await import('./lib/firebase');
        
        // We look for a document in app_translations/ui that holds translation overrides
        // The Translate Text extension should be configured to translate the 'text' field
        // and output to a 'translated' map in the same document.
        const docRef = doc(db, 'app_translations', 'ui_strings');
        const docSnap = await getDoc(docRef);
        
        if (docSnap.exists()) {
          const data = docSnap.data();
          // Read from the translated output of the extension
          if (language !== 'es' && data.translated && data.translated[language]) {
            setDynamicTranslations(data.translated[language]);
          }
          // Update base strings if they are missing or if we just want to ensure it's there
          // We won't overwrite constantly to avoid infinite translation loops
        } else {
          // Initialize the document with our base Spanish translations
          // The Translate extension will pick this up when installed
          try {
            await setDoc(docRef, { text: translations.es });
          } catch (writeErr) {
            // Ignore write errors (e.g. permission denied)
          }
        }
      } catch (error: any) {
        // Silently ignore offline errors to avoid spamming the console
        if (error?.message?.includes('client is offline')) {
          // Firebase might be offline or blocked by rules, ignore gracefully
          return;
        }
        console.warn('Could not fetch dynamic translations from Firebase', error?.message || error);
      }
    };
    
    fetchTranslations();
  }, [language, languageSelected]);

  useEffect(() => {
    localStorage.setItem('app_lang', language);
  }, [language]);

  useEffect(() => {
    localStorage.setItem('app_lang_selected', languageSelected.toString());
  }, [languageSelected]);

  const unreadCount = notifications.filter(n => !n.read).length;

  const markAsRead = () => {
    setNotifications(notifications.map(n => ({ ...n, read: true })));
  };

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  const handleSetView = (v: string) => {
    setViewHistory(prev => [...prev, v]);
    setCurrentView(v);
  };

  const goBack = () => {
    if (viewHistory.length > 1) {
      const newHistory = [...viewHistory];
      newHistory.pop();
      const lastView = newHistory[newHistory.length - 1];
      setViewHistory(newHistory);
      setCurrentView(lastView);
    } else {
      setCurrentView('dashboard');
    }
  };

  return (
    <AppContext.Provider value={{
      profile,
      setProfile: (p) => { 
        setProfile(p); 
        setCurrentView('dashboard'); 
        setViewHistory(['dashboard']);
      },
      currentView,
      setCurrentView: handleSetView,
      viewHistory,
      goBack,
      showToast,
      isAdminMode,
      setIsAdminMode,
      showNotifications,
      setShowNotifications,
      notifications,
      setNotifications,
      unreadCount,
      markAsRead,
      language,
      setLanguage,
      languageSelected,
      setLanguageSelected,
      theme,
      setTheme,
      toggleTheme,
      t: deepMerge(deepMerge(translations.es, dynamicTranslations), translations[language] || {})
    }}>
      {!isLoggedIn ? (
        <Login onLogin={() => setIsLoggedIn(true)} />
      ) : !profile ? (
        <ProfileSelector />
      ) : (
        <Layout onLogout={() => { setIsLoggedIn(false); setProfile(null); setLanguageSelected(false); }}>
          {profile === 'PF' && <PersonaFisicaView />}
          {profile === 'PYME' && <PYMEView />}
          {profile === 'CONTADOR' && <ContadorView />}
          {profile === 'ADMIN' && <AdminView />}
        </Layout>
      )}

      {/* Toast Notification */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="fixed bottom-8 left-1/2 -translate-x-1/2 z-[200] bg-dark text-white px-6 py-3 rounded-full shadow-2xl font-bold flex items-center gap-3 border border-white/10"
          >
            <div className="w-5 h-5 bg-secondary rounded-full flex items-center justify-center">
              <Star className="w-3 h-3 text-white fill-white" />
            </div>
            {toast}
          </motion.div>
        )}
      </AnimatePresence>
    </AppContext.Provider>
  );
}
